# YouTube Essayists

- [[Jenny Nicholson]] (113)
- [[Lindsay Ellis]] (132)
- [[hbomberguy]] (69)
