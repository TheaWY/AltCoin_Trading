---
title: "THE NO MAN'S SKY RANT [EPILEPSY WARNING]"
channel: "hbomberguy"
type: "video"
video_id: "4DhaUe6y-Co"
url: "https://www.youtube.com/watch?v=4DhaUe6y-Co"
duration: "00:06:58"
upload_order: 20
about: "Rant about No Man's Sky"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# THE NO MAN'S SKY RANT [EPILEPSY WARNING]

Channel: [[hbomberguy]] · Length 00:06:58 · [YouTube](https://www.youtube.com/watch?v=4DhaUe6y-Co)

## What it is

Rant about No Man's Sky

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
