---
title: "THE NO MAN'S SKY RANT [EPILEPSY WARNING]"
channel: "hbomberguy"
type: "video"
video_id: "4DhaUe6y-Co"
url: "https://www.youtube.com/watch?v=4DhaUe6y-Co"
duration: "00:06:58"
upload_order: 20
about_ko: "노 맨즈 스카이 분노 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# THE NO MAN'S SKY RANT [EPILEPSY WARNING]

채널: [[hbomberguy]] · 길이 00:06:58 · [YouTube](https://www.youtube.com/watch?v=4DhaUe6y-Co)

## 어떤 영상인가

노 맨즈 스카이 분노 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
