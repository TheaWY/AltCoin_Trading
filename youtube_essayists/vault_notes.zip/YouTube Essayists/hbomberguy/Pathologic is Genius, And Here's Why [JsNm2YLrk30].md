---
title: "Pathologic is Genius, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "JsNm2YLrk30"
url: "https://www.youtube.com/watch?v=JsNm2YLrk30"
duration: "02:10:52"
upload_order: 62
about: "Why the game Pathologic is brilliant"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Pathologic is Genius, And Here's Why

Channel: [[hbomberguy]] · Length 02:10:52 · [YouTube](https://www.youtube.com/watch?v=JsNm2YLrk30)

## What it is

Why the game Pathologic is brilliant

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
