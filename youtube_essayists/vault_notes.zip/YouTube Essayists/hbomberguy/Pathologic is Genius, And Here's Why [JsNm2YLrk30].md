---
title: "Pathologic is Genius, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "JsNm2YLrk30"
url: "https://www.youtube.com/watch?v=JsNm2YLrk30"
duration: "02:10:52"
upload_order: 62
about_ko: "게임 Pathologic이 천재적인 이유"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Pathologic is Genius, And Here's Why

채널: [[hbomberguy]] · 길이 02:10:52 · [YouTube](https://www.youtube.com/watch?v=JsNm2YLrk30)

## 어떤 영상인가

게임 Pathologic이 천재적인 이유

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
