---
title: "Fallout: New Vegas Is Genius, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "gzF7aHxk4Y4"
url: "https://www.youtube.com/watch?v=gzF7aHxk4Y4"
duration: "01:37:42"
upload_order: 64
about_ko: "폴아웃: 뉴 베가스가 훌륭한 이유"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Fallout: New Vegas Is Genius, And Here's Why

채널: [[hbomberguy]] · 길이 01:37:42 · [YouTube](https://www.youtube.com/watch?v=gzF7aHxk4Y4)

## 어떤 영상인가

폴아웃: 뉴 베가스가 훌륭한 이유

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
