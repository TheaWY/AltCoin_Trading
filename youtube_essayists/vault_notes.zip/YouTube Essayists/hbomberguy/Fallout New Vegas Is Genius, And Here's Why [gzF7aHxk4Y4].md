---
title: "Fallout: New Vegas Is Genius, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "gzF7aHxk4Y4"
url: "https://www.youtube.com/watch?v=gzF7aHxk4Y4"
duration: "01:37:42"
upload_order: 64
about: "Why Fallout: New Vegas is great"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Fallout: New Vegas Is Genius, And Here's Why

Channel: [[hbomberguy]] · Length 01:37:42 · [YouTube](https://www.youtube.com/watch?v=gzF7aHxk4Y4)

## What it is

Why Fallout: New Vegas is great

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
