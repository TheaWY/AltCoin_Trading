---
title: "Why Is New Donk City Uncanny? - SERIOUS LORE ANALYSIS"
channel: "hbomberguy"
type: "video"
video_id: "5_IT0C7bm2s"
url: "https://www.youtube.com/watch?v=5_IT0C7bm2s"
duration: "00:15:21"
upload_order: 30
about: "Comedy analysis of why New Donk City in Mario Odyssey is uncanny"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Why Is New Donk City Uncanny? - SERIOUS LORE ANALYSIS

Channel: [[hbomberguy]] · Length 00:15:21 · [YouTube](https://www.youtube.com/watch?v=5_IT0C7bm2s)

## What it is

Comedy analysis of why New Donk City in Mario Odyssey is uncanny

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
