---
title: "Why Is New Donk City Uncanny? - SERIOUS LORE ANALYSIS"
channel: "hbomberguy"
type: "video"
video_id: "5_IT0C7bm2s"
url: "https://www.youtube.com/watch?v=5_IT0C7bm2s"
duration: "00:15:21"
upload_order: 30
about_ko: "마리오 오디세이 뉴 동크 시티가 불쾌한 이유(코미디 분석)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Why Is New Donk City Uncanny? - SERIOUS LORE ANALYSIS

채널: [[hbomberguy]] · 길이 00:15:21 · [YouTube](https://www.youtube.com/watch?v=5_IT0C7bm2s)

## 어떤 영상인가

마리오 오디세이 뉴 동크 시티가 불쾌한 이유(코미디 분석)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
