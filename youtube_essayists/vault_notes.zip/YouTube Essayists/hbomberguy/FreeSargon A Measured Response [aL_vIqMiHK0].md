---
title: "#FreeSargon: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "aL_vIqMiHK0"
url: "https://www.youtube.com/watch?v=aL_vIqMiHK0"
duration: "00:09:50"
upload_order: 31
about: "Debunking the #FreeSargon hashtag"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# #FreeSargon: A Measured Response

Channel: [[hbomberguy]] · Length 00:09:50 · [YouTube](https://www.youtube.com/watch?v=aL_vIqMiHK0)

## What it is

Debunking the #FreeSargon hashtag

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
