---
title: "#FreeSargon: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "aL_vIqMiHK0"
url: "https://www.youtube.com/watch?v=aL_vIqMiHK0"
duration: "00:09:50"
upload_order: 31
about_ko: "#FreeSargon 해시태그 반박"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# #FreeSargon: A Measured Response

채널: [[hbomberguy]] · 길이 00:09:50 · [YouTube](https://www.youtube.com/watch?v=aL_vIqMiHK0)

## 어떤 영상인가

#FreeSargon 해시태그 반박

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
