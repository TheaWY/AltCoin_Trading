---
title: "Second Look At Nintendo Switch"
channel: "hbomberguy"
type: "video"
video_id: "g43NZSmY6-8"
url: "https://www.youtube.com/watch?v=g43NZSmY6-8"
duration: "00:03:30"
upload_order: 23
about: "A second look at the Nintendo Switch"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Second Look At Nintendo Switch

Channel: [[hbomberguy]] · Length 00:03:30 · [YouTube](https://www.youtube.com/watch?v=g43NZSmY6-8)

## What it is

A second look at the Nintendo Switch

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
