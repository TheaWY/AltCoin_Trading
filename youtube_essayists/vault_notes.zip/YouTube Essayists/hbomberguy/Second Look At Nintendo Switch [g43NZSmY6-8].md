---
title: "Second Look At Nintendo Switch"
channel: "hbomberguy"
type: "video"
video_id: "g43NZSmY6-8"
url: "https://www.youtube.com/watch?v=g43NZSmY6-8"
duration: "00:03:30"
upload_order: 23
about_ko: "닌텐도 스위치 재평가"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Second Look At Nintendo Switch

채널: [[hbomberguy]] · 길이 00:03:30 · [YouTube](https://www.youtube.com/watch?v=g43NZSmY6-8)

## 어떤 영상인가

닌텐도 스위치 재평가

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
