---
title: "Thunderf00t VS. FemiNAZI Ghostbusters: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "SpgBkpb7xlU"
url: "https://www.youtube.com/watch?v=SpgBkpb7xlU"
duration: "00:20:24"
upload_order: 9
about: "Rebuttal to Thunderf00t's Ghostbusters video"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Thunderf00t VS. FemiNAZI Ghostbusters: A Measured Response

Channel: [[hbomberguy]] · Length 00:20:24 · [YouTube](https://www.youtube.com/watch?v=SpgBkpb7xlU)

## What it is

Rebuttal to Thunderf00t's Ghostbusters video

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
