---
title: "Thunderf00t VS. FemiNAZI Ghostbusters: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "SpgBkpb7xlU"
url: "https://www.youtube.com/watch?v=SpgBkpb7xlU"
duration: "00:20:24"
upload_order: 9
about_ko: "Thunderf00t의 고스트버스터즈 영상 반박"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Thunderf00t VS. FemiNAZI Ghostbusters: A Measured Response

채널: [[hbomberguy]] · 길이 00:20:24 · [YouTube](https://www.youtube.com/watch?v=SpgBkpb7xlU)

## 어떤 영상인가

Thunderf00t의 고스트버스터즈 영상 반박

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
