---
title: "Measured Response: Bill Nye VS Pseudoscience (Part One)"
channel: "hbomberguy"
type: "video"
video_id: "dklVypazQsA"
url: "https://www.youtube.com/watch?v=dklVypazQsA"
duration: "00:35:05"
upload_order: 38
about: "Bill Nye vs pseudoscience, part 1"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Measured Response: Bill Nye VS Pseudoscience (Part One)

Channel: [[hbomberguy]] · Length 00:35:05 · [YouTube](https://www.youtube.com/watch?v=dklVypazQsA)

## What it is

Bill Nye vs pseudoscience, part 1

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
