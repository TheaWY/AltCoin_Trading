---
title: "Measured Response: Bill Nye VS Pseudoscience (Part One)"
channel: "hbomberguy"
type: "video"
video_id: "dklVypazQsA"
url: "https://www.youtube.com/watch?v=dklVypazQsA"
duration: "00:35:05"
upload_order: 38
about_ko: "빌 나이 대 사이비과학 1부"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Measured Response: Bill Nye VS Pseudoscience (Part One)

채널: [[hbomberguy]] · 길이 00:35:05 · [YouTube](https://www.youtube.com/watch?v=dklVypazQsA)

## 어떤 영상인가

빌 나이 대 사이비과학 1부

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
