---
title: "Plagiarism and You(Tube)"
channel: "hbomberguy"
type: "video"
video_id: "yDp3cB5fHXQ"
url: "https://www.youtube.com/watch?v=yDp3cB5fHXQ"
duration: "03:51:10"
upload_order: 69
about_ko: "유튜브 표절(제임스 소머턴 등)을 고발한 4시간 다큐. 채널 대표작"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Plagiarism and You(Tube)

채널: [[hbomberguy]] · 길이 03:51:10 · [YouTube](https://www.youtube.com/watch?v=yDp3cB5fHXQ)

## 어떤 영상인가

유튜브 표절(제임스 소머턴 등)을 고발한 4시간 다큐. 채널 대표작

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
