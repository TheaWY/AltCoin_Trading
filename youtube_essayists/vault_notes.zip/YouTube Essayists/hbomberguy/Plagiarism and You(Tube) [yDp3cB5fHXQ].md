---
title: "Plagiarism and You(Tube)"
channel: "hbomberguy"
type: "video"
video_id: "yDp3cB5fHXQ"
url: "https://www.youtube.com/watch?v=yDp3cB5fHXQ"
duration: "03:51:10"
upload_order: 69
about: "Four-hour documentary exposing plagiarism on YouTube (James Somerton and others). The channel's best-known video"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Plagiarism and You(Tube)

Channel: [[hbomberguy]] · Length 03:51:10 · [YouTube](https://www.youtube.com/watch?v=yDp3cB5fHXQ)

## What it is

Four-hour documentary exposing plagiarism on YouTube (James Somerton and others). The channel's best-known video

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
