---
title: "Sargon's Petition: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "XmKGPRXE-xw"
url: "https://www.youtube.com/watch?v=XmKGPRXE-xw"
duration: "00:17:08"
upload_order: 17
about_ko: "사르곤 청원 반박"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Sargon's Petition: A Measured Response

채널: [[hbomberguy]] · 길이 00:17:08 · [YouTube](https://www.youtube.com/watch?v=XmKGPRXE-xw)

## 어떤 영상인가

사르곤 청원 반박

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
