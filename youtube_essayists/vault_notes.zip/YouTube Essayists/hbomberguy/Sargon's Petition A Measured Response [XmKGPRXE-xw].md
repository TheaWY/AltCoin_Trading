---
title: "Sargon's Petition: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "XmKGPRXE-xw"
url: "https://www.youtube.com/watch?v=XmKGPRXE-xw"
duration: "00:17:08"
upload_order: 17
about: "Rebuttal to Sargon's petition"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Sargon's Petition: A Measured Response

Channel: [[hbomberguy]] · Length 00:17:08 · [YouTube](https://www.youtube.com/watch?v=XmKGPRXE-xw)

## What it is

Rebuttal to Sargon's petition

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
