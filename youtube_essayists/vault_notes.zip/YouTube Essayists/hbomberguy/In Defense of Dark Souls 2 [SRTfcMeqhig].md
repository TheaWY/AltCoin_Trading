---
title: "In Defense of Dark Souls 2"
channel: "hbomberguy"
type: "video"
video_id: "SRTfcMeqhig"
url: "https://www.youtube.com/watch?v=SRTfcMeqhig"
duration: "01:19:44"
upload_order: 34
about: "A defense of Dark Souls 2"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# In Defense of Dark Souls 2

Channel: [[hbomberguy]] · Length 01:19:44 · [YouTube](https://www.youtube.com/watch?v=SRTfcMeqhig)

## What it is

A defense of Dark Souls 2

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
