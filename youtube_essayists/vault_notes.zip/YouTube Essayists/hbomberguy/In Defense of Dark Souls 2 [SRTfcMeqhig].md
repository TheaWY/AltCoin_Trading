---
title: "In Defense of Dark Souls 2"
channel: "hbomberguy"
type: "video"
video_id: "SRTfcMeqhig"
url: "https://www.youtube.com/watch?v=SRTfcMeqhig"
duration: "01:19:44"
upload_order: 34
about_ko: "다크 소울 2 옹호"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# In Defense of Dark Souls 2

채널: [[hbomberguy]] · 길이 01:19:44 · [YouTube](https://www.youtube.com/watch?v=SRTfcMeqhig)

## 어떤 영상인가

다크 소울 2 옹호

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
