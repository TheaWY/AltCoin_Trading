---
title: "The Golden One: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "Ahuj1B0ow4U"
url: "https://www.youtube.com/watch?v=Ahuj1B0ow4U"
duration: "00:22:55"
upload_order: 27
about_ko: "유튜버 The Golden One 반박"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# The Golden One: A Measured Response

채널: [[hbomberguy]] · 길이 00:22:55 · [YouTube](https://www.youtube.com/watch?v=Ahuj1B0ow4U)

## 어떤 영상인가

유튜버 The Golden One 반박

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
