---
title: "The Golden One: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "Ahuj1B0ow4U"
url: "https://www.youtube.com/watch?v=Ahuj1B0ow4U"
duration: "00:22:55"
upload_order: 27
about: "Rebuttal to YouTuber The Golden One"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# The Golden One: A Measured Response

Channel: [[hbomberguy]] · Length 00:22:55 · [YouTube](https://www.youtube.com/watch?v=Ahuj1B0ow4U)

## What it is

Rebuttal to YouTuber The Golden One

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
