---
title: "Skyrim is Garbage, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "WYwpEzBvulA"
url: "https://www.youtube.com/watch?v=WYwpEzBvulA"
duration: "00:40:17"
upload_order: 51
about_ko: "스카이림이 별로인 이유"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Skyrim is Garbage, And Here's Why

채널: [[hbomberguy]] · 길이 00:40:17 · [YouTube](https://www.youtube.com/watch?v=WYwpEzBvulA)

## 어떤 영상인가

스카이림이 별로인 이유

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
