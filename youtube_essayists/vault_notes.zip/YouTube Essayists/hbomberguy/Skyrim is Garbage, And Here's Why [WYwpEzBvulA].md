---
title: "Skyrim is Garbage, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "WYwpEzBvulA"
url: "https://www.youtube.com/watch?v=WYwpEzBvulA"
duration: "00:40:17"
upload_order: 51
about: "Why Skyrim is bad"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Skyrim is Garbage, And Here's Why

Channel: [[hbomberguy]] · Length 00:40:17 · [YouTube](https://www.youtube.com/watch?v=WYwpEzBvulA)

## What it is

Why Skyrim is bad

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
