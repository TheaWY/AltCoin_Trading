---
title: "Doomfist In-Depth Analysis & Review"
channel: "hbomberguy"
type: "video"
video_id: "YpdY8eMwjZ8"
url: "https://www.youtube.com/watch?v=YpdY8eMwjZ8"
duration: "00:10:11"
upload_order: 41
about: "Comedy \"analysis\" of Overwatch's Doomfist"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Doomfist In-Depth Analysis & Review

Channel: [[hbomberguy]] · Length 00:10:11 · [YouTube](https://www.youtube.com/watch?v=YpdY8eMwjZ8)

## What it is

Comedy "analysis" of Overwatch's Doomfist

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
