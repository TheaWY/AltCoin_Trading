---
title: "Doomfist In-Depth Analysis & Review"
channel: "hbomberguy"
type: "video"
video_id: "YpdY8eMwjZ8"
url: "https://www.youtube.com/watch?v=YpdY8eMwjZ8"
duration: "00:10:11"
upload_order: 41
about_ko: "오버워치 둠피스트 분석(코미디)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Doomfist In-Depth Analysis & Review

채널: [[hbomberguy]] · 길이 00:10:11 · [YouTube](https://www.youtube.com/watch?v=YpdY8eMwjZ8)

## 어떤 영상인가

오버워치 둠피스트 분석(코미디)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
