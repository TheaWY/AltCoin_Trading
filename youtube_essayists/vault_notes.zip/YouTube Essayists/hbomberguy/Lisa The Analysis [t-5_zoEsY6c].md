---
title: "Lisa: The Analysis"
channel: "hbomberguy"
type: "video"
video_id: "t-5_zoEsY6c"
url: "https://www.youtube.com/watch?v=t-5_zoEsY6c"
duration: "00:40:51"
upload_order: 40
about: "Analysis of the game LISA"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Lisa: The Analysis

Channel: [[hbomberguy]] · Length 00:40:51 · [YouTube](https://www.youtube.com/watch?v=t-5_zoEsY6c)

## What it is

Analysis of the game LISA

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
