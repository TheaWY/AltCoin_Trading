---
title: "Lisa: The Analysis"
channel: "hbomberguy"
type: "video"
video_id: "t-5_zoEsY6c"
url: "https://www.youtube.com/watch?v=t-5_zoEsY6c"
duration: "00:40:51"
upload_order: 40
about_ko: "게임 LISA 분석"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Lisa: The Analysis

채널: [[hbomberguy]] · 길이 00:40:51 · [YouTube](https://www.youtube.com/watch?v=t-5_zoEsY6c)

## 어떤 영상인가

게임 LISA 분석

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
