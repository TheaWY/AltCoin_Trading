---
title: "WOKE BRANDS"
channel: "hbomberguy"
type: "video"
video_id: "06yy88tLWlg"
url: "https://www.youtube.com/watch?v=06yy88tLWlg"
duration: "00:26:44"
upload_order: 58
about: "Critique of \"woke\" corporate marketing"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# WOKE BRANDS

Channel: [[hbomberguy]] · Length 00:26:44 · [YouTube](https://www.youtube.com/watch?v=06yy88tLWlg)

## What it is

Critique of "woke" corporate marketing

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
