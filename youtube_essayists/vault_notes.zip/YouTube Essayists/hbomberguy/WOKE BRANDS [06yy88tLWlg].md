---
title: "WOKE BRANDS"
channel: "hbomberguy"
type: "video"
video_id: "06yy88tLWlg"
url: "https://www.youtube.com/watch?v=06yy88tLWlg"
duration: "00:26:44"
upload_order: 58
about_ko: "'깨어있는' 기업 마케팅 비판"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# WOKE BRANDS

채널: [[hbomberguy]] · 길이 00:26:44 · [YouTube](https://www.youtube.com/watch?v=06yy88tLWlg)

## 어떤 영상인가

'깨어있는' 기업 마케팅 비판

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
