---
title: "Hbomberguy's 100K Q&A!"
channel: "hbomberguy"
type: "video"
video_id: "5-qccQbgH6I"
url: "https://www.youtube.com/watch?v=5-qccQbgH6I"
duration: "00:36:23"
upload_order: 44
about_ko: "구독자 10만 기념 Q&A"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Hbomberguy's 100K Q&A!

채널: [[hbomberguy]] · 길이 00:36:23 · [YouTube](https://www.youtube.com/watch?v=5-qccQbgH6I)

## 어떤 영상인가

구독자 10만 기념 Q&A

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
