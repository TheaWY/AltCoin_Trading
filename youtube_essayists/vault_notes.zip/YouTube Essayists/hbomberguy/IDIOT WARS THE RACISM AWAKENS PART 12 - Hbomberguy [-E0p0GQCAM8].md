---
title: "IDIOT WARS: THE RACISM AWAKENS [PART 1/2] - Hbomberguy"
channel: "hbomberguy"
type: "video"
video_id: "-E0p0GQCAM8"
url: "https://www.youtube.com/watch?v=-E0p0GQCAM8"
duration: "00:09:12"
upload_order: 4
about_ko: "스타워즈 깨어난 포스 보이콧 논란 1부"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# IDIOT WARS: THE RACISM AWAKENS [PART 1/2] - Hbomberguy

채널: [[hbomberguy]] · 길이 00:09:12 · [YouTube](https://www.youtube.com/watch?v=-E0p0GQCAM8)

## 어떤 영상인가

스타워즈 깨어난 포스 보이콧 논란 1부

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
