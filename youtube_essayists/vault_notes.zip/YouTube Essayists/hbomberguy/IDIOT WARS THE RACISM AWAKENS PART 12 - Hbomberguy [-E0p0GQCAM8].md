---
title: "IDIOT WARS: THE RACISM AWAKENS [PART 1/2] - Hbomberguy"
channel: "hbomberguy"
type: "video"
video_id: "-E0p0GQCAM8"
url: "https://www.youtube.com/watch?v=-E0p0GQCAM8"
duration: "00:09:12"
upload_order: 4
about: "The Force Awakens boycott controversy, part 1"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# IDIOT WARS: THE RACISM AWAKENS [PART 1/2] - Hbomberguy

Channel: [[hbomberguy]] · Length 00:09:12 · [YouTube](https://www.youtube.com/watch?v=-E0p0GQCAM8)

## What it is

The Force Awakens boycott controversy, part 1

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
