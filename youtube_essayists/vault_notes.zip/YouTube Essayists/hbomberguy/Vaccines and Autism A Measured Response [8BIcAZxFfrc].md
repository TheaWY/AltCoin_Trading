---
title: "Vaccines and Autism: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "8BIcAZxFfrc"
url: "https://www.youtube.com/watch?v=8BIcAZxFfrc"
duration: "01:44:10"
upload_order: 66
about: "Long debunk of the vaccines-cause-autism claim"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Vaccines and Autism: A Measured Response

Channel: [[hbomberguy]] · Length 01:44:10 · [YouTube](https://www.youtube.com/watch?v=8BIcAZxFfrc)

## What it is

Long debunk of the vaccines-cause-autism claim

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
