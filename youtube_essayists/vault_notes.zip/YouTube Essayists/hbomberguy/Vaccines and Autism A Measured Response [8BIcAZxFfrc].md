---
title: "Vaccines and Autism: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "8BIcAZxFfrc"
url: "https://www.youtube.com/watch?v=8BIcAZxFfrc"
duration: "01:44:10"
upload_order: 66
about_ko: "백신-자폐 연관설을 반박하는 장편"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Vaccines and Autism: A Measured Response

채널: [[hbomberguy]] · 길이 01:44:10 · [YouTube](https://www.youtube.com/watch?v=8BIcAZxFfrc)

## 어떤 영상인가

백신-자폐 연관설을 반박하는 장편

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
