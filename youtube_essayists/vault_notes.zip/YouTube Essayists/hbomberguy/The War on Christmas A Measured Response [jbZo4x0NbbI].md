---
title: "The War on Christmas: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "jbZo4x0NbbI"
url: "https://www.youtube.com/watch?v=jbZo4x0NbbI"
duration: "00:53:58"
upload_order: 65
about_ko: "'크리스마스와의 전쟁' 담론 반박"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# The War on Christmas: A Measured Response

채널: [[hbomberguy]] · 길이 00:53:58 · [YouTube](https://www.youtube.com/watch?v=jbZo4x0NbbI)

## 어떤 영상인가

'크리스마스와의 전쟁' 담론 반박

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
