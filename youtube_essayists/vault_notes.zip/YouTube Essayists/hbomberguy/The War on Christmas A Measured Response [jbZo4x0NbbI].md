---
title: "The War on Christmas: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "jbZo4x0NbbI"
url: "https://www.youtube.com/watch?v=jbZo4x0NbbI"
duration: "00:53:58"
upload_order: 65
about: "Debunking the \"War on Christmas\" narrative"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# The War on Christmas: A Measured Response

Channel: [[hbomberguy]] · Length 00:53:58 · [YouTube](https://www.youtube.com/watch?v=jbZo4x0NbbI)

## What it is

Debunking the "War on Christmas" narrative

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
