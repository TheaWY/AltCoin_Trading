---
title: "Climate Denial: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "RLqXkYrdmjY"
url: "https://www.youtube.com/watch?v=RLqXkYrdmjY"
duration: "00:41:20"
upload_order: 60
about: "Debunking climate change denial"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Climate Denial: A Measured Response

Channel: [[hbomberguy]] · Length 00:41:20 · [YouTube](https://www.youtube.com/watch?v=RLqXkYrdmjY)

## What it is

Debunking climate change denial

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
