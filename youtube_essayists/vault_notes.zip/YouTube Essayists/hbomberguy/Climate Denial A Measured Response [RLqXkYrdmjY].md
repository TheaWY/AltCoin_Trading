---
title: "Climate Denial: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "RLqXkYrdmjY"
url: "https://www.youtube.com/watch?v=RLqXkYrdmjY"
duration: "00:41:20"
upload_order: 60
about_ko: "기후 변화 부정론 반박"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Climate Denial: A Measured Response

채널: [[hbomberguy]] · 길이 00:41:20 · [YouTube](https://www.youtube.com/watch?v=RLqXkYrdmjY)

## 어떤 영상인가

기후 변화 부정론 반박

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
