---
title: "Perverted Sentimentality: An Analysis of UNDERTALE"
channel: "hbomberguy"
type: "video"
video_id: "4E-0sjkDnkc"
url: "https://www.youtube.com/watch?v=4E-0sjkDnkc"
duration: "00:14:16"
upload_order: 19
about_ko: "언더테일 분석"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Perverted Sentimentality: An Analysis of UNDERTALE

채널: [[hbomberguy]] · 길이 00:14:16 · [YouTube](https://www.youtube.com/watch?v=4E-0sjkDnkc)

## 어떤 영상인가

언더테일 분석

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
