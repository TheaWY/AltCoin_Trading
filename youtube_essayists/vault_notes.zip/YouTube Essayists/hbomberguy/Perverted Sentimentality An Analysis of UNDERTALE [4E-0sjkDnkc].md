---
title: "Perverted Sentimentality: An Analysis of UNDERTALE"
channel: "hbomberguy"
type: "video"
video_id: "4E-0sjkDnkc"
url: "https://www.youtube.com/watch?v=4E-0sjkDnkc"
duration: "00:14:16"
upload_order: 19
about: "Analysis of Undertale"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Perverted Sentimentality: An Analysis of UNDERTALE

Channel: [[hbomberguy]] · Length 00:14:16 · [YouTube](https://www.youtube.com/watch?v=4E-0sjkDnkc)

## What it is

Analysis of Undertale

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
