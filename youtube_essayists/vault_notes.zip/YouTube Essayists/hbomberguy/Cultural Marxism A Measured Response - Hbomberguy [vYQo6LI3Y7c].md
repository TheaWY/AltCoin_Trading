---
title: "Cultural Marxism: A Measured Response - Hbomberguy"
channel: "hbomberguy"
type: "video"
video_id: "vYQo6LI3Y7c"
url: "https://www.youtube.com/watch?v=vYQo6LI3Y7c"
duration: "00:24:09"
upload_order: 3
about: "Debunking the \"Cultural Marxism\" conspiracy theory"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Cultural Marxism: A Measured Response - Hbomberguy

Channel: [[hbomberguy]] · Length 00:24:09 · [YouTube](https://www.youtube.com/watch?v=vYQo6LI3Y7c)

## What it is

Debunking the "Cultural Marxism" conspiracy theory

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
