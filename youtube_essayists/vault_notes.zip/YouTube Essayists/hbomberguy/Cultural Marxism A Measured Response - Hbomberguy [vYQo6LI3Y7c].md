---
title: "Cultural Marxism: A Measured Response - Hbomberguy"
channel: "hbomberguy"
type: "video"
video_id: "vYQo6LI3Y7c"
url: "https://www.youtube.com/watch?v=vYQo6LI3Y7c"
duration: "00:24:09"
upload_order: 3
about_ko: "'문화 마르크스주의' 음모론 반박"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Cultural Marxism: A Measured Response - Hbomberguy

채널: [[hbomberguy]] · 길이 00:24:09 · [YouTube](https://www.youtube.com/watch?v=vYQo6LI3Y7c)

## 어떤 영상인가

'문화 마르크스주의' 음모론 반박

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
