---
title: "I Filmed Myself Watching The Alt Right Dogs Trailer"
channel: "hbomberguy"
type: "video"
video_id: "1t_Bs-8L4Mo"
url: "https://www.youtube.com/watch?v=1t_Bs-8L4Mo"
duration: "00:15:02"
upload_order: 22
about_ko: "대안우파 다큐 예고편을 보며 촬영한 반응"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# I Filmed Myself Watching The Alt Right Dogs Trailer

채널: [[hbomberguy]] · 길이 00:15:02 · [YouTube](https://www.youtube.com/watch?v=1t_Bs-8L4Mo)

## 어떤 영상인가

대안우파 다큐 예고편을 보며 촬영한 반응

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
