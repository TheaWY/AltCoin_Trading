---
title: "I Filmed Myself Watching The Alt Right Dogs Trailer"
channel: "hbomberguy"
type: "video"
video_id: "1t_Bs-8L4Mo"
url: "https://www.youtube.com/watch?v=1t_Bs-8L4Mo"
duration: "00:15:02"
upload_order: 22
about: "Filming himself watching an alt-right documentary trailer"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# I Filmed Myself Watching The Alt Right Dogs Trailer

Channel: [[hbomberguy]] · Length 00:15:02 · [YouTube](https://www.youtube.com/watch?v=1t_Bs-8L4Mo)

## What it is

Filming himself watching an alt-right documentary trailer

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
