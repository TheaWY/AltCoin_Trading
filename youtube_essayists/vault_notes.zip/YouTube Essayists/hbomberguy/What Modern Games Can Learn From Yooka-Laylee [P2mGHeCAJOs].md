---
title: "What Modern Games Can Learn From Yooka-Laylee"
channel: "hbomberguy"
type: "video"
video_id: "P2mGHeCAJOs"
url: "https://www.youtube.com/watch?v=P2mGHeCAJOs"
duration: "00:13:53"
upload_order: 35
about: "What modern games can learn from Yooka-Laylee"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# What Modern Games Can Learn From Yooka-Laylee

Channel: [[hbomberguy]] · Length 00:13:53 · [YouTube](https://www.youtube.com/watch?v=P2mGHeCAJOs)

## What it is

What modern games can learn from Yooka-Laylee

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
