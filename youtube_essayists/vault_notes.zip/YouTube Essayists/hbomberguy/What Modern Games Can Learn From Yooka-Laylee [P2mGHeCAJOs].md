---
title: "What Modern Games Can Learn From Yooka-Laylee"
channel: "hbomberguy"
type: "video"
video_id: "P2mGHeCAJOs"
url: "https://www.youtube.com/watch?v=P2mGHeCAJOs"
duration: "00:13:53"
upload_order: 35
about_ko: "현대 게임이 Yooka-Laylee에서 배울 점"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# What Modern Games Can Learn From Yooka-Laylee

채널: [[hbomberguy]] · 길이 00:13:53 · [YouTube](https://www.youtube.com/watch?v=P2mGHeCAJOs)

## 어떤 영상인가

현대 게임이 Yooka-Laylee에서 배울 점

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
