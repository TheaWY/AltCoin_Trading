---
title: "The Power Of VHS | SCANLINE"
channel: "hbomberguy"
type: "video"
video_id: "xbZMqS-fW-8"
url: "https://www.youtube.com/watch?v=xbZMqS-fW-8"
duration: "00:29:21"
upload_order: 43
about: "The power of VHS (Scanline)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# The Power Of VHS | SCANLINE

Channel: [[hbomberguy]] · Length 00:29:21 · [YouTube](https://www.youtube.com/watch?v=xbZMqS-fW-8)

## What it is

The power of VHS (Scanline)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
