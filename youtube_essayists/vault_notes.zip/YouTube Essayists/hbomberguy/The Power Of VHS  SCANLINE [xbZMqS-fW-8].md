---
title: "The Power Of VHS | SCANLINE"
channel: "hbomberguy"
type: "video"
video_id: "xbZMqS-fW-8"
url: "https://www.youtube.com/watch?v=xbZMqS-fW-8"
duration: "00:29:21"
upload_order: 43
about_ko: "VHS의 힘 (Scanline)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# The Power Of VHS | SCANLINE

채널: [[hbomberguy]] · 길이 00:29:21 · [YouTube](https://www.youtube.com/watch?v=xbZMqS-fW-8)

## 어떤 영상인가

VHS의 힘 (Scanline)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
