---
title: "Weighing the Value of Director's Cuts | Scanline"
channel: "hbomberguy"
type: "video"
video_id: "D6OT77T7YlE"
url: "https://www.youtube.com/watch?v=D6OT77T7YlE"
duration: "00:49:07"
upload_order: 61
about: "Weighing the value of director's cuts (Scanline)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Weighing the Value of Director's Cuts | Scanline

Channel: [[hbomberguy]] · Length 00:49:07 · [YouTube](https://www.youtube.com/watch?v=D6OT77T7YlE)

## What it is

Weighing the value of director's cuts (Scanline)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
