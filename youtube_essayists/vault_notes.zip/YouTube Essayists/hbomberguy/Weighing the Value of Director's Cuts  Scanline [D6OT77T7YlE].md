---
title: "Weighing the Value of Director's Cuts | Scanline"
channel: "hbomberguy"
type: "video"
video_id: "D6OT77T7YlE"
url: "https://www.youtube.com/watch?v=D6OT77T7YlE"
duration: "00:49:07"
upload_order: 61
about_ko: "감독판의 가치 분석 (Scanline)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Weighing the Value of Director's Cuts | Scanline

채널: [[hbomberguy]] · 길이 00:49:07 · [YouTube](https://www.youtube.com/watch?v=D6OT77T7YlE)

## 어떤 영상인가

감독판의 가치 분석 (Scanline)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
