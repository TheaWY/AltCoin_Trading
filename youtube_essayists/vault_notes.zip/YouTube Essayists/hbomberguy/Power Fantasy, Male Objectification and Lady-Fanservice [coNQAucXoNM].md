---
title: "Power Fantasy, Male Objectification and Lady-Fanservice"
channel: "hbomberguy"
type: "video"
video_id: "coNQAucXoNM"
url: "https://www.youtube.com/watch?v=coNQAucXoNM"
duration: "00:11:19"
upload_order: 18
about_ko: "파워 판타지, 남성 대상화와 여성향 팬서비스"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Power Fantasy, Male Objectification and Lady-Fanservice

채널: [[hbomberguy]] · 길이 00:11:19 · [YouTube](https://www.youtube.com/watch?v=coNQAucXoNM)

## 어떤 영상인가

파워 판타지, 남성 대상화와 여성향 팬서비스

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
