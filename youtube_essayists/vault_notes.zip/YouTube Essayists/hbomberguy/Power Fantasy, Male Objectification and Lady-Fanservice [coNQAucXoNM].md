---
title: "Power Fantasy, Male Objectification and Lady-Fanservice"
channel: "hbomberguy"
type: "video"
video_id: "coNQAucXoNM"
url: "https://www.youtube.com/watch?v=coNQAucXoNM"
duration: "00:11:19"
upload_order: 18
about: "Power fantasy, male objectification and fanservice aimed at women"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Power Fantasy, Male Objectification and Lady-Fanservice

Channel: [[hbomberguy]] · Length 00:11:19 · [YouTube](https://www.youtube.com/watch?v=coNQAucXoNM)

## What it is

Power fantasy, male objectification and fanservice aimed at women

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
