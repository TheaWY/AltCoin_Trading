---
title: "What Makes An Action Scene Good?"
channel: "hbomberguy"
type: "video"
video_id: "ch-5ydxW_WE"
url: "https://www.youtube.com/watch?v=ch-5ydxW_WE"
duration: "00:14:35"
upload_order: 16
about: "What makes an action scene good"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# What Makes An Action Scene Good?

Channel: [[hbomberguy]] · Length 00:14:35 · [YouTube](https://www.youtube.com/watch?v=ch-5ydxW_WE)

## What it is

What makes an action scene good

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
