---
title: "What Makes An Action Scene Good?"
channel: "hbomberguy"
type: "video"
video_id: "ch-5ydxW_WE"
url: "https://www.youtube.com/watch?v=ch-5ydxW_WE"
duration: "00:14:35"
upload_order: 16
about_ko: "좋은 액션 장면의 조건"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# What Makes An Action Scene Good?

채널: [[hbomberguy]] · 길이 00:14:35 · [YouTube](https://www.youtube.com/watch?v=ch-5ydxW_WE)

## 어떤 영상인가

좋은 액션 장면의 조건

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
