---
title: "What Is \"Virtue Signalling\"?"
channel: "hbomberguy"
type: "video"
video_id: "sAmM872874A"
url: "https://www.youtube.com/watch?v=sAmM872874A"
duration: "00:10:48"
upload_order: 13
about_ko: "'버추 시그널링'이란 무엇인가"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# What Is "Virtue Signalling"?

채널: [[hbomberguy]] · 길이 00:10:48 · [YouTube](https://www.youtube.com/watch?v=sAmM872874A)

## 어떤 영상인가

'버추 시그널링'이란 무엇인가

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
