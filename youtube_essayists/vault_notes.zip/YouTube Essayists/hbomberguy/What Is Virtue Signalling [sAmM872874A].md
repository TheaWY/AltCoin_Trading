---
title: "What Is \"Virtue Signalling\"?"
channel: "hbomberguy"
type: "video"
video_id: "sAmM872874A"
url: "https://www.youtube.com/watch?v=sAmM872874A"
duration: "00:10:48"
upload_order: 13
about: "What \"virtue signalling\" means"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# What Is "Virtue Signalling"?

Channel: [[hbomberguy]] · Length 00:10:48 · [YouTube](https://www.youtube.com/watch?v=sAmM872874A)

## What it is

What "virtue signalling" means

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
