---
title: "Bill Nye VS Pseudoscience (Part Two!) | Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "LqYgjGDaMYg"
url: "https://www.youtube.com/watch?v=LqYgjGDaMYg"
duration: "00:55:50"
upload_order: 42
about: "Bill Nye vs pseudoscience, part 2"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Bill Nye VS Pseudoscience (Part Two!) | Measured Response

Channel: [[hbomberguy]] · Length 00:55:50 · [YouTube](https://www.youtube.com/watch?v=LqYgjGDaMYg)

## What it is

Bill Nye vs pseudoscience, part 2

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
