---
title: "Bill Nye VS Pseudoscience (Part Two!) | Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "LqYgjGDaMYg"
url: "https://www.youtube.com/watch?v=LqYgjGDaMYg"
duration: "00:55:50"
upload_order: 42
about_ko: "빌 나이 대 사이비과학 2부"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Bill Nye VS Pseudoscience (Part Two!) | Measured Response

채널: [[hbomberguy]] · 길이 00:55:50 · [YouTube](https://www.youtube.com/watch?v=LqYgjGDaMYg)

## 어떤 영상인가

빌 나이 대 사이비과학 2부

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
