---
title: "Pick Up Artistry: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "_pEfhgG3Ocw"
url: "https://www.youtube.com/watch?v=_pEfhgG3Ocw"
duration: "00:29:14"
upload_order: 33
about: "Debunking pickup artistry"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Pick Up Artistry: A Measured Response

Channel: [[hbomberguy]] · Length 00:29:14 · [YouTube](https://www.youtube.com/watch?v=_pEfhgG3Ocw)

## What it is

Debunking pickup artistry

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
