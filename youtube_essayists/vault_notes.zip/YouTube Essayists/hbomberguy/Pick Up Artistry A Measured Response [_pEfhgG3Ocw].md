---
title: "Pick Up Artistry: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "_pEfhgG3Ocw"
url: "https://www.youtube.com/watch?v=_pEfhgG3Ocw"
duration: "00:29:14"
upload_order: 33
about_ko: "픽업 아티스트 담론 반박"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Pick Up Artistry: A Measured Response

채널: [[hbomberguy]] · 길이 00:29:14 · [YouTube](https://www.youtube.com/watch?v=_pEfhgG3Ocw)

## 어떤 영상인가

픽업 아티스트 담론 반박

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
