---
title: "The Sarkeesian Effect: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "nsdIHK8O5yo"
url: "https://www.youtube.com/watch?v=nsdIHK8O5yo"
duration: "00:06:55"
upload_order: 1
about: "Rebuttal to the documentary The Sarkeesian Effect"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# The Sarkeesian Effect: A Measured Response

Channel: [[hbomberguy]] · Length 00:06:55 · [YouTube](https://www.youtube.com/watch?v=nsdIHK8O5yo)

## What it is

Rebuttal to the documentary The Sarkeesian Effect

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
