---
title: "The Sarkeesian Effect: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "nsdIHK8O5yo"
url: "https://www.youtube.com/watch?v=nsdIHK8O5yo"
duration: "00:06:55"
upload_order: 1
about_ko: "다큐 The Sarkeesian Effect 반박"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# The Sarkeesian Effect: A Measured Response

채널: [[hbomberguy]] · 길이 00:06:55 · [YouTube](https://www.youtube.com/watch?v=nsdIHK8O5yo)

## 어떤 영상인가

다큐 The Sarkeesian Effect 반박

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
