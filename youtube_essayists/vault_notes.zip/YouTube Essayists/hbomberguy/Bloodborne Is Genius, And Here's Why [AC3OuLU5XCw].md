---
title: "Bloodborne Is Genius, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "AC3OuLU5XCw"
url: "https://www.youtube.com/watch?v=AC3OuLU5XCw"
duration: "01:26:40"
upload_order: 24
about: "Why Bloodborne is great"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Bloodborne Is Genius, And Here's Why

Channel: [[hbomberguy]] · Length 01:26:40 · [YouTube](https://www.youtube.com/watch?v=AC3OuLU5XCw)

## What it is

Why Bloodborne is great

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
