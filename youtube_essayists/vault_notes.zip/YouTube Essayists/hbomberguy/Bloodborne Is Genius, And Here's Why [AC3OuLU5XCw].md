---
title: "Bloodborne Is Genius, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "AC3OuLU5XCw"
url: "https://www.youtube.com/watch?v=AC3OuLU5XCw"
duration: "01:26:40"
upload_order: 24
about_ko: "블러드본이 훌륭한 이유"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Bloodborne Is Genius, And Here's Why

채널: [[hbomberguy]] · 길이 01:26:40 · [YouTube](https://www.youtube.com/watch?v=AC3OuLU5XCw)

## 어떤 영상인가

블러드본이 훌륭한 이유

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
