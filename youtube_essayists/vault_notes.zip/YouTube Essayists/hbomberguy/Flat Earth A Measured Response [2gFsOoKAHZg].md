---
title: "Flat Earth: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "2gFsOoKAHZg"
url: "https://www.youtube.com/watch?v=2gFsOoKAHZg"
duration: "00:45:18"
upload_order: 55
about: "Debunking flat earth"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Flat Earth: A Measured Response

Channel: [[hbomberguy]] · Length 00:45:18 · [YouTube](https://www.youtube.com/watch?v=2gFsOoKAHZg)

## What it is

Debunking flat earth

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
