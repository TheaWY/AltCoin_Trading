---
title: "Flat Earth: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "2gFsOoKAHZg"
url: "https://www.youtube.com/watch?v=2gFsOoKAHZg"
duration: "00:45:18"
upload_order: 55
about_ko: "평평한 지구론 반박"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Flat Earth: A Measured Response

채널: [[hbomberguy]] · 길이 00:45:18 · [YouTube](https://www.youtube.com/watch?v=2gFsOoKAHZg)

## 어떤 영상인가

평평한 지구론 반박

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
