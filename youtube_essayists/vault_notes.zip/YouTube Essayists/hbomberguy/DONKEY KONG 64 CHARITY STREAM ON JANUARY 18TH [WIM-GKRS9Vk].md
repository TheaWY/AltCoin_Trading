---
title: "DONKEY KONG 64 CHARITY STREAM ON JANUARY 18TH"
channel: "hbomberguy"
type: "video"
video_id: "WIM-GKRS9Vk"
url: "https://www.youtube.com/watch?v=WIM-GKRS9Vk"
duration: "00:03:28"
upload_order: 56
about_ko: "동키콩 64 자선 방송 공지 (트랜스 청소년 단체 Mermaids 모금)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# DONKEY KONG 64 CHARITY STREAM ON JANUARY 18TH

채널: [[hbomberguy]] · 길이 00:03:28 · [YouTube](https://www.youtube.com/watch?v=WIM-GKRS9Vk)

## 어떤 영상인가

동키콩 64 자선 방송 공지 (트랜스 청소년 단체 Mermaids 모금)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
