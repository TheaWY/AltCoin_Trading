---
title: "DONKEY KONG 64 CHARITY STREAM ON JANUARY 18TH"
channel: "hbomberguy"
type: "video"
video_id: "WIM-GKRS9Vk"
url: "https://www.youtube.com/watch?v=WIM-GKRS9Vk"
duration: "00:03:28"
upload_order: 56
about: "Announcement for a Donkey Kong 64 charity stream (fundraiser for the trans youth charity Mermaids)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# DONKEY KONG 64 CHARITY STREAM ON JANUARY 18TH

Channel: [[hbomberguy]] · Length 00:03:28 · [YouTube](https://www.youtube.com/watch?v=WIM-GKRS9Vk)

## What it is

Announcement for a Donkey Kong 64 charity stream (fundraiser for the trans youth charity Mermaids)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
