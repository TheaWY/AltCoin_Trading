---
title: "Speedrunning Is Awesome, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "I5auJOBC828"
url: "https://www.youtube.com/watch?v=I5auJOBC828"
duration: "00:43:49"
upload_order: 54
about_ko: "스피드런이 멋진 이유"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Speedrunning Is Awesome, And Here's Why

채널: [[hbomberguy]] · 길이 00:43:49 · [YouTube](https://www.youtube.com/watch?v=I5auJOBC828)

## 어떤 영상인가

스피드런이 멋진 이유

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
