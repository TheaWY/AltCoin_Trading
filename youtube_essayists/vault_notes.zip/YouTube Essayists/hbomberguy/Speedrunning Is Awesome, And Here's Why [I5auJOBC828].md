---
title: "Speedrunning Is Awesome, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "I5auJOBC828"
url: "https://www.youtube.com/watch?v=I5auJOBC828"
duration: "00:43:49"
upload_order: 54
about: "Why speedrunning is great"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Speedrunning Is Awesome, And Here's Why

Channel: [[hbomberguy]] · Length 00:43:49 · [YouTube](https://www.youtube.com/watch?v=I5auJOBC828)

## What it is

Why speedrunning is great

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
