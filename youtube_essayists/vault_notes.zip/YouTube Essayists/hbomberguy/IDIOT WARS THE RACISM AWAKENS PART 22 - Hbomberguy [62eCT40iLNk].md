---
title: "IDIOT WARS: THE RACISM AWAKENS [PART 2/2] - Hbomberguy"
channel: "hbomberguy"
type: "video"
video_id: "62eCT40iLNk"
url: "https://www.youtube.com/watch?v=62eCT40iLNk"
duration: "00:15:29"
upload_order: 5
about_ko: "스타워즈 깨어난 포스 보이콧 논란 2부"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# IDIOT WARS: THE RACISM AWAKENS [PART 2/2] - Hbomberguy

채널: [[hbomberguy]] · 길이 00:15:29 · [YouTube](https://www.youtube.com/watch?v=62eCT40iLNk)

## 어떤 영상인가

스타워즈 깨어난 포스 보이콧 논란 2부

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
