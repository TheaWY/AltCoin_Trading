---
title: "IDIOT WARS: THE RACISM AWAKENS [PART 2/2] - Hbomberguy"
channel: "hbomberguy"
type: "video"
video_id: "62eCT40iLNk"
url: "https://www.youtube.com/watch?v=62eCT40iLNk"
duration: "00:15:29"
upload_order: 5
about: "The Force Awakens boycott controversy, part 2"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# IDIOT WARS: THE RACISM AWAKENS [PART 2/2] - Hbomberguy

Channel: [[hbomberguy]] · Length 00:15:29 · [YouTube](https://www.youtube.com/watch?v=62eCT40iLNk)

## What it is

The Force Awakens boycott controversy, part 2

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
