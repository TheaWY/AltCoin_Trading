---
title: "SOY BOYS: A MEASURED RESPONSE"
channel: "hbomberguy"
type: "video"
video_id: "C8dfiDeJeDU"
url: "https://www.youtube.com/watch?v=C8dfiDeJeDU"
duration: "00:31:02"
upload_order: 48
about: "Debunking the \"soy boy\" narrative"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# SOY BOYS: A MEASURED RESPONSE

Channel: [[hbomberguy]] · Length 00:31:02 · [YouTube](https://www.youtube.com/watch?v=C8dfiDeJeDU)

## What it is

Debunking the "soy boy" narrative

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
