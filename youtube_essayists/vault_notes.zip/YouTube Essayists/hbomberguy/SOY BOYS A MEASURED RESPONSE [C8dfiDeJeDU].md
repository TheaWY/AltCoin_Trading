---
title: "SOY BOYS: A MEASURED RESPONSE"
channel: "hbomberguy"
type: "video"
video_id: "C8dfiDeJeDU"
url: "https://www.youtube.com/watch?v=C8dfiDeJeDU"
duration: "00:31:02"
upload_order: 48
about_ko: "'소이 보이' 담론 반박"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# SOY BOYS: A MEASURED RESPONSE

채널: [[hbomberguy]] · 길이 00:31:02 · [YouTube](https://www.youtube.com/watch?v=C8dfiDeJeDU)

## 어떤 영상인가

'소이 보이' 담론 반박

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
