---
title: "The Sierra Effect: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "4UyPV2Fj4lk"
url: "https://www.youtube.com/watch?v=4UyPV2Fj4lk"
duration: "00:10:53"
upload_order: 8
about: "Rebuttal to The Sierra Effect"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# The Sierra Effect: A Measured Response

Channel: [[hbomberguy]] · Length 00:10:53 · [YouTube](https://www.youtube.com/watch?v=4UyPV2Fj4lk)

## What it is

Rebuttal to The Sierra Effect

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
