---
title: "Soy Boy Diet Aftermath"
channel: "hbomberguy"
type: "video"
video_id: "XYXkHIsslD0"
url: "https://www.youtube.com/watch?v=XYXkHIsslD0"
duration: "00:21:43"
upload_order: 49
about_ko: "소이 보이 다이어트 후기"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Soy Boy Diet Aftermath

채널: [[hbomberguy]] · 길이 00:21:43 · [YouTube](https://www.youtube.com/watch?v=XYXkHIsslD0)

## 어떤 영상인가

소이 보이 다이어트 후기

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
