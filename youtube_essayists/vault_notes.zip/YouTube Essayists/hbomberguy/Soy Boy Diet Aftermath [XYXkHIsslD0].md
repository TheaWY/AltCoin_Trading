---
title: "Soy Boy Diet Aftermath"
channel: "hbomberguy"
type: "video"
video_id: "XYXkHIsslD0"
url: "https://www.youtube.com/watch?v=XYXkHIsslD0"
duration: "00:21:43"
upload_order: 49
about: "Aftermath of the soy boy diet"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Soy Boy Diet Aftermath

Channel: [[hbomberguy]] · Length 00:21:43 · [YouTube](https://www.youtube.com/watch?v=XYXkHIsslD0)

## What it is

Aftermath of the soy boy diet

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
