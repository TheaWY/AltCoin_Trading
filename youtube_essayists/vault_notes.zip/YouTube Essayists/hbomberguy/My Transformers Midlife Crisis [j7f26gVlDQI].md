---
title: "My Transformers Midlife Crisis"
channel: "hbomberguy"
type: "video"
video_id: "j7f26gVlDQI"
url: "https://www.youtube.com/watch?v=j7f26gVlDQI"
duration: "00:45:56"
upload_order: 59
about_ko: "트랜스포머에 대한 중년의 위기 에세이"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# My Transformers Midlife Crisis

채널: [[hbomberguy]] · 길이 00:45:56 · [YouTube](https://www.youtube.com/watch?v=j7f26gVlDQI)

## 어떤 영상인가

트랜스포머에 대한 중년의 위기 에세이

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
