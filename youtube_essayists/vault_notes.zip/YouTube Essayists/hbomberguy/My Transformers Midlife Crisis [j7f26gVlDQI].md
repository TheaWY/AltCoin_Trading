---
title: "My Transformers Midlife Crisis"
channel: "hbomberguy"
type: "video"
video_id: "j7f26gVlDQI"
url: "https://www.youtube.com/watch?v=j7f26gVlDQI"
duration: "00:45:56"
upload_order: 59
about: "A midlife-crisis essay about Transformers"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# My Transformers Midlife Crisis

Channel: [[hbomberguy]] · Length 00:45:56 · [YouTube](https://www.youtube.com/watch?v=j7f26gVlDQI)

## What it is

A midlife-crisis essay about Transformers

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
