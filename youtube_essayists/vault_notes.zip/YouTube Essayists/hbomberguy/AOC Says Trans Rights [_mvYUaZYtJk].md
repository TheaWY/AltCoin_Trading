---
title: "AOC Says Trans Rights"
channel: "hbomberguy"
type: "video"
video_id: "_mvYUaZYtJk"
url: "https://www.youtube.com/watch?v=_mvYUaZYtJk"
duration: "00:11:32"
upload_order: 57
about_ko: "AOC와 트랜스 권리에 대한 짧은 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# AOC Says Trans Rights

채널: [[hbomberguy]] · 길이 00:11:32 · [YouTube](https://www.youtube.com/watch?v=_mvYUaZYtJk)

## 어떤 영상인가

AOC와 트랜스 권리에 대한 짧은 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
