---
title: "AOC Says Trans Rights"
channel: "hbomberguy"
type: "video"
video_id: "_mvYUaZYtJk"
url: "https://www.youtube.com/watch?v=_mvYUaZYtJk"
duration: "00:11:32"
upload_order: 57
about: "Short video on AOC and trans rights"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# AOC Says Trans Rights

Channel: [[hbomberguy]] · Length 00:11:32 · [YouTube](https://www.youtube.com/watch?v=_mvYUaZYtJk)

## What it is

Short video on AOC and trans rights

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
