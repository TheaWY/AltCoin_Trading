---
title: "SERIOUS SONIC LORE ANALYSIS"
channel: "hbomberguy"
type: "video"
video_id: "3Oco4WYRdaU"
url: "https://www.youtube.com/watch?v=3Oco4WYRdaU"
duration: "00:11:07"
upload_order: 21
about: "Comedy \"serious\" Sonic lore analysis"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# SERIOUS SONIC LORE ANALYSIS

Channel: [[hbomberguy]] · Length 00:11:07 · [YouTube](https://www.youtube.com/watch?v=3Oco4WYRdaU)

## What it is

Comedy "serious" Sonic lore analysis

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
