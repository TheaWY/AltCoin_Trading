---
title: "SERIOUS SONIC LORE ANALYSIS"
channel: "hbomberguy"
type: "video"
video_id: "3Oco4WYRdaU"
url: "https://www.youtube.com/watch?v=3Oco4WYRdaU"
duration: "00:11:07"
upload_order: 21
about_ko: "소닉 '진지한' 설정 분석(코미디)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# SERIOUS SONIC LORE ANALYSIS

채널: [[hbomberguy]] · 길이 00:11:07 · [YouTube](https://www.youtube.com/watch?v=3Oco4WYRdaU)

## 어떤 영상인가

소닉 '진지한' 설정 분석(코미디)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
