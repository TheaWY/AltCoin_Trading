---
title: "Halcyon Dreams: The Legacy of Dragon's Lair"
channel: "hbomberguy"
type: "video"
video_id: "CnPOQr1pxY8"
url: "https://www.youtube.com/watch?v=CnPOQr1pxY8"
duration: "00:43:17"
upload_order: 45
about: "The influence of the game Dragon's Lair"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Halcyon Dreams: The Legacy of Dragon's Lair

Channel: [[hbomberguy]] · Length 00:43:17 · [YouTube](https://www.youtube.com/watch?v=CnPOQr1pxY8)

## What it is

The influence of the game Dragon's Lair

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
