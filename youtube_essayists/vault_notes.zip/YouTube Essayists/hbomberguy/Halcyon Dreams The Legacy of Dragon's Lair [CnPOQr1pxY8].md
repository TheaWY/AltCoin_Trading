---
title: "Halcyon Dreams: The Legacy of Dragon's Lair"
channel: "hbomberguy"
type: "video"
video_id: "CnPOQr1pxY8"
url: "https://www.youtube.com/watch?v=CnPOQr1pxY8"
duration: "00:43:17"
upload_order: 45
about_ko: "게임 Dragon's Lair의 유산"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Halcyon Dreams: The Legacy of Dragon's Lair

채널: [[hbomberguy]] · 길이 00:43:17 · [YouTube](https://www.youtube.com/watch?v=CnPOQr1pxY8)

## 어떤 영상인가

게임 Dragon's Lair의 유산

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
