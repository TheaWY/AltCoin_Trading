---
title: "Sherlock Is Garbage, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "LkoGBOs5ecM"
url: "https://www.youtube.com/watch?v=LkoGBOs5ecM"
duration: "01:49:53"
upload_order: 36
about_ko: "드라마 셜록이 별로인 이유"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Sherlock Is Garbage, And Here's Why

채널: [[hbomberguy]] · 길이 01:49:53 · [YouTube](https://www.youtube.com/watch?v=LkoGBOs5ecM)

## 어떤 영상인가

드라마 셜록이 별로인 이유

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
