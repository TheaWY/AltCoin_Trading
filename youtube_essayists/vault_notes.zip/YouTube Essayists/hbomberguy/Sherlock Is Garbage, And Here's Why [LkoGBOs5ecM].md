---
title: "Sherlock Is Garbage, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "LkoGBOs5ecM"
url: "https://www.youtube.com/watch?v=LkoGBOs5ecM"
duration: "01:49:53"
upload_order: 36
about: "Why the TV show Sherlock is bad"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Sherlock Is Garbage, And Here's Why

Channel: [[hbomberguy]] · Length 01:49:53 · [YouTube](https://www.youtube.com/watch?v=LkoGBOs5ecM)

## What it is

Why the TV show Sherlock is bad

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
