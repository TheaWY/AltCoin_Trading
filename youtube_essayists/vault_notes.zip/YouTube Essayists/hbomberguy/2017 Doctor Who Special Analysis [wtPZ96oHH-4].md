---
title: "2017 Doctor Who Special Analysis"
channel: "hbomberguy"
type: "video"
video_id: "wtPZ96oHH-4"
url: "https://www.youtube.com/watch?v=wtPZ96oHH-4"
duration: "00:26:45"
upload_order: 47
about_ko: "닥터 후 2017 스페셜 분석"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# 2017 Doctor Who Special Analysis

채널: [[hbomberguy]] · 길이 00:26:45 · [YouTube](https://www.youtube.com/watch?v=wtPZ96oHH-4)

## 어떤 영상인가

닥터 후 2017 스페셜 분석

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
