---
title: "2017 Doctor Who Special Analysis"
channel: "hbomberguy"
type: "video"
video_id: "wtPZ96oHH-4"
url: "https://www.youtube.com/watch?v=wtPZ96oHH-4"
duration: "00:26:45"
upload_order: 47
about: "Analysis of the 2017 Doctor Who special"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# 2017 Doctor Who Special Analysis

Channel: [[hbomberguy]] · Length 00:26:45 · [YouTube](https://www.youtube.com/watch?v=wtPZ96oHH-4)

## What it is

Analysis of the 2017 Doctor Who special

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
