---
title: "Deus Ex: Human Revolution is FINE, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "bgJazjz9ZsA"
url: "https://www.youtube.com/watch?v=bgJazjz9ZsA"
duration: "03:33:34"
upload_order: 67
about: "Long analysis of Deus Ex: Human Revolution"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Deus Ex: Human Revolution is FINE, And Here's Why

Channel: [[hbomberguy]] · Length 03:33:34 · [YouTube](https://www.youtube.com/watch?v=bgJazjz9ZsA)

## What it is

Long analysis of Deus Ex: Human Revolution

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
