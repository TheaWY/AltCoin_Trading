---
title: "Deus Ex: Human Revolution is FINE, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "bgJazjz9ZsA"
url: "https://www.youtube.com/watch?v=bgJazjz9ZsA"
duration: "03:33:34"
upload_order: 67
about_ko: "데우스 엑스: 휴먼 레볼루션을 장시간 분석"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Deus Ex: Human Revolution is FINE, And Here's Why

채널: [[hbomberguy]] · 길이 03:33:34 · [YouTube](https://www.youtube.com/watch?v=bgJazjz9ZsA)

## 어떤 영상인가

데우스 엑스: 휴먼 레볼루션을 장시간 분석

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
