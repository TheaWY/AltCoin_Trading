---
title: "HBOMB'S GOTY 2016 LIST"
channel: "hbomberguy"
type: "video"
video_id: "JwYLTJelJ0k"
url: "https://www.youtube.com/watch?v=JwYLTJelJ0k"
duration: "00:20:23"
upload_order: 28
about_ko: "2016 올해의 게임 목록"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# HBOMB'S GOTY 2016 LIST

채널: [[hbomberguy]] · 길이 00:20:23 · [YouTube](https://www.youtube.com/watch?v=JwYLTJelJ0k)

## 어떤 영상인가

2016 올해의 게임 목록

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
