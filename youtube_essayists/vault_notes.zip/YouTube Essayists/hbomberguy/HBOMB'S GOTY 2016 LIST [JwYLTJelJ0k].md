---
title: "HBOMB'S GOTY 2016 LIST"
channel: "hbomberguy"
type: "video"
video_id: "JwYLTJelJ0k"
url: "https://www.youtube.com/watch?v=JwYLTJelJ0k"
duration: "00:20:23"
upload_order: 28
about: "His game of the year list for 2016"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# HBOMB'S GOTY 2016 LIST

Channel: [[hbomberguy]] · Length 00:20:23 · [YouTube](https://www.youtube.com/watch?v=JwYLTJelJ0k)

## What it is

His game of the year list for 2016

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
