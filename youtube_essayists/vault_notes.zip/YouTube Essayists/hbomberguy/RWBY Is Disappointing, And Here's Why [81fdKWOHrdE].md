---
title: "RWBY Is Disappointing, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "81fdKWOHrdE"
url: "https://www.youtube.com/watch?v=81fdKWOHrdE"
duration: "02:27:25"
upload_order: 63
about_ko: "애니메이션 RWBY가 실망스러운 이유"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# RWBY Is Disappointing, And Here's Why

채널: [[hbomberguy]] · 길이 02:27:25 · [YouTube](https://www.youtube.com/watch?v=81fdKWOHrdE)

## 어떤 영상인가

애니메이션 RWBY가 실망스러운 이유

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
