---
title: "RWBY Is Disappointing, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "81fdKWOHrdE"
url: "https://www.youtube.com/watch?v=81fdKWOHrdE"
duration: "02:27:25"
upload_order: 63
about: "Why the animated series RWBY disappoints"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# RWBY Is Disappointing, And Here's Why

Channel: [[hbomberguy]] · Length 02:27:25 · [YouTube](https://www.youtube.com/watch?v=81fdKWOHrdE)

## What it is

Why the animated series RWBY disappoints

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
