---
title: "THE SOY BOY DIET"
channel: "hbomberguy"
type: "video"
video_id: "5MS0TrsI7rE"
url: "https://www.youtube.com/watch?v=5MS0TrsI7rE"
duration: "00:09:33"
upload_order: 46
about: "Trying the soy boy diet"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# THE SOY BOY DIET

Channel: [[hbomberguy]] · Length 00:09:33 · [YouTube](https://www.youtube.com/watch?v=5MS0TrsI7rE)

## What it is

Trying the soy boy diet

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
