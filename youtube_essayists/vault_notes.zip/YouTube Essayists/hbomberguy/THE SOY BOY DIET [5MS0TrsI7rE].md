---
title: "THE SOY BOY DIET"
channel: "hbomberguy"
type: "video"
video_id: "5MS0TrsI7rE"
url: "https://www.youtube.com/watch?v=5MS0TrsI7rE"
duration: "00:09:33"
upload_order: 46
about_ko: "소이 보이 다이어트 도전"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# THE SOY BOY DIET

채널: [[hbomberguy]] · 길이 00:09:33 · [YouTube](https://www.youtube.com/watch?v=5MS0TrsI7rE)

## 어떤 영상인가

소이 보이 다이어트 도전

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
