---
title: "Antifeminism VS FACTS"
channel: "hbomberguy"
type: "video"
video_id: "rc24YtUslCU"
url: "https://www.youtube.com/watch?v=rc24YtUslCU"
duration: "00:17:11"
upload_order: 14
about_ko: "반페미니즘 주장 대 사실"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Antifeminism VS FACTS

채널: [[hbomberguy]] · 길이 00:17:11 · [YouTube](https://www.youtube.com/watch?v=rc24YtUslCU)

## 어떤 영상인가

반페미니즘 주장 대 사실

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
