---
title: "Antifeminism VS FACTS"
channel: "hbomberguy"
type: "video"
video_id: "rc24YtUslCU"
url: "https://www.youtube.com/watch?v=rc24YtUslCU"
duration: "00:17:11"
upload_order: 14
about: "Antifeminist claims checked against facts"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Antifeminism VS FACTS

Channel: [[hbomberguy]] · Length 00:17:11 · [YouTube](https://www.youtube.com/watch?v=rc24YtUslCU)

## What it is

Antifeminist claims checked against facts

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
