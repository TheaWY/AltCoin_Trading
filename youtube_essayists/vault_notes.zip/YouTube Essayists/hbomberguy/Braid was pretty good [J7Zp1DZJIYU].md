---
title: "Braid was pretty good"
channel: "hbomberguy"
type: "video"
video_id: "J7Zp1DZJIYU"
url: "https://www.youtube.com/watch?v=J7Zp1DZJIYU"
duration: "00:13:34"
upload_order: 6
about_ko: "게임 Braid 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Braid was pretty good

채널: [[hbomberguy]] · 길이 00:13:34 · [YouTube](https://www.youtube.com/watch?v=J7Zp1DZJIYU)

## 어떤 영상인가

게임 Braid 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
