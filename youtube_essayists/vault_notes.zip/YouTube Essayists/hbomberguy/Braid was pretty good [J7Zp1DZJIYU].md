---
title: "Braid was pretty good"
channel: "hbomberguy"
type: "video"
video_id: "J7Zp1DZJIYU"
url: "https://www.youtube.com/watch?v=J7Zp1DZJIYU"
duration: "00:13:34"
upload_order: 6
about: "Review of the game Braid"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Braid was pretty good

Channel: [[hbomberguy]] · Length 00:13:34 · [YouTube](https://www.youtube.com/watch?v=J7Zp1DZJIYU)

## What it is

Review of the game Braid

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
