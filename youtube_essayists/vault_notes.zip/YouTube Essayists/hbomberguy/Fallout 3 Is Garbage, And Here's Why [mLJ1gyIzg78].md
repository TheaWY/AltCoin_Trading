---
title: "Fallout 3 Is Garbage, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "mLJ1gyIzg78"
url: "https://www.youtube.com/watch?v=mLJ1gyIzg78"
duration: "01:29:37"
upload_order: 11
about_ko: "폴아웃 3가 별로인 이유"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Fallout 3 Is Garbage, And Here's Why

채널: [[hbomberguy]] · 길이 01:29:37 · [YouTube](https://www.youtube.com/watch?v=mLJ1gyIzg78)

## 어떤 영상인가

폴아웃 3가 별로인 이유

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
