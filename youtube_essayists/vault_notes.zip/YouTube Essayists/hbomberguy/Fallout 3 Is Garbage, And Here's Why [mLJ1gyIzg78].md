---
title: "Fallout 3 Is Garbage, And Here's Why"
channel: "hbomberguy"
type: "video"
video_id: "mLJ1gyIzg78"
url: "https://www.youtube.com/watch?v=mLJ1gyIzg78"
duration: "01:29:37"
upload_order: 11
about: "Why Fallout 3 is bad"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Fallout 3 Is Garbage, And Here's Why

Channel: [[hbomberguy]] · Length 01:29:37 · [YouTube](https://www.youtube.com/watch?v=mLJ1gyIzg78)

## What it is

Why Fallout 3 is bad

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
