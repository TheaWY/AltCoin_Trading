---
title: "How Should I Vote In The EU Referendum?"
channel: "hbomberguy"
type: "video"
video_id: "RgVIQWItFE8"
url: "https://www.youtube.com/watch?v=RgVIQWItFE8"
duration: "00:10:28"
upload_order: 15
about: "Voting guide for the Brexit referendum"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# How Should I Vote In The EU Referendum?

Channel: [[hbomberguy]] · Length 00:10:28 · [YouTube](https://www.youtube.com/watch?v=RgVIQWItFE8)

## What it is

Voting guide for the Brexit referendum

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
