---
title: "PewDiePie Is A Nazi"
channel: "hbomberguy"
type: "video"
video_id: "GjNILjFters"
url: "https://www.youtube.com/watch?v=GjNILjFters"
duration: "00:14:18"
upload_order: 32
about: "Video on the PewDiePie controversy"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# PewDiePie Is A Nazi

Channel: [[hbomberguy]] · Length 00:14:18 · [YouTube](https://www.youtube.com/watch?v=GjNILjFters)

## What it is

Video on the PewDiePie controversy

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
