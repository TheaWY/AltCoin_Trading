---
title: "PewDiePie Is A Nazi"
channel: "hbomberguy"
type: "video"
video_id: "GjNILjFters"
url: "https://www.youtube.com/watch?v=GjNILjFters"
duration: "00:14:18"
upload_order: 32
about_ko: "퓨디파이 논란에 대한 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# PewDiePie Is A Nazi

채널: [[hbomberguy]] · 길이 00:14:18 · [YouTube](https://www.youtube.com/watch?v=GjNILjFters)

## 어떤 영상인가

퓨디파이 논란에 대한 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
