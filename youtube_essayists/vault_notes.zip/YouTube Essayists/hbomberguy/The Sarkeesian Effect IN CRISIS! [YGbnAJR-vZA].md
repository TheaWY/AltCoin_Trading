---
title: "The Sarkeesian Effect: IN CRISIS!"
channel: "hbomberguy"
type: "video"
video_id: "YGbnAJR-vZA"
url: "https://www.youtube.com/watch?v=YGbnAJR-vZA"
duration: "00:08:54"
upload_order: 2
about: "Follow-up rebuttal to the documentary The Sarkeesian Effect"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# The Sarkeesian Effect: IN CRISIS!

Channel: [[hbomberguy]] · Length 00:08:54 · [YouTube](https://www.youtube.com/watch?v=YGbnAJR-vZA)

## What it is

Follow-up rebuttal to the documentary The Sarkeesian Effect

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
