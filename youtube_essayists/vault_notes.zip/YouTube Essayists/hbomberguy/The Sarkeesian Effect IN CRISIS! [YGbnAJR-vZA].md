---
title: "The Sarkeesian Effect: IN CRISIS!"
channel: "hbomberguy"
type: "video"
video_id: "YGbnAJR-vZA"
url: "https://www.youtube.com/watch?v=YGbnAJR-vZA"
duration: "00:08:54"
upload_order: 2
about_ko: "다큐 The Sarkeesian Effect 후속 반박"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# The Sarkeesian Effect: IN CRISIS!

채널: [[hbomberguy]] · 길이 00:08:54 · [YouTube](https://www.youtube.com/watch?v=YGbnAJR-vZA)

## 어떤 영상인가

다큐 The Sarkeesian Effect 후속 반박

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
