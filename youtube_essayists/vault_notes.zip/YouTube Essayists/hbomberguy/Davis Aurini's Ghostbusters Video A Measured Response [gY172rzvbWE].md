---
title: "Davis Aurini's Ghostbusters Video: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "gY172rzvbWE"
url: "https://www.youtube.com/watch?v=gY172rzvbWE"
duration: "00:16:27"
upload_order: 12
about: "Rebuttal to Davis Aurini's Ghostbusters video"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Davis Aurini's Ghostbusters Video: A Measured Response

Channel: [[hbomberguy]] · Length 00:16:27 · [YouTube](https://www.youtube.com/watch?v=gY172rzvbWE)

## What it is

Rebuttal to Davis Aurini's Ghostbusters video

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
