---
title: "Davis Aurini's Ghostbusters Video: A Measured Response"
channel: "hbomberguy"
type: "video"
video_id: "gY172rzvbWE"
url: "https://www.youtube.com/watch?v=gY172rzvbWE"
duration: "00:16:27"
upload_order: 12
about_ko: "Davis Aurini의 고스트버스터즈 영상 반박"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Davis Aurini's Ghostbusters Video: A Measured Response

채널: [[hbomberguy]] · 길이 00:16:27 · [YouTube](https://www.youtube.com/watch?v=gY172rzvbWE)

## 어떤 영상인가

Davis Aurini의 고스트버스터즈 영상 반박

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
