---
title: "BUTT GATE"
channel: "hbomberguy"
type: "video"
video_id: "Ozf2hwEOWHE"
url: "https://www.youtube.com/watch?v=Ozf2hwEOWHE"
duration: "00:02:12"
upload_order: 10
about_ko: "짧은 코미디 영상(제목 기준)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# BUTT GATE

채널: [[hbomberguy]] · 길이 00:02:12 · [YouTube](https://www.youtube.com/watch?v=Ozf2hwEOWHE)

## 어떤 영상인가

짧은 코미디 영상(제목 기준)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
