---
title: "BUTT GATE"
channel: "hbomberguy"
type: "video"
video_id: "Ozf2hwEOWHE"
url: "https://www.youtube.com/watch?v=Ozf2hwEOWHE"
duration: "00:02:12"
upload_order: 10
about: "Short comedy video (guessed from title)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# BUTT GATE

Channel: [[hbomberguy]] · Length 00:02:12 · [YouTube](https://www.youtube.com/watch?v=Ozf2hwEOWHE)

## What it is

Short comedy video (guessed from title)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
