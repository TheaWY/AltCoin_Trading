# hbomberguy

영상 69개

| # | 영상 | 길이 | 어떤 영상인가 |
|---|---|---|---|
| 69 | [[Plagiarism and You(Tube) [yDp3cB5fHXQ]\|Plagiarism and You(Tube)]] | 03:51:10 | 유튜브 표절(제임스 소머턴 등)을 고발한 4시간 다큐. 채널 대표작 |
| 68 | [[ROBLOX_OOF.mp3 [0twDETh6QaI]\|ROBLOX_OOF.mp3]] | 01:57:49 | 로블록스 'oof' 효과음의 출처와 저작권 문제 추적 |
| 67 | [[Deus Ex Human Revolution is FINE, And Here's Why [bgJazjz9ZsA]\|Deus Ex: Human Revolution is FINE, And Here's Why]] | 03:33:34 | 데우스 엑스: 휴먼 레볼루션을 장시간 분석 |
| 66 | [[Vaccines and Autism A Measured Response [8BIcAZxFfrc]\|Vaccines and Autism: A Measured Response]] | 01:44:10 | 백신-자폐 연관설을 반박하는 장편 |
| 65 | [[The War on Christmas A Measured Response [jbZo4x0NbbI]\|The War on Christmas: A Measured Response]] | 00:53:58 | '크리스마스와의 전쟁' 담론 반박 |
| 64 | [[Fallout New Vegas Is Genius, And Here's Why [gzF7aHxk4Y4]\|Fallout: New Vegas Is Genius, And Here's Why]] | 01:37:42 | 폴아웃: 뉴 베가스가 훌륭한 이유 |
| 63 | [[RWBY Is Disappointing, And Here's Why [81fdKWOHrdE]\|RWBY Is Disappointing, And Here's Why]] | 02:27:25 | 애니메이션 RWBY가 실망스러운 이유 |
| 62 | [[Pathologic is Genius, And Here's Why [JsNm2YLrk30]\|Pathologic is Genius, And Here's Why]] | 02:10:52 | 게임 Pathologic이 천재적인 이유 |
| 61 | [[Weighing the Value of Director's Cuts  Scanline [D6OT77T7YlE]\|Weighing the Value of Director's Cuts / Scanline]] | 00:49:07 | 감독판의 가치 분석 (Scanline) |
| 60 | [[Climate Denial A Measured Response [RLqXkYrdmjY]\|Climate Denial: A Measured Response]] | 00:41:20 | 기후 변화 부정론 반박 |
| 59 | [[My Transformers Midlife Crisis [j7f26gVlDQI]\|My Transformers Midlife Crisis]] | 00:45:56 | 트랜스포머에 대한 중년의 위기 에세이 |
| 58 | [[WOKE BRANDS [06yy88tLWlg]\|WOKE BRANDS]] | 00:26:44 | '깨어있는' 기업 마케팅 비판 |
| 57 | [[AOC Says Trans Rights [_mvYUaZYtJk]\|AOC Says Trans Rights]] | 00:11:32 | AOC와 트랜스 권리에 대한 짧은 영상 |
| 56 | [[DONKEY KONG 64 CHARITY STREAM ON JANUARY 18TH [WIM-GKRS9Vk]\|DONKEY KONG 64 CHARITY STREAM ON JANUARY 18TH]] | 00:03:28 | 동키콩 64 자선 방송 공지 (트랜스 청소년 단체 Mermaids 모금) |
| 55 | [[Flat Earth A Measured Response [2gFsOoKAHZg]\|Flat Earth: A Measured Response]] | 00:45:18 | 평평한 지구론 반박 |
| 54 | [[Speedrunning Is Awesome, And Here's Why [I5auJOBC828]\|Speedrunning Is Awesome, And Here's Why]] | 00:43:49 | 스피드런이 멋진 이유 |
| 53 | [[Outsiders How To Adapt H.P. Lovecraft In the 21st Century [l8u8wZ0WvxI]\|Outsiders: How To Adapt H.P. Lovecraft In the 21st Century]] | 00:33:26 | 21세기에 러브크래프트를 각색하는 법(Outsiders) |
| 52 | [[CTRL+ALT+DEL  SLA3 [TebCHHCw9rY]\|CTRL+ALT+DEL / SLA:3]] | 00:34:11 | 웹코믹 CTRL+ALT+DEL 비평 |
| 51 | [[Skyrim is Garbage, And Here's Why [WYwpEzBvulA]\|Skyrim is Garbage, And Here's Why]] | 00:40:17 | 스카이림이 별로인 이유 |
| 50 | [[Nice Try, Paul [JOp28hQb_Xw]\|Nice Try, Paul]] | 00:07:06 | 폴(Paul Joseph Watson) 반박 짧은 영상 |
| 49 | [[Soy Boy Diet Aftermath [XYXkHIsslD0]\|Soy Boy Diet Aftermath]] | 00:21:43 | 소이 보이 다이어트 후기 |
| 48 | [[SOY BOYS A MEASURED RESPONSE [C8dfiDeJeDU]\|SOY BOYS: A MEASURED RESPONSE]] | 00:31:02 | '소이 보이' 담론 반박 |
| 47 | [[2017 Doctor Who Special Analysis [wtPZ96oHH-4]\|2017 Doctor Who Special Analysis]] | 00:26:45 | 닥터 후 2017 스페셜 분석 |
| 46 | [[THE SOY BOY DIET [5MS0TrsI7rE]\|THE SOY BOY DIET]] | 00:09:33 | 소이 보이 다이어트 도전 |
| 45 | [[Halcyon Dreams The Legacy of Dragon's Lair [CnPOQr1pxY8]\|Halcyon Dreams: The Legacy of Dragon's Lair]] | 00:43:17 | 게임 Dragon's Lair의 유산 |
| 44 | [[Hbomberguy's 100K Q&A! [5-qccQbgH6I]\|Hbomberguy's 100K Q&A!]] | 00:36:23 | 구독자 10만 기념 Q&A |
| 43 | [[The Power Of VHS  SCANLINE [xbZMqS-fW-8]\|The Power Of VHS / SCANLINE]] | 00:29:21 | VHS의 힘 (Scanline) |
| 42 | [[Bill Nye VS Pseudoscience (Part Two!)  Measured Response [LqYgjGDaMYg]\|Bill Nye VS Pseudoscience (Part Two!) / Measured Response]] | 00:55:50 | 빌 나이 대 사이비과학 2부 |
| 41 | [[Doomfist In-Depth Analysis & Review [YpdY8eMwjZ8]\|Doomfist In-Depth Analysis & Review]] | 00:10:11 | 오버워치 둠피스트 분석(코미디) |
| 40 | [[Lisa The Analysis [t-5_zoEsY6c]\|Lisa: The Analysis]] | 00:40:51 | 게임 LISA 분석 |
| 39 | [[Here's Three Stories About YouTube Plagiarism [ZDtJ7bte_zg]\|Here's Three Stories About YouTube Plagiarism]] | 00:17:12 | 유튜브 표절 사례 세 가지 |
| 38 | [[Measured Response Bill Nye VS Pseudoscience (Part One) [dklVypazQsA]\|Measured Response: Bill Nye VS Pseudoscience (Part One)]] | 00:35:05 | 빌 나이 대 사이비과학 1부 |
| 37 | [[ELECTIONWATCH 2017 [dVbC0jASJYA]\|ELECTIONWATCH 2017]] | 00:28:00 | 2017 영국 총선 영상 |
| 36 | [[Sherlock Is Garbage, And Here's Why [LkoGBOs5ecM]\|Sherlock Is Garbage, And Here's Why]] | 01:49:53 | 드라마 셜록이 별로인 이유 |
| 35 | [[What Modern Games Can Learn From Yooka-Laylee [P2mGHeCAJOs]\|What Modern Games Can Learn From Yooka-Laylee]] | 00:13:53 | 현대 게임이 Yooka-Laylee에서 배울 점 |
| 34 | [[In Defense of Dark Souls 2 [SRTfcMeqhig]\|In Defense of Dark Souls 2]] | 01:19:44 | 다크 소울 2 옹호 |
| 33 | [[Pick Up Artistry A Measured Response [_pEfhgG3Ocw]\|Pick Up Artistry: A Measured Response]] | 00:29:14 | 픽업 아티스트 담론 반박 |
| 32 | [[PewDiePie Is A Nazi [GjNILjFters]\|PewDiePie Is A Nazi]] | 00:14:18 | 퓨디파이 논란에 대한 영상 |
| 31 | [[FreeSargon A Measured Response [aL_vIqMiHK0]\|#FreeSargon: A Measured Response]] | 00:09:50 | #FreeSargon 해시태그 반박 |
| 30 | [[Why Is New Donk City Uncanny - SERIOUS LORE ANALYSIS [5_IT0C7bm2s]\|Why Is New Donk City Uncanny? - SERIOUS LORE ANALYSIS]] | 00:15:21 | 마리오 오디세이 뉴 동크 시티가 불쾌한 이유(코미디 분석) |
| 29 | [[Bethesda VS Critics How To Save The Games Industry [C6NiXAdMzEk]\|Bethesda VS Critics: How To Save The Games Industry]] | 00:22:23 | 베데스다와 비평가, 게임 산업 이야기 |
| 28 | [[HBOMB'S GOTY 2016 LIST [JwYLTJelJ0k]\|HBOMB'S GOTY 2016 LIST]] | 00:20:23 | 2016 올해의 게임 목록 |
| 27 | [[The Golden One A Measured Response [Ahuj1B0ow4U]\|The Golden One: A Measured Response]] | 00:22:55 | 유튜버 The Golden One 반박 |
| 26 | [[Stan Lee Owns [RmLFGWAyajU]\|Stan Lee Owns]] | 00:03:31 | 스탠 리 짧은 영상 |
| 25 | [[The Killing Joke Movie and The Problem With Comics [4xRDiUD1a8c]\|The Killing Joke Movie and The Problem With Comics]] | 00:16:26 | 킬링 조크 애니메이션과 코믹스의 문제 |
| 24 | [[Bloodborne Is Genius, And Here's Why [AC3OuLU5XCw]\|Bloodborne Is Genius, And Here's Why]] | 01:26:40 | 블러드본이 훌륭한 이유 |
| 23 | [[Second Look At Nintendo Switch [g43NZSmY6-8]\|Second Look At Nintendo Switch]] | 00:03:30 | 닌텐도 스위치 재평가 |
| 22 | [[I Filmed Myself Watching The Alt Right Dogs Trailer [1t_Bs-8L4Mo]\|I Filmed Myself Watching The Alt Right Dogs Trailer]] | 00:15:02 | 대안우파 다큐 예고편을 보며 촬영한 반응 |
| 21 | [[SERIOUS SONIC LORE ANALYSIS [3Oco4WYRdaU]\|SERIOUS SONIC LORE ANALYSIS]] | 00:11:07 | 소닉 '진지한' 설정 분석(코미디) |
| 20 | [[THE NO MAN'S SKY RANT EPILEPSY WARNING [4DhaUe6y-Co]\|THE NO MAN'S SKY RANT [EPILEPSY WARNING]]] | 00:06:58 | 노 맨즈 스카이 분노 영상 |
| 19 | [[Perverted Sentimentality An Analysis of UNDERTALE [4E-0sjkDnkc]\|Perverted Sentimentality: An Analysis of UNDERTALE]] | 00:14:16 | 언더테일 분석 |
| 18 | [[Power Fantasy, Male Objectification and Lady-Fanservice [coNQAucXoNM]\|Power Fantasy, Male Objectification and Lady-Fanservice]] | 00:11:19 | 파워 판타지, 남성 대상화와 여성향 팬서비스 |
| 17 | [[Sargon's Petition A Measured Response [XmKGPRXE-xw]\|Sargon's Petition: A Measured Response]] | 00:17:08 | 사르곤 청원 반박 |
| 16 | [[What Makes An Action Scene Good [ch-5ydxW_WE]\|What Makes An Action Scene Good?]] | 00:14:35 | 좋은 액션 장면의 조건 |
| 15 | [[How Should I Vote In The EU Referendum [RgVIQWItFE8]\|How Should I Vote In The EU Referendum?]] | 00:10:28 | 브렉시트 국민투표 투표 안내 |
| 14 | [[Antifeminism VS FACTS [rc24YtUslCU]\|Antifeminism VS FACTS]] | 00:17:11 | 반페미니즘 주장 대 사실 |
| 13 | [[What Is Virtue Signalling [sAmM872874A]\|What Is "Virtue Signalling"?]] | 00:10:48 | '버추 시그널링'이란 무엇인가 |
| 12 | [[Davis Aurini's Ghostbusters Video A Measured Response [gY172rzvbWE]\|Davis Aurini's Ghostbusters Video: A Measured Response]] | 00:16:27 | Davis Aurini의 고스트버스터즈 영상 반박 |
| 11 | [[Fallout 3 Is Garbage, And Here's Why [mLJ1gyIzg78]\|Fallout 3 Is Garbage, And Here's Why]] | 01:29:37 | 폴아웃 3가 별로인 이유 |
| 10 | [[BUTT GATE [Ozf2hwEOWHE]\|BUTT GATE]] | 00:02:12 | 짧은 코미디 영상(제목 기준) |
| 9 | [[Thunderf00t VS. FemiNAZI Ghostbusters A Measured Response [SpgBkpb7xlU]\|Thunderf00t VS. FemiNAZI Ghostbusters: A Measured Response]] | 00:20:24 | Thunderf00t의 고스트버스터즈 영상 반박 |
| 8 | [[The Sierra Effect A Measured Response [4UyPV2Fj4lk]\|The Sierra Effect: A Measured Response]] | 00:10:53 | The Sierra Effect 반박 |
| 7 | [[Darkest Dungeon and Ludonarrative - Hbomberguy [ziqXwyCjuFE]\|Darkest Dungeon and Ludonarrative - Hbomberguy]] | 00:09:22 | 다키스트 던전과 루도내러티브 |
| 6 | [[Braid was pretty good [J7Zp1DZJIYU]\|Braid was pretty good]] | 00:13:34 | 게임 Braid 리뷰 |
| 5 | [[IDIOT WARS THE RACISM AWAKENS PART 22 - Hbomberguy [62eCT40iLNk]\|IDIOT WARS: THE RACISM AWAKENS [PART 2/2] - Hbomberguy]] | 00:15:29 | 스타워즈 깨어난 포스 보이콧 논란 2부 |
| 4 | [[IDIOT WARS THE RACISM AWAKENS PART 12 - Hbomberguy [-E0p0GQCAM8]\|IDIOT WARS: THE RACISM AWAKENS [PART 1/2] - Hbomberguy]] | 00:09:12 | 스타워즈 깨어난 포스 보이콧 논란 1부 |
| 3 | [[Cultural Marxism A Measured Response - Hbomberguy [vYQo6LI3Y7c]\|Cultural Marxism: A Measured Response - Hbomberguy]] | 00:24:09 | '문화 마르크스주의' 음모론 반박 |
| 2 | [[The Sarkeesian Effect IN CRISIS! [YGbnAJR-vZA]\|The Sarkeesian Effect: IN CRISIS!]] | 00:08:54 | 다큐 The Sarkeesian Effect 후속 반박 |
| 1 | [[The Sarkeesian Effect A Measured Response [nsdIHK8O5yo]\|The Sarkeesian Effect: A Measured Response]] | 00:06:55 | 다큐 The Sarkeesian Effect 반박 |
