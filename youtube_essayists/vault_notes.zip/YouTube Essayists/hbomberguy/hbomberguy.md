# hbomberguy

69 videos

| # | Video | Length | What it is |
|---|---|---|---|
| 69 | [[Plagiarism and You(Tube) [yDp3cB5fHXQ]\|Plagiarism and You(Tube)]] | 03:51:10 | Four-hour documentary exposing plagiarism on YouTube (James Somerton and others). The channel's best-known video |
| 68 | [[ROBLOX_OOF.mp3 [0twDETh6QaI]\|ROBLOX_OOF.mp3]] | 01:57:49 | Tracing the origin and copyright mess of Roblox's "oof" sound |
| 67 | [[Deus Ex Human Revolution is FINE, And Here's Why [bgJazjz9ZsA]\|Deus Ex: Human Revolution is FINE, And Here's Why]] | 03:33:34 | Long analysis of Deus Ex: Human Revolution |
| 66 | [[Vaccines and Autism A Measured Response [8BIcAZxFfrc]\|Vaccines and Autism: A Measured Response]] | 01:44:10 | Long debunk of the vaccines-cause-autism claim |
| 65 | [[The War on Christmas A Measured Response [jbZo4x0NbbI]\|The War on Christmas: A Measured Response]] | 00:53:58 | Debunking the "War on Christmas" narrative |
| 64 | [[Fallout New Vegas Is Genius, And Here's Why [gzF7aHxk4Y4]\|Fallout: New Vegas Is Genius, And Here's Why]] | 01:37:42 | Why Fallout: New Vegas is great |
| 63 | [[RWBY Is Disappointing, And Here's Why [81fdKWOHrdE]\|RWBY Is Disappointing, And Here's Why]] | 02:27:25 | Why the animated series RWBY disappoints |
| 62 | [[Pathologic is Genius, And Here's Why [JsNm2YLrk30]\|Pathologic is Genius, And Here's Why]] | 02:10:52 | Why the game Pathologic is brilliant |
| 61 | [[Weighing the Value of Director's Cuts  Scanline [D6OT77T7YlE]\|Weighing the Value of Director's Cuts / Scanline]] | 00:49:07 | Weighing the value of director's cuts (Scanline) |
| 60 | [[Climate Denial A Measured Response [RLqXkYrdmjY]\|Climate Denial: A Measured Response]] | 00:41:20 | Debunking climate change denial |
| 59 | [[My Transformers Midlife Crisis [j7f26gVlDQI]\|My Transformers Midlife Crisis]] | 00:45:56 | A midlife-crisis essay about Transformers |
| 58 | [[WOKE BRANDS [06yy88tLWlg]\|WOKE BRANDS]] | 00:26:44 | Critique of "woke" corporate marketing |
| 57 | [[AOC Says Trans Rights [_mvYUaZYtJk]\|AOC Says Trans Rights]] | 00:11:32 | Short video on AOC and trans rights |
| 56 | [[DONKEY KONG 64 CHARITY STREAM ON JANUARY 18TH [WIM-GKRS9Vk]\|DONKEY KONG 64 CHARITY STREAM ON JANUARY 18TH]] | 00:03:28 | Announcement for a Donkey Kong 64 charity stream (fundraiser for the trans youth charity Mermaids) |
| 55 | [[Flat Earth A Measured Response [2gFsOoKAHZg]\|Flat Earth: A Measured Response]] | 00:45:18 | Debunking flat earth |
| 54 | [[Speedrunning Is Awesome, And Here's Why [I5auJOBC828]\|Speedrunning Is Awesome, And Here's Why]] | 00:43:49 | Why speedrunning is great |
| 53 | [[Outsiders How To Adapt H.P. Lovecraft In the 21st Century [l8u8wZ0WvxI]\|Outsiders: How To Adapt H.P. Lovecraft In the 21st Century]] | 00:33:26 | How to adapt H.P. Lovecraft in the 21st century (Outsiders) |
| 52 | [[CTRL+ALT+DEL  SLA3 [TebCHHCw9rY]\|CTRL+ALT+DEL / SLA:3]] | 00:34:11 | Critique of the webcomic CTRL+ALT+DEL |
| 51 | [[Skyrim is Garbage, And Here's Why [WYwpEzBvulA]\|Skyrim is Garbage, And Here's Why]] | 00:40:17 | Why Skyrim is bad |
| 50 | [[Nice Try, Paul [JOp28hQb_Xw]\|Nice Try, Paul]] | 00:07:06 | Short rebuttal to Paul Joseph Watson |
| 49 | [[Soy Boy Diet Aftermath [XYXkHIsslD0]\|Soy Boy Diet Aftermath]] | 00:21:43 | Aftermath of the soy boy diet |
| 48 | [[SOY BOYS A MEASURED RESPONSE [C8dfiDeJeDU]\|SOY BOYS: A MEASURED RESPONSE]] | 00:31:02 | Debunking the "soy boy" narrative |
| 47 | [[2017 Doctor Who Special Analysis [wtPZ96oHH-4]\|2017 Doctor Who Special Analysis]] | 00:26:45 | Analysis of the 2017 Doctor Who special |
| 46 | [[THE SOY BOY DIET [5MS0TrsI7rE]\|THE SOY BOY DIET]] | 00:09:33 | Trying the soy boy diet |
| 45 | [[Halcyon Dreams The Legacy of Dragon's Lair [CnPOQr1pxY8]\|Halcyon Dreams: The Legacy of Dragon's Lair]] | 00:43:17 | The influence of the game Dragon's Lair |
| 44 | [[Hbomberguy's 100K Q&A! [5-qccQbgH6I]\|Hbomberguy's 100K Q&A!]] | 00:36:23 | Q&A for 100k subscribers |
| 43 | [[The Power Of VHS  SCANLINE [xbZMqS-fW-8]\|The Power Of VHS / SCANLINE]] | 00:29:21 | The power of VHS (Scanline) |
| 42 | [[Bill Nye VS Pseudoscience (Part Two!)  Measured Response [LqYgjGDaMYg]\|Bill Nye VS Pseudoscience (Part Two!) / Measured Response]] | 00:55:50 | Bill Nye vs pseudoscience, part 2 |
| 41 | [[Doomfist In-Depth Analysis & Review [YpdY8eMwjZ8]\|Doomfist In-Depth Analysis & Review]] | 00:10:11 | Comedy "analysis" of Overwatch's Doomfist |
| 40 | [[Lisa The Analysis [t-5_zoEsY6c]\|Lisa: The Analysis]] | 00:40:51 | Analysis of the game LISA |
| 39 | [[Here's Three Stories About YouTube Plagiarism [ZDtJ7bte_zg]\|Here's Three Stories About YouTube Plagiarism]] | 00:17:12 | Three stories about plagiarism on YouTube |
| 38 | [[Measured Response Bill Nye VS Pseudoscience (Part One) [dklVypazQsA]\|Measured Response: Bill Nye VS Pseudoscience (Part One)]] | 00:35:05 | Bill Nye vs pseudoscience, part 1 |
| 37 | [[ELECTIONWATCH 2017 [dVbC0jASJYA]\|ELECTIONWATCH 2017]] | 00:28:00 | Video on the 2017 UK general election |
| 36 | [[Sherlock Is Garbage, And Here's Why [LkoGBOs5ecM]\|Sherlock Is Garbage, And Here's Why]] | 01:49:53 | Why the TV show Sherlock is bad |
| 35 | [[What Modern Games Can Learn From Yooka-Laylee [P2mGHeCAJOs]\|What Modern Games Can Learn From Yooka-Laylee]] | 00:13:53 | What modern games can learn from Yooka-Laylee |
| 34 | [[In Defense of Dark Souls 2 [SRTfcMeqhig]\|In Defense of Dark Souls 2]] | 01:19:44 | A defense of Dark Souls 2 |
| 33 | [[Pick Up Artistry A Measured Response [_pEfhgG3Ocw]\|Pick Up Artistry: A Measured Response]] | 00:29:14 | Debunking pickup artistry |
| 32 | [[PewDiePie Is A Nazi [GjNILjFters]\|PewDiePie Is A Nazi]] | 00:14:18 | Video on the PewDiePie controversy |
| 31 | [[FreeSargon A Measured Response [aL_vIqMiHK0]\|#FreeSargon: A Measured Response]] | 00:09:50 | Debunking the #FreeSargon hashtag |
| 30 | [[Why Is New Donk City Uncanny - SERIOUS LORE ANALYSIS [5_IT0C7bm2s]\|Why Is New Donk City Uncanny? - SERIOUS LORE ANALYSIS]] | 00:15:21 | Comedy analysis of why New Donk City in Mario Odyssey is uncanny |
| 29 | [[Bethesda VS Critics How To Save The Games Industry [C6NiXAdMzEk]\|Bethesda VS Critics: How To Save The Games Industry]] | 00:22:23 | Bethesda, critics and the games industry |
| 28 | [[HBOMB'S GOTY 2016 LIST [JwYLTJelJ0k]\|HBOMB'S GOTY 2016 LIST]] | 00:20:23 | His game of the year list for 2016 |
| 27 | [[The Golden One A Measured Response [Ahuj1B0ow4U]\|The Golden One: A Measured Response]] | 00:22:55 | Rebuttal to YouTuber The Golden One |
| 26 | [[Stan Lee Owns [RmLFGWAyajU]\|Stan Lee Owns]] | 00:03:31 | Short video about Stan Lee |
| 25 | [[The Killing Joke Movie and The Problem With Comics [4xRDiUD1a8c]\|The Killing Joke Movie and The Problem With Comics]] | 00:16:26 | The Killing Joke animated film and the problem with comics |
| 24 | [[Bloodborne Is Genius, And Here's Why [AC3OuLU5XCw]\|Bloodborne Is Genius, And Here's Why]] | 01:26:40 | Why Bloodborne is great |
| 23 | [[Second Look At Nintendo Switch [g43NZSmY6-8]\|Second Look At Nintendo Switch]] | 00:03:30 | A second look at the Nintendo Switch |
| 22 | [[I Filmed Myself Watching The Alt Right Dogs Trailer [1t_Bs-8L4Mo]\|I Filmed Myself Watching The Alt Right Dogs Trailer]] | 00:15:02 | Filming himself watching an alt-right documentary trailer |
| 21 | [[SERIOUS SONIC LORE ANALYSIS [3Oco4WYRdaU]\|SERIOUS SONIC LORE ANALYSIS]] | 00:11:07 | Comedy "serious" Sonic lore analysis |
| 20 | [[THE NO MAN'S SKY RANT EPILEPSY WARNING [4DhaUe6y-Co]\|THE NO MAN'S SKY RANT [EPILEPSY WARNING]]] | 00:06:58 | Rant about No Man's Sky |
| 19 | [[Perverted Sentimentality An Analysis of UNDERTALE [4E-0sjkDnkc]\|Perverted Sentimentality: An Analysis of UNDERTALE]] | 00:14:16 | Analysis of Undertale |
| 18 | [[Power Fantasy, Male Objectification and Lady-Fanservice [coNQAucXoNM]\|Power Fantasy, Male Objectification and Lady-Fanservice]] | 00:11:19 | Power fantasy, male objectification and fanservice aimed at women |
| 17 | [[Sargon's Petition A Measured Response [XmKGPRXE-xw]\|Sargon's Petition: A Measured Response]] | 00:17:08 | Rebuttal to Sargon's petition |
| 16 | [[What Makes An Action Scene Good [ch-5ydxW_WE]\|What Makes An Action Scene Good?]] | 00:14:35 | What makes an action scene good |
| 15 | [[How Should I Vote In The EU Referendum [RgVIQWItFE8]\|How Should I Vote In The EU Referendum?]] | 00:10:28 | Voting guide for the Brexit referendum |
| 14 | [[Antifeminism VS FACTS [rc24YtUslCU]\|Antifeminism VS FACTS]] | 00:17:11 | Antifeminist claims checked against facts |
| 13 | [[What Is Virtue Signalling [sAmM872874A]\|What Is "Virtue Signalling"?]] | 00:10:48 | What "virtue signalling" means |
| 12 | [[Davis Aurini's Ghostbusters Video A Measured Response [gY172rzvbWE]\|Davis Aurini's Ghostbusters Video: A Measured Response]] | 00:16:27 | Rebuttal to Davis Aurini's Ghostbusters video |
| 11 | [[Fallout 3 Is Garbage, And Here's Why [mLJ1gyIzg78]\|Fallout 3 Is Garbage, And Here's Why]] | 01:29:37 | Why Fallout 3 is bad |
| 10 | [[BUTT GATE [Ozf2hwEOWHE]\|BUTT GATE]] | 00:02:12 | Short comedy video (guessed from title) |
| 9 | [[Thunderf00t VS. FemiNAZI Ghostbusters A Measured Response [SpgBkpb7xlU]\|Thunderf00t VS. FemiNAZI Ghostbusters: A Measured Response]] | 00:20:24 | Rebuttal to Thunderf00t's Ghostbusters video |
| 8 | [[The Sierra Effect A Measured Response [4UyPV2Fj4lk]\|The Sierra Effect: A Measured Response]] | 00:10:53 | Rebuttal to The Sierra Effect |
| 7 | [[Darkest Dungeon and Ludonarrative - Hbomberguy [ziqXwyCjuFE]\|Darkest Dungeon and Ludonarrative - Hbomberguy]] | 00:09:22 | Darkest Dungeon and ludonarrative |
| 6 | [[Braid was pretty good [J7Zp1DZJIYU]\|Braid was pretty good]] | 00:13:34 | Review of the game Braid |
| 5 | [[IDIOT WARS THE RACISM AWAKENS PART 22 - Hbomberguy [62eCT40iLNk]\|IDIOT WARS: THE RACISM AWAKENS [PART 2/2] - Hbomberguy]] | 00:15:29 | The Force Awakens boycott controversy, part 2 |
| 4 | [[IDIOT WARS THE RACISM AWAKENS PART 12 - Hbomberguy [-E0p0GQCAM8]\|IDIOT WARS: THE RACISM AWAKENS [PART 1/2] - Hbomberguy]] | 00:09:12 | The Force Awakens boycott controversy, part 1 |
| 3 | [[Cultural Marxism A Measured Response - Hbomberguy [vYQo6LI3Y7c]\|Cultural Marxism: A Measured Response - Hbomberguy]] | 00:24:09 | Debunking the "Cultural Marxism" conspiracy theory |
| 2 | [[The Sarkeesian Effect IN CRISIS! [YGbnAJR-vZA]\|The Sarkeesian Effect: IN CRISIS!]] | 00:08:54 | Follow-up rebuttal to the documentary The Sarkeesian Effect |
| 1 | [[The Sarkeesian Effect A Measured Response [nsdIHK8O5yo]\|The Sarkeesian Effect: A Measured Response]] | 00:06:55 | Rebuttal to the documentary The Sarkeesian Effect |
