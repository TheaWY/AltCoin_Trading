---
title: "Outsiders: How To Adapt H.P. Lovecraft In the 21st Century"
channel: "hbomberguy"
type: "video"
video_id: "l8u8wZ0WvxI"
url: "https://www.youtube.com/watch?v=l8u8wZ0WvxI"
duration: "00:33:26"
upload_order: 53
about_ko: "21세기에 러브크래프트를 각색하는 법(Outsiders)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Outsiders: How To Adapt H.P. Lovecraft In the 21st Century

채널: [[hbomberguy]] · 길이 00:33:26 · [YouTube](https://www.youtube.com/watch?v=l8u8wZ0WvxI)

## 어떤 영상인가

21세기에 러브크래프트를 각색하는 법(Outsiders)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
