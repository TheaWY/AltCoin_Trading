---
title: "Outsiders: How To Adapt H.P. Lovecraft In the 21st Century"
channel: "hbomberguy"
type: "video"
video_id: "l8u8wZ0WvxI"
url: "https://www.youtube.com/watch?v=l8u8wZ0WvxI"
duration: "00:33:26"
upload_order: 53
about: "How to adapt H.P. Lovecraft in the 21st century (Outsiders)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Outsiders: How To Adapt H.P. Lovecraft In the 21st Century

Channel: [[hbomberguy]] · Length 00:33:26 · [YouTube](https://www.youtube.com/watch?v=l8u8wZ0WvxI)

## What it is

How to adapt H.P. Lovecraft in the 21st century (Outsiders)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
