---
title: "Darkest Dungeon and Ludonarrative - Hbomberguy"
channel: "hbomberguy"
type: "video"
video_id: "ziqXwyCjuFE"
url: "https://www.youtube.com/watch?v=ziqXwyCjuFE"
duration: "00:09:22"
upload_order: 7
about: "Darkest Dungeon and ludonarrative"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Darkest Dungeon and Ludonarrative - Hbomberguy

Channel: [[hbomberguy]] · Length 00:09:22 · [YouTube](https://www.youtube.com/watch?v=ziqXwyCjuFE)

## What it is

Darkest Dungeon and ludonarrative

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
