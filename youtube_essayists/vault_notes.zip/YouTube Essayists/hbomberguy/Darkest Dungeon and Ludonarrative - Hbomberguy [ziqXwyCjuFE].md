---
title: "Darkest Dungeon and Ludonarrative - Hbomberguy"
channel: "hbomberguy"
type: "video"
video_id: "ziqXwyCjuFE"
url: "https://www.youtube.com/watch?v=ziqXwyCjuFE"
duration: "00:09:22"
upload_order: 7
about_ko: "다키스트 던전과 루도내러티브"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Darkest Dungeon and Ludonarrative - Hbomberguy

채널: [[hbomberguy]] · 길이 00:09:22 · [YouTube](https://www.youtube.com/watch?v=ziqXwyCjuFE)

## 어떤 영상인가

다키스트 던전과 루도내러티브

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
