---
title: "CTRL+ALT+DEL | SLA:3"
channel: "hbomberguy"
type: "video"
video_id: "TebCHHCw9rY"
url: "https://www.youtube.com/watch?v=TebCHHCw9rY"
duration: "00:34:11"
upload_order: 52
about: "Critique of the webcomic CTRL+ALT+DEL"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# CTRL+ALT+DEL | SLA:3

Channel: [[hbomberguy]] · Length 00:34:11 · [YouTube](https://www.youtube.com/watch?v=TebCHHCw9rY)

## What it is

Critique of the webcomic CTRL+ALT+DEL

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
