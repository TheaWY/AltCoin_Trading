---
title: "CTRL+ALT+DEL | SLA:3"
channel: "hbomberguy"
type: "video"
video_id: "TebCHHCw9rY"
url: "https://www.youtube.com/watch?v=TebCHHCw9rY"
duration: "00:34:11"
upload_order: 52
about_ko: "웹코믹 CTRL+ALT+DEL 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# CTRL+ALT+DEL | SLA:3

채널: [[hbomberguy]] · 길이 00:34:11 · [YouTube](https://www.youtube.com/watch?v=TebCHHCw9rY)

## 어떤 영상인가

웹코믹 CTRL+ALT+DEL 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
