---
title: "The Killing Joke Movie and The Problem With Comics"
channel: "hbomberguy"
type: "video"
video_id: "4xRDiUD1a8c"
url: "https://www.youtube.com/watch?v=4xRDiUD1a8c"
duration: "00:16:26"
upload_order: 25
about: "The Killing Joke animated film and the problem with comics"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# The Killing Joke Movie and The Problem With Comics

Channel: [[hbomberguy]] · Length 00:16:26 · [YouTube](https://www.youtube.com/watch?v=4xRDiUD1a8c)

## What it is

The Killing Joke animated film and the problem with comics

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
