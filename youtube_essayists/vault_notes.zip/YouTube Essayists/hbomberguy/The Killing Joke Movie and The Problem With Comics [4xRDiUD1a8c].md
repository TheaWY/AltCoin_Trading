---
title: "The Killing Joke Movie and The Problem With Comics"
channel: "hbomberguy"
type: "video"
video_id: "4xRDiUD1a8c"
url: "https://www.youtube.com/watch?v=4xRDiUD1a8c"
duration: "00:16:26"
upload_order: 25
about_ko: "킬링 조크 애니메이션과 코믹스의 문제"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# The Killing Joke Movie and The Problem With Comics

채널: [[hbomberguy]] · 길이 00:16:26 · [YouTube](https://www.youtube.com/watch?v=4xRDiUD1a8c)

## 어떤 영상인가

킬링 조크 애니메이션과 코믹스의 문제

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
