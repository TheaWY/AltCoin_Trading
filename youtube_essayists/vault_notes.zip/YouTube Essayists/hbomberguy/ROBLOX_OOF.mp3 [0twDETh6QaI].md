---
title: "ROBLOX_OOF.mp3"
channel: "hbomberguy"
type: "video"
video_id: "0twDETh6QaI"
url: "https://www.youtube.com/watch?v=0twDETh6QaI"
duration: "01:57:49"
upload_order: 68
about: "Tracing the origin and copyright mess of Roblox's \"oof\" sound"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# ROBLOX_OOF.mp3

Channel: [[hbomberguy]] · Length 01:57:49 · [YouTube](https://www.youtube.com/watch?v=0twDETh6QaI)

## What it is

Tracing the origin and copyright mess of Roblox's "oof" sound

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
