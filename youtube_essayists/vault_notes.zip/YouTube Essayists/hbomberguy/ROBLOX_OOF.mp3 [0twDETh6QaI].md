---
title: "ROBLOX_OOF.mp3"
channel: "hbomberguy"
type: "video"
video_id: "0twDETh6QaI"
url: "https://www.youtube.com/watch?v=0twDETh6QaI"
duration: "01:57:49"
upload_order: 68
about_ko: "로블록스 'oof' 효과음의 출처와 저작권 문제 추적"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# ROBLOX_OOF.mp3

채널: [[hbomberguy]] · 길이 01:57:49 · [YouTube](https://www.youtube.com/watch?v=0twDETh6QaI)

## 어떤 영상인가

로블록스 'oof' 효과음의 출처와 저작권 문제 추적

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
