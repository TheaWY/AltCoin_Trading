---
title: "Bethesda VS Critics: How To Save The Games Industry"
channel: "hbomberguy"
type: "video"
video_id: "C6NiXAdMzEk"
url: "https://www.youtube.com/watch?v=C6NiXAdMzEk"
duration: "00:22:23"
upload_order: 29
about: "Bethesda, critics and the games industry"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Bethesda VS Critics: How To Save The Games Industry

Channel: [[hbomberguy]] · Length 00:22:23 · [YouTube](https://www.youtube.com/watch?v=C6NiXAdMzEk)

## What it is

Bethesda, critics and the games industry

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
