---
title: "Bethesda VS Critics: How To Save The Games Industry"
channel: "hbomberguy"
type: "video"
video_id: "C6NiXAdMzEk"
url: "https://www.youtube.com/watch?v=C6NiXAdMzEk"
duration: "00:22:23"
upload_order: 29
about_ko: "베데스다와 비평가, 게임 산업 이야기"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Bethesda VS Critics: How To Save The Games Industry

채널: [[hbomberguy]] · 길이 00:22:23 · [YouTube](https://www.youtube.com/watch?v=C6NiXAdMzEk)

## 어떤 영상인가

베데스다와 비평가, 게임 산업 이야기

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
