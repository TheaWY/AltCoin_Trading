---
title: "ELECTIONWATCH 2017"
channel: "hbomberguy"
type: "video"
video_id: "dVbC0jASJYA"
url: "https://www.youtube.com/watch?v=dVbC0jASJYA"
duration: "00:28:00"
upload_order: 37
about_ko: "2017 영국 총선 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# ELECTIONWATCH 2017

채널: [[hbomberguy]] · 길이 00:28:00 · [YouTube](https://www.youtube.com/watch?v=dVbC0jASJYA)

## 어떤 영상인가

2017 영국 총선 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
