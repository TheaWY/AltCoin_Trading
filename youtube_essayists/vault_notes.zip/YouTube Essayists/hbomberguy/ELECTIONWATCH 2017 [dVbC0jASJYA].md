---
title: "ELECTIONWATCH 2017"
channel: "hbomberguy"
type: "video"
video_id: "dVbC0jASJYA"
url: "https://www.youtube.com/watch?v=dVbC0jASJYA"
duration: "00:28:00"
upload_order: 37
about: "Video on the 2017 UK general election"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# ELECTIONWATCH 2017

Channel: [[hbomberguy]] · Length 00:28:00 · [YouTube](https://www.youtube.com/watch?v=dVbC0jASJYA)

## What it is

Video on the 2017 UK general election

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
