---
title: "Here's Three Stories About YouTube Plagiarism"
channel: "hbomberguy"
type: "video"
video_id: "ZDtJ7bte_zg"
url: "https://www.youtube.com/watch?v=ZDtJ7bte_zg"
duration: "00:17:12"
upload_order: 39
about_ko: "유튜브 표절 사례 세 가지"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Here's Three Stories About YouTube Plagiarism

채널: [[hbomberguy]] · 길이 00:17:12 · [YouTube](https://www.youtube.com/watch?v=ZDtJ7bte_zg)

## 어떤 영상인가

유튜브 표절 사례 세 가지

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
