---
title: "Here's Three Stories About YouTube Plagiarism"
channel: "hbomberguy"
type: "video"
video_id: "ZDtJ7bte_zg"
url: "https://www.youtube.com/watch?v=ZDtJ7bte_zg"
duration: "00:17:12"
upload_order: 39
about: "Three stories about plagiarism on YouTube"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Here's Three Stories About YouTube Plagiarism

Channel: [[hbomberguy]] · Length 00:17:12 · [YouTube](https://www.youtube.com/watch?v=ZDtJ7bte_zg)

## What it is

Three stories about plagiarism on YouTube

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
