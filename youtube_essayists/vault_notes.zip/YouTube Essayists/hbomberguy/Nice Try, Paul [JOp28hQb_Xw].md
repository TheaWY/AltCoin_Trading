---
title: "Nice Try, Paul"
channel: "hbomberguy"
type: "video"
video_id: "JOp28hQb_Xw"
url: "https://www.youtube.com/watch?v=JOp28hQb_Xw"
duration: "00:07:06"
upload_order: 50
about: "Short rebuttal to Paul Joseph Watson"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Nice Try, Paul

Channel: [[hbomberguy]] · Length 00:07:06 · [YouTube](https://www.youtube.com/watch?v=JOp28hQb_Xw)

## What it is

Short rebuttal to Paul Joseph Watson

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
