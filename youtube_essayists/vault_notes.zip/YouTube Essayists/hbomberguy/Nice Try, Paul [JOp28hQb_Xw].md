---
title: "Nice Try, Paul"
channel: "hbomberguy"
type: "video"
video_id: "JOp28hQb_Xw"
url: "https://www.youtube.com/watch?v=JOp28hQb_Xw"
duration: "00:07:06"
upload_order: 50
about_ko: "폴(Paul Joseph Watson) 반박 짧은 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "hbomberguy"]
---

# Nice Try, Paul

채널: [[hbomberguy]] · 길이 00:07:06 · [YouTube](https://www.youtube.com/watch?v=JOp28hQb_Xw)

## 어떤 영상인가

폴(Paul Joseph Watson) 반박 짧은 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
