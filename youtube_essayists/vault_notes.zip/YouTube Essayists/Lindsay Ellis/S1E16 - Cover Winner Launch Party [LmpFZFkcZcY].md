---
title: "S1E16 - Cover Winner Launch Party"
channel: "Lindsay Ellis"
type: "video"
video_id: "LmpFZFkcZcY"
url: "https://www.youtube.com/watch?v=LmpFZFkcZcY"
duration: "00:04:33"
upload_order: 12
about: "Chick Lit S1E16: cover winner and launch party"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E16 - Cover Winner Launch Party

Channel: [[Lindsay Ellis]] · Length 00:04:33 · [YouTube](https://www.youtube.com/watch?v=LmpFZFkcZcY)

## What it is

Chick Lit S1E16: cover winner and launch party

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
