---
title: "S1E16 - Cover Winner Launch Party"
channel: "Lindsay Ellis"
type: "video"
video_id: "LmpFZFkcZcY"
url: "https://www.youtube.com/watch?v=LmpFZFkcZcY"
duration: "00:04:33"
upload_order: 12
about_ko: "Chick Lit S1E16: 표지 당선작과 출간 파티"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E16 - Cover Winner Launch Party

채널: [[Lindsay Ellis]] · 길이 00:04:33 · [YouTube](https://www.youtube.com/watch?v=LmpFZFkcZcY)

## 어떤 영상인가

Chick Lit S1E16: 표지 당선작과 출간 파티

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
