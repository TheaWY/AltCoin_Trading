---
title: "Is Beauty and the Beast About Stockholm Syndrome?"
channel: "Lindsay Ellis"
type: "video"
video_id: "syYCO0QVkZo"
url: "https://www.youtube.com/watch?v=syYCO0QVkZo"
duration: "00:17:07"
upload_order: 70
about_ko: "미녀와 야수는 스톡홀름 증후군 이야기인가"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Is Beauty and the Beast About Stockholm Syndrome?

채널: [[Lindsay Ellis]] · 길이 00:17:07 · [YouTube](https://www.youtube.com/watch?v=syYCO0QVkZo)

## 어떤 영상인가

미녀와 야수는 스톡홀름 증후군 이야기인가

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
