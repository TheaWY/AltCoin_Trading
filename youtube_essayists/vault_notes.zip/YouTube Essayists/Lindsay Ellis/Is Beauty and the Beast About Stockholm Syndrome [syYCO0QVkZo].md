---
title: "Is Beauty and the Beast About Stockholm Syndrome?"
channel: "Lindsay Ellis"
type: "video"
video_id: "syYCO0QVkZo"
url: "https://www.youtube.com/watch?v=syYCO0QVkZo"
duration: "00:17:07"
upload_order: 70
about: "Is Beauty and the Beast about Stockholm syndrome?"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Is Beauty and the Beast About Stockholm Syndrome?

Channel: [[Lindsay Ellis]] · Length 00:17:07 · [YouTube](https://www.youtube.com/watch?v=syYCO0QVkZo)

## What it is

Is Beauty and the Beast about Stockholm syndrome?

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
