---
title: "How Aladdin Changed Animation (by Screwing Over Robin Williams)"
channel: "Lindsay Ellis"
type: "video"
video_id: "nyiBdccfNkg"
url: "https://www.youtube.com/watch?v=nyiBdccfNkg"
duration: "00:24:00"
upload_order: 100
about: "How Aladdin and the Robin Williams fallout changed the animation business"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# How Aladdin Changed Animation (by Screwing Over Robin Williams)

Channel: [[Lindsay Ellis]] · Length 00:24:00 · [YouTube](https://www.youtube.com/watch?v=nyiBdccfNkg)

## What it is

How Aladdin and the Robin Williams fallout changed the animation business

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
