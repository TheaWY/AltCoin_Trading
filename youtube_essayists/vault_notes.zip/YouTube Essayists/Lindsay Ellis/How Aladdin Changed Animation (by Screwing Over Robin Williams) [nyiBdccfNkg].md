---
title: "How Aladdin Changed Animation (by Screwing Over Robin Williams)"
channel: "Lindsay Ellis"
type: "video"
video_id: "nyiBdccfNkg"
url: "https://www.youtube.com/watch?v=nyiBdccfNkg"
duration: "00:24:00"
upload_order: 100
about_ko: "알라딘이 로빈 윌리엄스와의 갈등을 통해 애니메이션 업계를 바꾼 과정"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# How Aladdin Changed Animation (by Screwing Over Robin Williams)

채널: [[Lindsay Ellis]] · 길이 00:24:00 · [YouTube](https://www.youtube.com/watch?v=nyiBdccfNkg)

## 어떤 영상인가

알라딘이 로빈 윌리엄스와의 갈등을 통해 애니메이션 업계를 바꾼 과정

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
