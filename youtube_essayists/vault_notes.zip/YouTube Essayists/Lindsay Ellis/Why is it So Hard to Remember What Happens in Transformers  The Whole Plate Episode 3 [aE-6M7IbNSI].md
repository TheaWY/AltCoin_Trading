---
title: "Why is it So Hard to Remember What Happens in Transformers? | The Whole Plate: Episode 3"
channel: "Lindsay Ellis"
type: "video"
video_id: "aE-6M7IbNSI"
url: "https://www.youtube.com/watch?v=aE-6M7IbNSI"
duration: "00:14:07"
upload_order: 73
about_ko: "The Whole Plate 3화: 트랜스포머 내용이 기억에 안 남는 이유"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Why is it So Hard to Remember What Happens in Transformers? | The Whole Plate: Episode 3

채널: [[Lindsay Ellis]] · 길이 00:14:07 · [YouTube](https://www.youtube.com/watch?v=aE-6M7IbNSI)

## 어떤 영상인가

The Whole Plate 3화: 트랜스포머 내용이 기억에 안 남는 이유

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
