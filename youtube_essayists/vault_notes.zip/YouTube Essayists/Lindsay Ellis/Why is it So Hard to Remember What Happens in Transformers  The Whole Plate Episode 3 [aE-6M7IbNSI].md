---
title: "Why is it So Hard to Remember What Happens in Transformers? | The Whole Plate: Episode 3"
channel: "Lindsay Ellis"
type: "video"
video_id: "aE-6M7IbNSI"
url: "https://www.youtube.com/watch?v=aE-6M7IbNSI"
duration: "00:14:07"
upload_order: 73
about: "The Whole Plate ep. 3: why Transformers plots are hard to remember"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Why is it So Hard to Remember What Happens in Transformers? | The Whole Plate: Episode 3

Channel: [[Lindsay Ellis]] · Length 00:14:07 · [YouTube](https://www.youtube.com/watch?v=aE-6M7IbNSI)

## What it is

The Whole Plate ep. 3: why Transformers plots are hard to remember

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
