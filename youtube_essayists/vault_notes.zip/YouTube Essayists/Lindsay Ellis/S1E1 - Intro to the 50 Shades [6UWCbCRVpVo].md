---
title: "S1E1 - Intro to the 50 Shades"
channel: "Lindsay Ellis"
type: "video"
video_id: "6UWCbCRVpVo"
url: "https://www.youtube.com/watch?v=6UWCbCRVpVo"
duration: "00:05:44"
upload_order: 1
about: "Chick Lit S1E1: intro to the series about writing a 50 Shades parody"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E1 - Intro to the 50 Shades

Channel: [[Lindsay Ellis]] · Length 00:05:44 · [YouTube](https://www.youtube.com/watch?v=6UWCbCRVpVo)

## What it is

Chick Lit S1E1: intro to the series about writing a 50 Shades parody

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
