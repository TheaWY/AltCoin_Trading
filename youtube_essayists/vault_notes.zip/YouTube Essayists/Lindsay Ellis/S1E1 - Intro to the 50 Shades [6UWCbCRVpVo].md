---
title: "S1E1 - Intro to the 50 Shades"
channel: "Lindsay Ellis"
type: "video"
video_id: "6UWCbCRVpVo"
url: "https://www.youtube.com/watch?v=6UWCbCRVpVo"
duration: "00:05:44"
upload_order: 1
about_ko: "Chick Lit S1E1: 50 Shades 패러디 소설 쓰기 시리즈 소개"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E1 - Intro to the 50 Shades

채널: [[Lindsay Ellis]] · 길이 00:05:44 · [YouTube](https://www.youtube.com/watch?v=6UWCbCRVpVo)

## 어떤 영상인가

Chick Lit S1E1: 50 Shades 패러디 소설 쓰기 시리즈 소개

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
