---
title: "Mini - Canon: \"Oscar Bait\": A History"
channel: "Lindsay Ellis"
type: "video"
video_id: "nxkjLQdFmRI"
url: "https://www.youtube.com/watch?v=nxkjLQdFmRI"
duration: "00:10:24"
upload_order: 33
about_ko: "Mini-Canon: '오스카 베이트' 영화의 역사"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Mini - Canon: "Oscar Bait": A History

채널: [[Lindsay Ellis]] · 길이 00:10:24 · [YouTube](https://www.youtube.com/watch?v=nxkjLQdFmRI)

## 어떤 영상인가

Mini-Canon: '오스카 베이트' 영화의 역사

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
