---
title: "Mini - Canon: \"Oscar Bait\": A History"
channel: "Lindsay Ellis"
type: "video"
video_id: "nxkjLQdFmRI"
url: "https://www.youtube.com/watch?v=nxkjLQdFmRI"
duration: "00:10:24"
upload_order: 33
about: "Mini-Canon: history of \"Oscar bait\" films"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Mini - Canon: "Oscar Bait": A History

Channel: [[Lindsay Ellis]] · Length 00:10:24 · [YouTube](https://www.youtube.com/watch?v=nxkjLQdFmRI)

## What it is

Mini-Canon: history of "Oscar bait" films

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
