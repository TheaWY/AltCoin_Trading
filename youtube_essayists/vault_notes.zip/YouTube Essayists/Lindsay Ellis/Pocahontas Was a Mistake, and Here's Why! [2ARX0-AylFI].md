---
title: "Pocahontas Was a Mistake, and Here's Why!"
channel: "Lindsay Ellis"
type: "video"
video_id: "2ARX0-AylFI"
url: "https://www.youtube.com/watch?v=2ARX0-AylFI"
duration: "00:32:56"
upload_order: 78
about: "Why Disney's Pocahontas was a mistake"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Pocahontas Was a Mistake, and Here's Why!

Channel: [[Lindsay Ellis]] · Length 00:32:56 · [YouTube](https://www.youtube.com/watch?v=2ARX0-AylFI)

## What it is

Why Disney's Pocahontas was a mistake

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
