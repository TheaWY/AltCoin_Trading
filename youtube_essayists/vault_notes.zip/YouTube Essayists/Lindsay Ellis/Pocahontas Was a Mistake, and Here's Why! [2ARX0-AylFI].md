---
title: "Pocahontas Was a Mistake, and Here's Why!"
channel: "Lindsay Ellis"
type: "video"
video_id: "2ARX0-AylFI"
url: "https://www.youtube.com/watch?v=2ARX0-AylFI"
duration: "00:32:56"
upload_order: 78
about_ko: "디즈니 포카혼타스가 실수였던 이유"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Pocahontas Was a Mistake, and Here's Why!

채널: [[Lindsay Ellis]] · 길이 00:32:56 · [YouTube](https://www.youtube.com/watch?v=2ARX0-AylFI)

## 어떤 영상인가

디즈니 포카혼타스가 실수였던 이유

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
