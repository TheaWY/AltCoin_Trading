---
title: "The Epcot Challenge: Drinking Around the World 2016"
channel: "Lindsay Ellis"
type: "video"
video_id: "gI4T6pvbIAY"
url: "https://www.youtube.com/watch?v=gI4T6pvbIAY"
duration: "00:14:16"
upload_order: 44
about_ko: "엡콧 '세계 일주 음주' 챌린지 브이로그"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Epcot Challenge: Drinking Around the World 2016

채널: [[Lindsay Ellis]] · 길이 00:14:16 · [YouTube](https://www.youtube.com/watch?v=gI4T6pvbIAY)

## 어떤 영상인가

엡콧 '세계 일주 음주' 챌린지 브이로그

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
