---
title: "The Epcot Challenge: Drinking Around the World 2016"
channel: "Lindsay Ellis"
type: "video"
video_id: "gI4T6pvbIAY"
url: "https://www.youtube.com/watch?v=gI4T6pvbIAY"
duration: "00:14:16"
upload_order: 44
about: "Vlog of the Epcot \"drinking around the world\" challenge"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Epcot Challenge: Drinking Around the World 2016

Channel: [[Lindsay Ellis]] · Length 00:14:16 · [YouTube](https://www.youtube.com/watch?v=gI4T6pvbIAY)

## What it is

Vlog of the Epcot "drinking around the world" challenge

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
