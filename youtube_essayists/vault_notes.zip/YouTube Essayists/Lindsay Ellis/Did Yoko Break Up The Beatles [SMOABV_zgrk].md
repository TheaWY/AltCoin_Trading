---
title: "Did Yoko Break Up The Beatles?"
channel: "Lindsay Ellis"
type: "video"
video_id: "SMOABV_zgrk"
url: "https://www.youtube.com/watch?v=SMOABV_zgrk"
duration: "01:41:11"
upload_order: 120
about_ko: "오노 요코가 비틀스를 해체시켰다는 통념을 역사적으로 검증"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Did Yoko Break Up The Beatles?

채널: [[Lindsay Ellis]] · 길이 01:41:11 · [YouTube](https://www.youtube.com/watch?v=SMOABV_zgrk)

## 어떤 영상인가

오노 요코가 비틀스를 해체시켰다는 통념을 역사적으로 검증

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
