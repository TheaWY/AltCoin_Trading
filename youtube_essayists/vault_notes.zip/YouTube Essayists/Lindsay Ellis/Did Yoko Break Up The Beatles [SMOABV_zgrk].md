---
title: "Did Yoko Break Up The Beatles?"
channel: "Lindsay Ellis"
type: "video"
video_id: "SMOABV_zgrk"
url: "https://www.youtube.com/watch?v=SMOABV_zgrk"
duration: "01:41:11"
upload_order: 120
about: "Checking the popular idea that Yoko Ono broke up the Beatles"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Did Yoko Break Up The Beatles?

Channel: [[Lindsay Ellis]] · Length 01:41:11 · [YouTube](https://www.youtube.com/watch?v=SMOABV_zgrk)

## What it is

Checking the popular idea that Yoko Ono broke up the Beatles

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
