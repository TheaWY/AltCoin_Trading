---
title: "How To Get A Book Deal in Ten Years or Less"
channel: "Lindsay Ellis"
type: "video"
video_id: "tuRE55YH8yE"
url: "https://www.youtube.com/watch?v=tuRE55YH8yE"
duration: "00:31:05"
upload_order: 104
about: "How she got a book deal after ten years of trying"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# How To Get A Book Deal in Ten Years or Less

Channel: [[Lindsay Ellis]] · Length 00:31:05 · [YouTube](https://www.youtube.com/watch?v=tuRE55YH8yE)

## What it is

How she got a book deal after ten years of trying

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
