---
title: "How To Get A Book Deal in Ten Years or Less"
channel: "Lindsay Ellis"
type: "video"
video_id: "tuRE55YH8yE"
url: "https://www.youtube.com/watch?v=tuRE55YH8yE"
duration: "00:31:05"
upload_order: 104
about_ko: "10년 걸려 책 계약을 따낸 과정"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# How To Get A Book Deal in Ten Years or Less

채널: [[Lindsay Ellis]] · 길이 00:31:05 · [YouTube](https://www.youtube.com/watch?v=tuRE55YH8yE)

## 어떤 영상인가

10년 걸려 책 계약을 따낸 과정

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
