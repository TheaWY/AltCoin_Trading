---
title: "S1E10 Completion Of A Great Opus"
channel: "Lindsay Ellis"
type: "video"
video_id: "9uNIQ4LZrg0"
url: "https://www.youtube.com/watch?v=9uNIQ4LZrg0"
duration: "00:10:47"
upload_order: 10
about_ko: "Chick Lit S1E10: 패러디 소설 탈고"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E10 Completion Of A Great Opus

채널: [[Lindsay Ellis]] · 길이 00:10:47 · [YouTube](https://www.youtube.com/watch?v=9uNIQ4LZrg0)

## 어떤 영상인가

Chick Lit S1E10: 패러디 소설 탈고

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
