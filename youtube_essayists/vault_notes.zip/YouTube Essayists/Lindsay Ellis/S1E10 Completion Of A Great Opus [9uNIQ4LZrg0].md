---
title: "S1E10 Completion Of A Great Opus"
channel: "Lindsay Ellis"
type: "video"
video_id: "9uNIQ4LZrg0"
url: "https://www.youtube.com/watch?v=9uNIQ4LZrg0"
duration: "00:10:47"
upload_order: 10
about: "Chick Lit S1E10: finishing the parody novel"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E10 Completion Of A Great Opus

Channel: [[Lindsay Ellis]] · Length 00:10:47 · [YouTube](https://www.youtube.com/watch?v=9uNIQ4LZrg0)

## What it is

Chick Lit S1E10: finishing the parody novel

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
