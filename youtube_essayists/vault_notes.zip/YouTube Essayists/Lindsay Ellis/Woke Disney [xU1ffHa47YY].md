---
title: "Woke Disney"
channel: "Lindsay Ellis"
type: "video"
video_id: "xU1ffHa47YY"
url: "https://www.youtube.com/watch?v=xU1ffHa47YY"
duration: "00:30:02"
upload_order: 103
about_ko: "디즈니의 '깨어있는' 마케팅 비판"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Woke Disney

채널: [[Lindsay Ellis]] · 길이 00:30:02 · [YouTube](https://www.youtube.com/watch?v=xU1ffHa47YY)

## 어떤 영상인가

디즈니의 '깨어있는' 마케팅 비판

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
