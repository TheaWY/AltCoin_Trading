---
title: "Woke Disney"
channel: "Lindsay Ellis"
type: "video"
video_id: "xU1ffHa47YY"
url: "https://www.youtube.com/watch?v=xU1ffHa47YY"
duration: "00:30:02"
upload_order: 103
about: "Critique of Disney's \"woke\" marketing"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Woke Disney

Channel: [[Lindsay Ellis]] · Length 00:30:02 · [YouTube](https://www.youtube.com/watch?v=xU1ffHa47YY)

## What it is

Critique of Disney's "woke" marketing

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
