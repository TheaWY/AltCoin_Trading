---
title: "Into The Omegaverse: How a Fanfic Trope Landed in Federal Court"
channel: "Lindsay Ellis"
type: "video"
video_id: "zhWWcWtAUoY"
url: "https://www.youtube.com/watch?v=zhWWcWtAUoY"
duration: "01:04:35"
upload_order: 111
about_ko: "팬픽 장르 오메가버스가 연방 저작권 소송까지 간 사건 분석"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Into The Omegaverse: How a Fanfic Trope Landed in Federal Court

채널: [[Lindsay Ellis]] · 길이 01:04:35 · [YouTube](https://www.youtube.com/watch?v=zhWWcWtAUoY)

## 어떤 영상인가

팬픽 장르 오메가버스가 연방 저작권 소송까지 간 사건 분석

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
