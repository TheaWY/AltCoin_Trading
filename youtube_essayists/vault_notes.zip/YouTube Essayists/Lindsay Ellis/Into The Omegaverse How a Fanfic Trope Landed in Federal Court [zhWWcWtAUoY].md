---
title: "Into The Omegaverse: How a Fanfic Trope Landed in Federal Court"
channel: "Lindsay Ellis"
type: "video"
video_id: "zhWWcWtAUoY"
url: "https://www.youtube.com/watch?v=zhWWcWtAUoY"
duration: "01:04:35"
upload_order: 111
about: "How the omegaverse fanfic trope ended up in a federal copyright case"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Into The Omegaverse: How a Fanfic Trope Landed in Federal Court

Channel: [[Lindsay Ellis]] · Length 01:04:35 · [YouTube](https://www.youtube.com/watch?v=zhWWcWtAUoY)

## What it is

How the omegaverse fanfic trope ended up in a federal copyright case

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
