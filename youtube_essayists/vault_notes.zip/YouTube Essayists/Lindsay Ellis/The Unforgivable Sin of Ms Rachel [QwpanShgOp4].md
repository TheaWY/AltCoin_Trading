---
title: "The Unforgivable Sin of Ms Rachel"
channel: "Lindsay Ellis"
type: "video"
video_id: "QwpanShgOp4"
url: "https://www.youtube.com/watch?v=QwpanShgOp4"
duration: "02:22:02"
upload_order: 121
about: "The controversy and online backlash around kids' creator Ms Rachel"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Unforgivable Sin of Ms Rachel

Channel: [[Lindsay Ellis]] · Length 02:22:02 · [YouTube](https://www.youtube.com/watch?v=QwpanShgOp4)

## What it is

The controversy and online backlash around kids' creator Ms Rachel

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
