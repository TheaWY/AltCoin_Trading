---
title: "The Unforgivable Sin of Ms Rachel"
channel: "Lindsay Ellis"
type: "video"
video_id: "QwpanShgOp4"
url: "https://www.youtube.com/watch?v=QwpanShgOp4"
duration: "02:22:02"
upload_order: 121
about_ko: "유아 콘텐츠 Ms Rachel을 둘러싼 논란과 온라인 반발을 분석"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Unforgivable Sin of Ms Rachel

채널: [[Lindsay Ellis]] · 길이 02:22:02 · [YouTube](https://www.youtube.com/watch?v=QwpanShgOp4)

## 어떤 영상인가

유아 콘텐츠 Ms Rachel을 둘러싼 논란과 온라인 반발을 분석

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
