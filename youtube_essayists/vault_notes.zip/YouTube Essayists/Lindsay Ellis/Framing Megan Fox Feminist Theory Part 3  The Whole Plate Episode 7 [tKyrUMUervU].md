---
title: "Framing Megan Fox: Feminist Theory Part 3 | The Whole Plate: Episode 7"
channel: "Lindsay Ellis"
type: "video"
video_id: "tKyrUMUervU"
url: "https://www.youtube.com/watch?v=tKyrUMUervU"
duration: "00:14:23"
upload_order: 81
about_ko: "The Whole Plate 7화: 메간 폭스와 페미니즘 이론 3부"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Framing Megan Fox: Feminist Theory Part 3 | The Whole Plate: Episode 7

채널: [[Lindsay Ellis]] · 길이 00:14:23 · [YouTube](https://www.youtube.com/watch?v=tKyrUMUervU)

## 어떤 영상인가

The Whole Plate 7화: 메간 폭스와 페미니즘 이론 3부

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
