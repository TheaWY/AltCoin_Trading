---
title: "Framing Megan Fox: Feminist Theory Part 3 | The Whole Plate: Episode 7"
channel: "Lindsay Ellis"
type: "video"
video_id: "tKyrUMUervU"
url: "https://www.youtube.com/watch?v=tKyrUMUervU"
duration: "00:14:23"
upload_order: 81
about: "The Whole Plate ep. 7: Megan Fox and feminist theory, part 3"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Framing Megan Fox: Feminist Theory Part 3 | The Whole Plate: Episode 7

Channel: [[Lindsay Ellis]] · Length 00:14:23 · [YouTube](https://www.youtube.com/watch?v=tKyrUMUervU)

## What it is

The Whole Plate ep. 7: Megan Fox and feminist theory, part 3

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
