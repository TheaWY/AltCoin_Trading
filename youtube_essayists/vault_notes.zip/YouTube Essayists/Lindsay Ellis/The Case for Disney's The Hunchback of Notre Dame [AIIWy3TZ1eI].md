---
title: "The Case for Disney's The Hunchback of Notre Dame"
channel: "Lindsay Ellis"
type: "video"
video_id: "AIIWy3TZ1eI"
url: "https://www.youtube.com/watch?v=AIIWy3TZ1eI"
duration: "00:38:11"
upload_order: 83
about_ko: "디즈니 노트르담의 꼽추를 옹호하는 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Case for Disney's The Hunchback of Notre Dame

채널: [[Lindsay Ellis]] · 길이 00:38:11 · [YouTube](https://www.youtube.com/watch?v=AIIWy3TZ1eI)

## 어떤 영상인가

디즈니 노트르담의 꼽추를 옹호하는 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
