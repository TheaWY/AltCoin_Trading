---
title: "The Case for Disney's The Hunchback of Notre Dame"
channel: "Lindsay Ellis"
type: "video"
video_id: "AIIWy3TZ1eI"
url: "https://www.youtube.com/watch?v=AIIWy3TZ1eI"
duration: "00:38:11"
upload_order: 83
about: "A defense of Disney's The Hunchback of Notre Dame"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Case for Disney's The Hunchback of Notre Dame

Channel: [[Lindsay Ellis]] · Length 00:38:11 · [YouTube](https://www.youtube.com/watch?v=AIIWy3TZ1eI)

## What it is

A defense of Disney's The Hunchback of Notre Dame

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
