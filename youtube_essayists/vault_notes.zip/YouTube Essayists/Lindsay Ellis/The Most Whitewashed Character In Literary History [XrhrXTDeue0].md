---
title: "The Most Whitewashed Character In Literary History"
channel: "Lindsay Ellis"
type: "video"
video_id: "XrhrXTDeue0"
url: "https://www.youtube.com/watch?v=XrhrXTDeue0"
duration: "00:35:51"
upload_order: 105
about: "The most whitewashed character in literature, traced through adaptations"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Most Whitewashed Character In Literary History

Channel: [[Lindsay Ellis]] · Length 00:35:51 · [YouTube](https://www.youtube.com/watch?v=XrhrXTDeue0)

## What it is

The most whitewashed character in literature, traced through adaptations

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
