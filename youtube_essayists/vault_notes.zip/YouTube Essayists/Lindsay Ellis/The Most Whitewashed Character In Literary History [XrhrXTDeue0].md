---
title: "The Most Whitewashed Character In Literary History"
channel: "Lindsay Ellis"
type: "video"
video_id: "XrhrXTDeue0"
url: "https://www.youtube.com/watch?v=XrhrXTDeue0"
duration: "00:35:51"
upload_order: 105
about_ko: "문학사에서 가장 화이트워싱된 인물(오셀로 등 각색사)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Most Whitewashed Character In Literary History

채널: [[Lindsay Ellis]] · 길이 00:35:51 · [YouTube](https://www.youtube.com/watch?v=XrhrXTDeue0)

## 어떤 영상인가

문학사에서 가장 화이트워싱된 인물(오셀로 등 각색사)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
