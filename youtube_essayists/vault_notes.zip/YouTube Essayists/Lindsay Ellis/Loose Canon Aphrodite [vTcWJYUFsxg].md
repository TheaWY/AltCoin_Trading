---
title: "Loose Canon: Aphrodite"
channel: "Lindsay Ellis"
type: "video"
video_id: "vTcWJYUFsxg"
url: "https://www.youtube.com/watch?v=vTcWJYUFsxg"
duration: "00:20:39"
upload_order: 43
about: "Loose Canon: Aphrodite"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Aphrodite

Channel: [[Lindsay Ellis]] · Length 00:20:39 · [YouTube](https://www.youtube.com/watch?v=vTcWJYUFsxg)

## What it is

Loose Canon: Aphrodite

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
