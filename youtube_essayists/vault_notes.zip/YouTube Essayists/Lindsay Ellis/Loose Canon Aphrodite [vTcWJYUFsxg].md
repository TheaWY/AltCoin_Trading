---
title: "Loose Canon: Aphrodite"
channel: "Lindsay Ellis"
type: "video"
video_id: "vTcWJYUFsxg"
url: "https://www.youtube.com/watch?v=vTcWJYUFsxg"
duration: "00:20:39"
upload_order: 43
about_ko: "Loose Canon: 아프로디테"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Aphrodite

채널: [[Lindsay Ellis]] · 길이 00:20:39 · [YouTube](https://www.youtube.com/watch?v=vTcWJYUFsxg)

## 어떤 영상인가

Loose Canon: 아프로디테

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
