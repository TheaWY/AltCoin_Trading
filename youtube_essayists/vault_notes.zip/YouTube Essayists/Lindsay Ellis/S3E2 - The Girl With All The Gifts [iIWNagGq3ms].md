---
title: "S3E2 - The Girl With All The Gifts"
channel: "Lindsay Ellis"
type: "video"
video_id: "iIWNagGq3ms"
url: "https://www.youtube.com/watch?v=iIWNagGq3ms"
duration: "00:14:22"
upload_order: 30
about: "Chick Lit S3E2: review of The Girl With All The Gifts"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S3E2 - The Girl With All The Gifts

Channel: [[Lindsay Ellis]] · Length 00:14:22 · [YouTube](https://www.youtube.com/watch?v=iIWNagGq3ms)

## What it is

Chick Lit S3E2: review of The Girl With All The Gifts

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
