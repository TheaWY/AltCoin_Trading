---
title: "S3E2 - The Girl With All The Gifts"
channel: "Lindsay Ellis"
type: "video"
video_id: "iIWNagGq3ms"
url: "https://www.youtube.com/watch?v=iIWNagGq3ms"
duration: "00:14:22"
upload_order: 30
about_ko: "Chick Lit S3E2: The Girl With All The Gifts 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S3E2 - The Girl With All The Gifts

채널: [[Lindsay Ellis]] · 길이 00:14:22 · [YouTube](https://www.youtube.com/watch?v=iIWNagGq3ms)

## 어떤 영상인가

Chick Lit S3E2: The Girl With All The Gifts 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
