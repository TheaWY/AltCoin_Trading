---
title: "S2E1 - 50 Shades of Rebranding"
channel: "Lindsay Ellis"
type: "video"
video_id: "0D_tbK9tBz4"
url: "https://www.youtube.com/watch?v=0D_tbK9tBz4"
duration: "00:10:18"
upload_order: 19
about_ko: "Chick Lit S2E1: 50 Shades 리브랜딩"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E1 - 50 Shades of Rebranding

채널: [[Lindsay Ellis]] · 길이 00:10:18 · [YouTube](https://www.youtube.com/watch?v=0D_tbK9tBz4)

## 어떤 영상인가

Chick Lit S2E1: 50 Shades 리브랜딩

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
