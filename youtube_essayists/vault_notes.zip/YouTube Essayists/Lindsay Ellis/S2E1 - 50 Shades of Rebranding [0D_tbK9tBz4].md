---
title: "S2E1 - 50 Shades of Rebranding"
channel: "Lindsay Ellis"
type: "video"
video_id: "0D_tbK9tBz4"
url: "https://www.youtube.com/watch?v=0D_tbK9tBz4"
duration: "00:10:18"
upload_order: 19
about: "Chick Lit S2E1: rebranding 50 Shades"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E1 - 50 Shades of Rebranding

Channel: [[Lindsay Ellis]] · Length 00:10:18 · [YouTube](https://www.youtube.com/watch?v=0D_tbK9tBz4)

## What it is

Chick Lit S2E1: rebranding 50 Shades

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
