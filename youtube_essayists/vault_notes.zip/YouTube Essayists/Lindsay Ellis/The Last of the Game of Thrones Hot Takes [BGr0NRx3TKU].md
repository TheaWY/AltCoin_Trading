---
title: "The Last of the Game of Thrones Hot Takes"
channel: "Lindsay Ellis"
type: "video"
video_id: "BGr0NRx3TKU"
url: "https://www.youtube.com/watch?v=BGr0NRx3TKU"
duration: "01:10:46"
upload_order: 102
about: "Critique of Game of Thrones' final season"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Last of the Game of Thrones Hot Takes

Channel: [[Lindsay Ellis]] · Length 01:10:46 · [YouTube](https://www.youtube.com/watch?v=BGr0NRx3TKU)

## What it is

Critique of Game of Thrones' final season

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
