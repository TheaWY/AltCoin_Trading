---
title: "The Last of the Game of Thrones Hot Takes"
channel: "Lindsay Ellis"
type: "video"
video_id: "BGr0NRx3TKU"
url: "https://www.youtube.com/watch?v=BGr0NRx3TKU"
duration: "01:10:46"
upload_order: 102
about_ko: "왕좌의 게임 마지막 시즌 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Last of the Game of Thrones Hot Takes

채널: [[Lindsay Ellis]] · 길이 01:10:46 · [YouTube](https://www.youtube.com/watch?v=BGr0NRx3TKU)

## 어떤 영상인가

왕좌의 게임 마지막 시즌 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
