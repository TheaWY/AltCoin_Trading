# Lindsay Ellis

123 videos + 9 Shorts

| # | Video | Length | What it is |
|---|---|---|---|
| 123 | [[I Tested Every Cruise Line to Find the Least Evil [zjPRAM0WDgw]\|I Tested Every Cruise Line to Find the Least Evil]] | 02:20:41 | Long first-person essay riding several cruise lines to find the least bad one |
| 122 | [[Did Disney Really Steal Aladdin [44chgavSaKA]\|Did Disney Really Steal Aladdin?]] | 01:07:07 | Testing the claim that Disney's Aladdin plagiarized another work |
| 121 | [[The Unforgivable Sin of Ms Rachel [QwpanShgOp4]\|The Unforgivable Sin of Ms Rachel]] | 02:22:02 | The controversy and online backlash around kids' creator Ms Rachel |
| 120 | [[Did Yoko Break Up The Beatles [SMOABV_zgrk]\|Did Yoko Break Up The Beatles?]] | 01:41:11 | Checking the popular idea that Yoko Ono broke up the Beatles |
| 119 | [[Love Never Dies The Magnificent Trashfire Sequel to Phantom of the Opera [Pfz-_WxGu3Y]\|Love Never Dies: The Magnificent Trashfire Sequel to Phantom of the Opera]] | 00:44:00 | Critique of Love Never Dies, the Phantom of the Opera sequel musical |
| 118 | [[Loki, the MCU, and Narcissism [n2Tg-OmOztM]\|Loki, the MCU, and Narcissism]] | 00:36:34 | Loki and the self-absorbed structure of MCU storytelling |
| 117 | [[9 things I wish I knew before publishing my first novel [7hZdOGB7Tgk]\|9 things I wish I knew before publishing my first novel]] | 00:23:13 | Nine things she wishes she'd known before publishing her first novel |
| 116 | [[Reevaluating The Little Mermaid before Disney horks up another live action remake [NeuLEu9ZePc]\|Reevaluating The Little Mermaid before Disney horks up another live action remake]] | 00:35:46 | Reassessing animated The Little Mermaid ahead of the live-action remake |
| 115 | [[Tracing the Roots of Pop Culture Transphobia [cHTMidTLO60]\|Tracing the Roots of Pop Culture Transphobia]] | 00:58:57 | History of transphobic portrayals in pop culture |
| 114 | [[Axiom's End Q&A [TJWAxMfFAOg]\|Axiom's End Q&A]] | 00:42:18 | Q&A about her novel Axiom's End |
| 113 | [[Why Borat Works Better in 2020 [MlqWBVea5S4]\|Why Borat Works Better in 2020]] | 00:31:00 | Why the Borat sequel works better in 2020 |
| 112 | [[Addison Cain's lawyer e-mailed me, and it only got worse from there [K3v5wFMQRqs]\|Addison Cain's lawyer e-mailed me, and it only got worse from there]] | 00:53:26 | Follow-up after author Addison Cain's lawyer emailed her about the omegaverse video |
| 111 | [[Into The Omegaverse How a Fanfic Trope Landed in Federal Court [zhWWcWtAUoY]\|Into The Omegaverse: How a Fanfic Trope Landed in Federal Court]] | 01:04:35 | How the omegaverse fanfic trope ended up in a federal copyright case |
| 110 | [[Death of the Author 2 Rowling Boogaloo [NViZYL-U8s0]\|Death of the Author 2: Rowling Boogaloo]] | 00:17:59 | Death of the Author, part two: the J.K. Rowling case |
| 109 | [[Is Titanic Good, Actually [hW4U_lfgPac]\|Is Titanic Good, Actually?]] | 00:40:37 | Is Titanic actually a good movie? |
| 108 | [[Protest Music of the Bush Era [ehbgAGlrVKE]\|Protest Music of the Bush Era]] | 00:37:47 | History of protest music during the Bush years |
| 107 | [[WHYYYYYYYYYYYYYY [CameSDK-2m8]\|WHYYYYYYYYYYYYYY]] | 00:02:41 | Short reaction video (guessed from title) |
| 106 | [[Why is Cats [G6iqAip-ZNo]\|Why is Cats?]] | 00:57:30 | Why does Cats (the film and musical) exist? |
| 105 | [[The Most Whitewashed Character In Literary History [XrhrXTDeue0]\|The Most Whitewashed Character In Literary History]] | 00:35:51 | The most whitewashed character in literature, traced through adaptations |
| 104 | [[How To Get A Book Deal in Ten Years or Less [tuRE55YH8yE]\|How To Get A Book Deal in Ten Years or Less]] | 00:31:05 | How she got a book deal after ten years of trying |
| 103 | [[Woke Disney [xU1ffHa47YY]\|Woke Disney]] | 00:30:02 | Critique of Disney's "woke" marketing |
| 102 | [[The Last of the Game of Thrones Hot Takes [BGr0NRx3TKU]\|The Last of the Game of Thrones Hot Takes]] | 01:10:46 | Critique of Game of Thrones' final season |
| 101 | [[We Need to Talk About Game of Thrones I Guess [hys_m3BPTS8]\|We Need to Talk About Game of Thrones I Guess]] | 00:44:04 | On the later seasons of Game of Thrones |
| 100 | [[How Aladdin Changed Animation (by Screwing Over Robin Williams) [nyiBdccfNkg]\|How Aladdin Changed Animation (by Screwing Over Robin Williams)]] | 00:24:00 | How Aladdin and the Robin Williams fallout changed the animation business |
| 99 | [[Independence Day vs. War of the Worlds [KioF1sTQFtE]\|Independence Day vs. War of the Worlds]] | 00:37:10 | Independence Day compared with War of the Worlds |
| 98 | [[Death of the Author [MGn9x4-Y_7A]\|Death of the Author]] | 00:30:17 | Explainer on the critical theory "death of the author" |
| 97 | [[YouTube Manufacturing Authenticity (For Fun and Profit!) [8FJEtCvb2Kw]\|YouTube: Manufacturing Authenticity (For Fun and Profit!)]] | 00:36:02 | How YouTube turns authenticity into a product |
| 96 | [[The Death of the Hollywood Movie Musical [b8o7LzGqc3E]\|The Death of the Hollywood Movie Musical]] | 00:24:57 | The decline of the Hollywood movie musical |
| 95 | [[400k Q&A! [UkfgB48jeZA]\|400k Q&A!]] | 00:26:14 | Q&A for 400k subscribers |
| 94 | [[That Time Disney Remade Beauty and the Beast [vpUx9DnQUkA]\|That Time Disney Remade Beauty and the Beast]] | 00:36:53 | Critique of Disney's live-action Beauty and the Beast remake |
| 93 | [[Marxism!  The Whole Plate Episode 9 [pFMiuAtbMO0]\|Marxism! / The Whole Plate: Episode 9]] | 00:19:02 | The Whole Plate ep. 9: Marxist criticism, using Transformers |
| 92 | [[Queering Michael Bay  The Whole Plate Episode 8 [btbAxY6P3Oc]\|Queering Michael Bay / The Whole Plate: Episode 8]] | 00:16:20 | The Whole Plate ep. 8: queer readings of Michael Bay films |
| 91 | [[The Ideology of the First Order [XAVeyXwy3BE]\|The Ideology of the First Order]] | 00:23:40 | The ideology of the First Order in Star Wars |
| 90 | [[The Hobbit The Desolation of Warners (Part 32) [Qi7t_g5QObs]\|The Hobbit: The Desolation of Warners (Part 3/2)]] | 00:30:38 | The Hobbit trilogy's studio problems, part 3 |
| 89 | [[The Hobbit Battle of Five Studios (Part 22) [ElPJr_tKkO4]\|The Hobbit: Battle of Five Studios (Part 2/2)]] | 00:34:43 | The Hobbit trilogy's studio problems, part 2 |
| 88 | [[The Hobbit A Long-Expected Autopsy (Part 12) [uTRUQ-RKfUs]\|The Hobbit: A Long-Expected Autopsy (Part 1/2)]] | 00:36:49 | Autopsy of how the Hobbit trilogy was made, part 1 |
| 87 | [[My Monster Boyfriend [YesMWAxqJ60]\|My Monster Boyfriend]] | 00:24:23 | The monster-boyfriend romance genre (The Shape of Water and others) |
| 86 | [[Bright The Apotheosis of Lazy Worldbuilding  Video Essay [gLOxQxMnEz8]\|Bright: The Apotheosis of Lazy Worldbuilding / Video Essay]] | 00:44:34 | Critique of the lazy worldbuilding in Netflix's Bright |
| 85 | [[Dear Stephenie Meyer [8O06tMbIKh0]\|Dear Stephenie Meyer]] | 00:19:09 | Essay framed as a letter to Twilight author Stephenie Meyer |
| 84 | [[Stranger Things, IT and the Upside Down of Nostalgia [Radg-Kn0jLs]\|Stranger Things, IT and the Upside Down of Nostalgia]] | 00:13:12 | Stranger Things, IT and nostalgia marketing |
| 83 | [[The Case for Disney's The Hunchback of Notre Dame [AIIWy3TZ1eI]\|The Case for Disney's The Hunchback of Notre Dame]] | 00:38:11 | A defense of Disney's The Hunchback of Notre Dame |
| 82 | [[The Revisionist World of Disney Mary Poppins, Walt Disney and Saving Mr. Banks [w9dCWUuJZLw]\|The Revisionist World of Disney: Mary Poppins, Walt Disney and Saving Mr. Banks]] | 00:25:40 | Disney's revisionism seen through Mary Poppins, Walt Disney and Saving Mr. Banks |
| 81 | [[Framing Megan Fox Feminist Theory Part 3  The Whole Plate Episode 7 [tKyrUMUervU]\|Framing Megan Fox: Feminist Theory Part 3 / The Whole Plate: Episode 7]] | 00:14:23 | The Whole Plate ep. 7: Megan Fox and feminist theory, part 3 |
| 80 | [[The Male Gaze vs. The Men Feminist Theory Part 2  The Whole Plate Episode 6 [oNkTeHpHj_I]\|The Male Gaze vs. The Men: Feminist Theory Part 2 / The Whole Plate: Episode 6]] | 00:13:40 | The Whole Plate ep. 6: male gaze theory, part 2 |
| 79 | [[The Complex Feels of Guardians of the Galaxy v.2 [8VulkN5OLEM]\|The Complex Feels of Guardians of the Galaxy v.2]] | 00:34:25 | The emotional structure of Guardians of the Galaxy Vol. 2 |
| 78 | [[Pocahontas Was a Mistake, and Here's Why! [2ARX0-AylFI]\|Pocahontas Was a Mistake, and Here's Why!]] | 00:32:56 | Why Disney's Pocahontas was a mistake |
| 77 | [[The Problem of Lady Robots Feminist Theory Part 1  The Whole Plate Episode 5 [uMfV7S5hfUo]\|The Problem of Lady Robots: Feminist Theory Part 1 / The Whole Plate: Episode 5]] | 00:12:27 | The Whole Plate ep. 5: female robots and feminist theory, part 1 |
| 76 | [[Genre  The Whole Plate Episode 4 [ZhmyIb5CF9s]\|Genre / The Whole Plate: Episode 4]] | 00:12:01 | The Whole Plate ep. 4: genre theory |
| 75 | [[Screenwriting, Staying Motivated and Microbudget Filmmaking - Conversation with David McCr [DdkiG07iWKs]\|Screenwriting, Staying Motivated and Microbudget Filmmaking - Conversation with David McCracken]] | 00:25:48 | Conversation with David McCracken on screenwriting, motivation and microbudget film |
| 74 | [[Mel Brooks, The Producers and the Ethics of Satire about N@zis [62cPPSyoQkE]\|Mel Brooks, The Producers and the Ethics of Satire about N@zis]] | 00:40:46 | Mel Brooks, The Producers and the ethics of satirizing Nazis |
| 73 | [[Why is it So Hard to Remember What Happens in Transformers  The Whole Plate Episode 3 [aE-6M7IbNSI]\|Why is it So Hard to Remember What Happens in Transformers? / The Whole Plate: Episode 3]] | 00:14:07 | The Whole Plate ep. 3: why Transformers plots are hard to remember |
| 72 | [[Auteur Theory vs. Michael Bay  The Whole Plate Episode Two [srk-tPbQVcs]\|Auteur Theory vs. Michael Bay / The Whole Plate: Episode Two]] | 00:12:32 | The Whole Plate ep. 2: auteur theory and Michael Bay |
| 71 | [[Transformers and Film Studies  The Whole Plate Episode 1 [PRXI__Wixas]\|Transformers and Film Studies / The Whole Plate: Episode 1]] | 00:08:14 | The Whole Plate ep. 1: learning film studies through Transformers |
| 70 | [[Is Beauty and the Beast About Stockholm Syndrome [syYCO0QVkZo]\|Is Beauty and the Beast About Stockholm Syndrome?]] | 00:17:07 | Is Beauty and the Beast about Stockholm syndrome? |
| 69 | [[Loose Canon Nightcrawler [puw0JxMj3eE]\|Loose Canon: Nightcrawler]] | 00:20:02 | Loose Canon: Nightcrawler's history across adaptations |
| 68 | [[Loose Canon Death [9aNax1Rhs-w]\|Loose Canon: Death]] | 00:24:07 | Loose Canon: how Death has been personified |
| 67 | [[Loose Canon King Kong [HOfnPnfp3aw]\|Loose Canon: King Kong]] | 00:21:42 | Loose Canon: King Kong across adaptations |
| 66 | [[Loose Canon The Wicked Witch of the West [xiZB4WgjJmA]\|Loose Canon: The Wicked Witch of the West]] | 00:27:18 | Loose Canon: the Wicked Witch of the West across adaptations |
| 65 | [[Loose Canon The Jacks of King Kong [KHy37toiqzA]\|Loose Canon: The Jacks of King Kong]] | 00:10:29 | Loose Canon: the Jacks who made the King Kong films |
| 64 | [[Loose Canon Captain America [FS7mCUgd9eI]\|Loose Canon: Captain America]] | 00:27:24 | Loose Canon: Captain America across adaptations |
| 63 | [[Loose Canon Hades [kmcV90cya1Y]\|Loose Canon: Hades]] | 00:22:11 | Loose Canon: Hades across adaptations |
| 62 | [[Mini-Canon Mad Max [9C047mGP6i4]\|Mini-Canon: Mad Max]] | 00:12:05 | Mini-Canon: Mad Max |
| 61 | [[Loose Canon Starscream [b3ysMBXTXDk]\|Loose Canon: Starscream]] | 00:19:59 | Loose Canon: Starscream from Transformers |
| 60 | [[Are Disney Villains Going Extinct [doQB5d3Gggw]\|Are Disney Villains Going Extinct?]] | 00:15:20 | Are Disney villains disappearing? |
| 59 | [[Planting and Payoff - Featuring Mad Max Fury Road [PLLGN7zv-3k]\|Planting and Payoff - Featuring Mad Max: Fury Road]] | 00:12:11 | Planting and payoff, using Mad Max: Fury Road |
| 58 | [[RENT - Look Pretty and Do As Little as Possible A Video Essay [q0qfFbtIj5w]\|RENT - Look Pretty and Do As Little as Possible: A Video Essay]] | 00:45:54 | Essay critiquing the film version of RENT |
| 57 | [[Loose Canon  Santa Claus [ICfD1lACsm4]\|Loose Canon:  Santa Claus]] | 00:17:25 | Loose Canon: Santa Claus |
| 56 | [[Should You Go To Film School - Conversation with Dan Olson [hrxKwUi78zc]\|Should You Go To Film School? - Conversation with Dan Olson]] | 00:28:56 | Conversation with Dan Olson on whether to go to film school |
| 55 | [[Designing the Other Aliens on Film [srul5Xd2kT4]\|Designing the Other: Aliens on Film]] | 00:11:48 | Alien design in film and the idea of the Other |
| 54 | [[How to Survive (and maybe even engage) Your Family This Thanksgiving [ds5U_0AOZ5I]\|How to Survive (and maybe even engage?) Your Family This Thanksgiving]] | 00:10:25 | How to survive a family Thanksgiving |
| 53 | [[Loose Canon Jack the Ripper [i-3gmyEluKk]\|Loose Canon: Jack the Ripper]] | 00:22:13 | Loose Canon: Jack the Ripper |
| 52 | [[How Three-Act Screenplays Work (and why it matters) [o0QO7YuKKdI]\|How Three-Act Screenplays Work (and why it matters)]] | 00:17:04 | How three-act screenplays work |
| 51 | [[Hercules, Disney's Beautiful Hot Mess a Video Essay [KznZcK7ksf4]\|Hercules, Disney's Beautiful Hot Mess: a Video Essay]] | 00:37:02 | Essay on Disney's Hercules |
| 50 | [[Loose Canon Hillary Clinton [yMi8_7UOnto]\|Loose Canon: Hillary Clinton]] | 00:17:30 | Loose Canon: Hillary Clinton's pop culture image |
| 49 | [[Loose Canon Mystique [uQB0vMwAUqI]\|Loose Canon: Mystique]] | 00:17:16 | Loose Canon: Mystique |
| 48 | [[Loose Canon 911- Part 2 [waL2lJVbAf4]\|Loose Canon: 9/11- Part 2]] | 00:27:37 | Loose Canon: 9/11 on film, part 2 |
| 47 | [[Loose Canon 911 - Part 1 [NZbH72rWAhQ]\|Loose Canon: 9/11 - Part 1]] | 00:21:56 | Loose Canon: 9/11 on film, part 1 |
| 46 | [[Mini-Canon Marilyn Monroe [MvyzRXFnqXI]\|Mini-Canon: Marilyn Monroe]] | 00:10:17 | Mini-Canon: Marilyn Monroe |
| 45 | [[Mini-Canon X-men Dying (and un-dying) [eegVnInQtfo]\|Mini-Canon: X-men Dying (and un-dying)]] | 00:07:45 | Mini-Canon: X-Men characters dying and coming back |
| 44 | [[The Epcot Challenge Drinking Around the World 2016 [gI4T6pvbIAY]\|The Epcot Challenge: Drinking Around the World 2016]] | 00:14:16 | Vlog of the Epcot "drinking around the world" challenge |
| 43 | [[Loose Canon Aphrodite [vTcWJYUFsxg]\|Loose Canon: Aphrodite]] | 00:20:39 | Loose Canon: Aphrodite |
| 42 | [[Nostalgic Woman - Lord of the Rings Return Of The King (Part 2) [2MDNYhUdd2s]\|Nostalgic Woman - Lord of the Rings: Return Of The King (Part 2)]] | 00:15:50 | Nostalgic Woman: The Return of the King, part 2 |
| 41 | [[Nostalgic Woman - Lord of the Rings Return of the King (Part 1) [Zi_zw3xDTa8]\|Nostalgic Woman - Lord of the Rings: Return of the King (Part 1)]] | 00:17:03 | Nostalgic Woman: The Return of the King, part 1 |
| 40 | [[Nostalgic Woman - Lord Of The Rings The Two Towers [SpsdoR1hmQc]\|Nostalgic Woman - Lord Of The Rings: The Two Towers]] | 00:18:06 | Nostalgic Woman: The Two Towers |
| 39 | [[Nostalgic Woman - Lord of the Rings The Fellowship of the Ring [XP6uMQL9Od4]\|Nostalgic Woman - Lord of the Rings: The Fellowship of the Ring]] | 00:19:40 | Nostalgic Woman: The Fellowship of the Ring |
| 38 | [[Joel Schumacher's Phantom of the Opera A Video Essay [-m5I_5Vnh6A]\|Joel Schumacher's Phantom of the Opera: A Video Essay]] | 00:41:25 | Essay on Joel Schumacher's Phantom of the Opera |
| 37 | [[Mini-Canon - Superhero v. Superhero A History [Lw-HyPmQn4E]\|Mini-Canon - Superhero v. Superhero: A History]] | 00:09:44 | Mini-Canon: history of hero-versus-hero films |
| 36 | [[Loose Canon Queen Elizabeth I [RZBS7HJi-n0]\|Loose Canon: Queen Elizabeth I]] | 00:19:58 | Loose Canon: Queen Elizabeth I |
| 35 | [[Loose Canon Phantom of the Opera (Part 2) After Lord Andy [hV3aptwQX94]\|Loose Canon: Phantom of the Opera (Part 2): After Lord Andy]] | 00:23:25 | Loose Canon: Phantom of the Opera, part 2 (after Andrew Lloyd Webber) |
| 34 | [[Loose Canon Phantom of the Opera (Part 1) - Before Broadway [6srPCZhecOY]\|Loose Canon: Phantom of the Opera (Part 1) - Before Broadway]] | 00:18:34 | Loose Canon: Phantom of the Opera, part 1 (before Broadway) |
| 33 | [[Mini - Canon Oscar Bait A History [nxkjLQdFmRI]\|Mini - Canon: "Oscar Bait": A History]] | 00:10:24 | Mini-Canon: history of "Oscar bait" films |
| 32 | [[Is Freddy Got Fingered a Dadaist Masterpiece [3v_wfECtCvQ]\|Is Freddy Got Fingered a Dadaist Masterpiece?]] | 00:19:40 | Is Freddy Got Fingered a Dadaist masterpiece? |
| 31 | [[S3E3 - Glory O'Brien's History of the Future by AS King [eUUfNsJdaDk]\|S3E3 - Glory O'Brien's History of the Future by AS King]] | 00:15:12 | Chick Lit S3E3: review of an A.S. King novel |
| 30 | [[S3E2 - The Girl With All The Gifts [iIWNagGq3ms]\|S3E2 - The Girl With All The Gifts]] | 00:14:22 | Chick Lit S3E2: review of The Girl With All The Gifts |
| 29 | [[S3E1 - Where We Left Off [2zRvownVlfQ]\|S3E1 - Where We Left Off]] | 00:16:04 | Chick Lit S3E1: season 3 opener |
| 28 | [[S2E9 - Author Interview Lindsay Ribar - The Fourth Wish [89WwIosrOt0]\|S2E9 - Author Interview: Lindsay Ribar - The Fourth Wish]] | 00:17:14 | Chick Lit S2E9: interview with author Lindsay Ribar |
| 27 | [[S2E11 - Lock In By John Scalzi [Yh5AIEHGC0s]\|S2E11 - Lock In By John Scalzi]] | 00:25:26 | Chick Lit S2E11: review of John Scalzi's Lock In |
| 26 | [[S2E6.5 - BEA And BookCon Roundup [-JVdZMmnfN0]\|S2E6.5 - BEA And BookCon Roundup]] | 00:10:44 | Chick Lit S2E6.5: BEA and BookCon roundup |
| 25 | [[S2E7 - Shades Of Rage [m3Xm1JFu034]\|S2E7 - Shades Of Rage]] | 00:16:16 | Chick Lit S2E7: Shades of Rage (guessed from title) |
| 24 | [[S2E8 - The Outline [cURHEvT7hTE]\|S2E8 - The Outline]] | 00:16:26 | Chick Lit S2E8: outlining a novel |
| 23 | [[S2E5 - A Peculiar Review [IpG3KmRHHXg]\|S2E5 - A Peculiar Review]] | 00:15:27 | Chick Lit S2E5: review of Miss Peregrine |
| 22 | [[S2E4 - Topical Parody [RNkjDGwhg5Y]\|S2E4 - Topical Parody]] | 00:14:33 | Chick Lit S2E4: topical parody |
| 21 | [[S2E3 - Fire and Cinder [4XgPFyuuBKk]\|S2E3 - Fire and Cinder]] | 00:14:40 | Chick Lit S2E3: Fire and Cinder (guessed from title) |
| 20 | [[S2E2 - 50 Shades of (Still) Rebranding [G6NEz_wIf6M]\|S2E2 - 50 Shades of (Still) Rebranding]] | 00:13:52 | Chick Lit S2E2: rebranding 50 Shades, part 2 |
| 19 | [[S2E1 - 50 Shades of Rebranding [0D_tbK9tBz4]\|S2E1 - 50 Shades of Rebranding]] | 00:10:18 | Chick Lit S2E1: rebranding 50 Shades |
| 18 | [[S1E18 - Parody, Satire, and Serra [plR8KFz6jVA]\|S1E18 - Parody, Satire, and Serra]] | 00:14:03 | Chick Lit S1E18: parody and satire |
| 17 | [[S1E17 - Dramatic Reading At The Launch Party [V2ubKQpKtCE]\|S1E17 - Dramatic Reading At The Launch Party]] | 00:10:16 | Chick Lit S1E17: reading at the launch party |
| 16 | [[S1E11 - Naked Came The Cthulhu [qjjaD_wbdkU]\|S1E11 - Naked Came The Cthulhu]] | 00:12:09 | Chick Lit S1E11: Naked Came The Cthulhu |
| 15 | [[S1E12 - Traditional vs. Self Publishing [mGzFUKH8948]\|S1E12 - Traditional vs. Self Publishing]] | 00:11:26 | Chick Lit S1E12: traditional vs self-publishing |
| 14 | [[S1E14 - The Cover Art Contest [lCsykiors6I]\|S1E14 - The Cover Art Contest]] | 00:09:39 | Chick Lit S1E14: cover art contest |
| 13 | [[S1E15 - Art Contest Finalists [FdiY1kXM-2k]\|S1E15 - Art Contest Finalists]] | 00:12:14 | Chick Lit S1E15: cover contest finalists |
| 12 | [[S1E16 - Cover Winner Launch Party [LmpFZFkcZcY]\|S1E16 - Cover Winner Launch Party]] | 00:04:33 | Chick Lit S1E16: cover winner and launch party |
| 11 | [[S1E13 - Poe's Law [J-T8XESu_vI]\|S1E13 - Poe's Law]] | 00:09:50 | Chick Lit S1E13: Poe's Law |
| 10 | [[S1E10 Completion Of A Great Opus [9uNIQ4LZrg0]\|S1E10 Completion Of A Great Opus]] | 00:10:47 | Chick Lit S1E10: finishing the parody novel |
| 9 | [[S1E9 - The Journey Begins [HS4N6S9EeYE]\|S1E9 - The Journey Begins]] | 00:05:56 | Chick Lit S1E9: the journey begins |
| 8 | [[S1E8 - Stiff Competition [3i9fJfamjgY]\|S1E8 - Stiff Competition]] | 00:05:20 | Chick Lit S1E8: Stiff Competition |
| 7 | [[S1E7 - Young Adult And Purple Prose [JeV90Pu5T0E]\|S1E7 - Young Adult And Purple Prose]] | 00:10:39 | Chick Lit S1E7: young adult fiction and purple prose |
| 6 | [[S1E6 - Dead Cthulhu Lies Dreaming... Of Her [1cRlVdL_b_g]\|S1E6 - Dead Cthulhu Lies Dreaming... Of Her]] | 00:14:18 | Chick Lit S1E6: writing the Cthulhu parody novel |
| 5 | [[S1E5 - Cementing An Outline [AOvW5TfJPjU]\|S1E5 - Cementing An Outline]] | 00:12:18 | Chick Lit S1E5: locking the outline |
| 4 | [[S1E4 - Our Hollow Female Protagonist [_1jkc8YHukQ]\|S1E4 - Our Hollow Female Protagonist]] | 00:12:04 | Chick Lit S1E4: building a hollow female protagonist |
| 3 | [[S1E3 - Crafting A Lovecraftian Love Story [ADjXkizEDs4]\|S1E3 - Crafting A Lovecraftian Love Story]] | 00:13:13 | Chick Lit S1E3: planning a Lovecraftian love story |
| 2 | [[S1E2 - What's Our Gimmick [sw8iTiYfWHM]\|S1E2 - What's Our Gimmick?]] | 00:09:21 | Chick Lit S1E2: picking the gimmick |
| 1 | [[S1E1 - Intro to the 50 Shades [6UWCbCRVpVo]\|S1E1 - Intro to the 50 Shades]] | 00:05:44 | Chick Lit S1E1: intro to the series about writing a 50 Shades parody |
| 9 | [[Ed Sheeran’s non-complicity merch [OPE7pTKNstM]\|Ed Sheeran’s non-complicity merch]] |  | [Short] About Ed Sheeran merch |
| 8 | [[What happened to the South Park guys [WjtWvygG5wI]\|What happened to the South Park guys?]] |  | [Short] What happened to the South Park creators? |
| 7 | [[Watch the video here on Nebula httpsnebula.tvvideoslindsayellis-bodycam-youtube [_H0zzRDQRvU]\|Watch the video here on Nebula https://nebula.tv/videos/lindsayellis-bodycam-youtube]] |  | [Short] Promo for a Nebula video on bodycam YouTube |
| 6 | [[Bluey adults! Only on Nebula and only for adults. httpsnebula.tvvideoslindsayellis-bluey-a [lkx4jLg41kc]\|Bluey adults! Only on Nebula and only for adults. https://nebula.tv/videos/lindsayellis-bluey-adults]] |  | [Short] Promo for a Nebula video on adult Bluey fans |
| 5 | [[Comparing and contrasting Disney’s flop eras, now on Nebula [97mjYqcu4lk]\|Comparing and contrasting Disney’s flop eras, now on Nebula]] |  | [Short] Promo for a Nebula video comparing Disney's flop eras |
| 4 | [[Trash Disney Rebrands  Nebula Original [6-qeMzrdKs4]\|Trash Disney Rebrands / Nebula Original]] |  | [Short] Promo for a Nebula Original on Disney rebrands |
| 3 | [[Stop helping @Little Joel [kv6YQamfBFM]\|Stop helping @Little Joel]] |  | [Short] Collab clip with Little Joel |
| 2 | [[Advance reader copies pt. 1 ft little Joel [lu95IhDV1ng]\|Advance reader copies pt. 1 ft little Joel]] |  | [Short] Advance reader copies, part 1, with Little Joel |
| 1 | [[Attention Canada!  Sale ends 128! httpswww.indigo.caen-casalemost-anticipated-sci-fi-fanta [cUTRYlIPE7I]\|Attention Canada!  Sale ends 1/28!: https://www.indigo.ca/en-ca/sale/most-anticipated-sci-fi-fantasy]] |  | [Short] Canadian bookstore sale promo |
