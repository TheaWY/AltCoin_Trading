# Lindsay Ellis

영상 123개 + Shorts 9개

| # | 영상 | 길이 | 어떤 영상인가 |
|---|---|---|---|
| 123 | [[I Tested Every Cruise Line to Find the Least Evil [zjPRAM0WDgw]\|I Tested Every Cruise Line to Find the Least Evil]] | 02:20:41 | 여러 크루즈 회사를 직접 타보며 그중 '가장 덜 나쁜' 곳을 찾는 장편 체험 에세이 |
| 122 | [[Did Disney Really Steal Aladdin [44chgavSaKA]\|Did Disney Really Steal Aladdin?]] | 01:07:07 | 디즈니 알라딘이 다른 작품을 표절했다는 주장을 검증하는 영상 |
| 121 | [[The Unforgivable Sin of Ms Rachel [QwpanShgOp4]\|The Unforgivable Sin of Ms Rachel]] | 02:22:02 | 유아 콘텐츠 Ms Rachel을 둘러싼 논란과 온라인 반발을 분석 |
| 120 | [[Did Yoko Break Up The Beatles [SMOABV_zgrk]\|Did Yoko Break Up The Beatles?]] | 01:41:11 | 오노 요코가 비틀스를 해체시켰다는 통념을 역사적으로 검증 |
| 119 | [[Love Never Dies The Magnificent Trashfire Sequel to Phantom of the Opera [Pfz-_WxGu3Y]\|Love Never Dies: The Magnificent Trashfire Sequel to Phantom of the Opera]] | 00:44:00 | 오페라의 유령 속편 뮤지컬 Love Never Dies 비평 |
| 118 | [[Loki, the MCU, and Narcissism [n2Tg-OmOztM]\|Loki, the MCU, and Narcissism]] | 00:36:34 | 드라마 로키와 MCU 서사의 자기도취적 구조 |
| 117 | [[9 things I wish I knew before publishing my first novel [7hZdOGB7Tgk]\|9 things I wish I knew before publishing my first novel]] | 00:23:13 | 첫 소설 출간 전에 알았으면 좋았을 9가지 |
| 116 | [[Reevaluating The Little Mermaid before Disney horks up another live action remake [NeuLEu9ZePc]\|Reevaluating The Little Mermaid before Disney horks up another live action remake]] | 00:35:46 | 실사판 리메이크 전에 애니메이션 인어공주를 다시 평가 |
| 115 | [[Tracing the Roots of Pop Culture Transphobia [cHTMidTLO60]\|Tracing the Roots of Pop Culture Transphobia]] | 00:58:57 | 대중문화 속 트랜스젠더 혐오 묘사의 역사 |
| 114 | [[Axiom's End Q&A [TJWAxMfFAOg]\|Axiom's End Q&A]] | 00:42:18 | 본인 소설 Axiom's End에 대한 Q&A |
| 113 | [[Why Borat Works Better in 2020 [MlqWBVea5S4]\|Why Borat Works Better in 2020]] | 00:31:00 | 보랏 속편이 2020년에 더 잘 먹히는 이유 |
| 112 | [[Addison Cain's lawyer e-mailed me, and it only got worse from there [K3v5wFMQRqs]\|Addison Cain's lawyer e-mailed me, and it only got worse from there]] | 00:53:26 | 오메가버스 영상 이후 작가 Addison Cain 측 변호사에게 받은 이메일 후일담 |
| 111 | [[Into The Omegaverse How a Fanfic Trope Landed in Federal Court [zhWWcWtAUoY]\|Into The Omegaverse: How a Fanfic Trope Landed in Federal Court]] | 01:04:35 | 팬픽 장르 오메가버스가 연방 저작권 소송까지 간 사건 분석 |
| 110 | [[Death of the Author 2 Rowling Boogaloo [NViZYL-U8s0]\|Death of the Author 2: Rowling Boogaloo]] | 00:17:59 | '작가의 죽음' 속편: J.K. 롤링 사례 |
| 109 | [[Is Titanic Good, Actually [hW4U_lfgPac]\|Is Titanic Good, Actually?]] | 00:40:37 | 영화 타이타닉은 사실 좋은 영화인가 |
| 108 | [[Protest Music of the Bush Era [ehbgAGlrVKE]\|Protest Music of the Bush Era]] | 00:37:47 | 부시 정권 시절 저항 음악의 역사 |
| 107 | [[WHYYYYYYYYYYYYYY [CameSDK-2m8]\|WHYYYYYYYYYYYYYY]] | 00:02:41 | 짧은 반응 영상(제목 기준) |
| 106 | [[Why is Cats [G6iqAip-ZNo]\|Why is Cats?]] | 00:57:30 | 영화/뮤지컬 캣츠는 왜 존재하는가 |
| 105 | [[The Most Whitewashed Character In Literary History [XrhrXTDeue0]\|The Most Whitewashed Character In Literary History]] | 00:35:51 | 문학사에서 가장 화이트워싱된 인물(오셀로 등 각색사) |
| 104 | [[How To Get A Book Deal in Ten Years or Less [tuRE55YH8yE]\|How To Get A Book Deal in Ten Years or Less]] | 00:31:05 | 10년 걸려 책 계약을 따낸 과정 |
| 103 | [[Woke Disney [xU1ffHa47YY]\|Woke Disney]] | 00:30:02 | 디즈니의 '깨어있는' 마케팅 비판 |
| 102 | [[The Last of the Game of Thrones Hot Takes [BGr0NRx3TKU]\|The Last of the Game of Thrones Hot Takes]] | 01:10:46 | 왕좌의 게임 마지막 시즌 비평 |
| 101 | [[We Need to Talk About Game of Thrones I Guess [hys_m3BPTS8]\|We Need to Talk About Game of Thrones I Guess]] | 00:44:04 | 왕좌의 게임 후반 시즌에 대한 이야기 |
| 100 | [[How Aladdin Changed Animation (by Screwing Over Robin Williams) [nyiBdccfNkg]\|How Aladdin Changed Animation (by Screwing Over Robin Williams)]] | 00:24:00 | 알라딘이 로빈 윌리엄스와의 갈등을 통해 애니메이션 업계를 바꾼 과정 |
| 99 | [[Independence Day vs. War of the Worlds [KioF1sTQFtE]\|Independence Day vs. War of the Worlds]] | 00:37:10 | 인디펜던스 데이와 우주전쟁 비교 |
| 98 | [[Death of the Author [MGn9x4-Y_7A]\|Death of the Author]] | 00:30:17 | 비평 이론 '작가의 죽음' 해설 |
| 97 | [[YouTube Manufacturing Authenticity (For Fun and Profit!) [8FJEtCvb2Kw]\|YouTube: Manufacturing Authenticity (For Fun and Profit!)]] | 00:36:02 | 유튜브가 '진정성'을 상품으로 만드는 방식 |
| 96 | [[The Death of the Hollywood Movie Musical [b8o7LzGqc3E]\|The Death of the Hollywood Movie Musical]] | 00:24:57 | 할리우드 뮤지컬 영화의 쇠퇴 |
| 95 | [[400k Q&A! [UkfgB48jeZA]\|400k Q&A!]] | 00:26:14 | 구독자 40만 기념 Q&A |
| 94 | [[That Time Disney Remade Beauty and the Beast [vpUx9DnQUkA]\|That Time Disney Remade Beauty and the Beast]] | 00:36:53 | 디즈니가 미녀와 야수를 실사로 리메이크한 일 비평 |
| 93 | [[Marxism!  The Whole Plate Episode 9 [pFMiuAtbMO0]\|Marxism! / The Whole Plate: Episode 9]] | 00:19:02 | The Whole Plate 9화: 마르크스주의 비평(트랜스포머 기반) |
| 92 | [[Queering Michael Bay  The Whole Plate Episode 8 [btbAxY6P3Oc]\|Queering Michael Bay / The Whole Plate: Episode 8]] | 00:16:20 | The Whole Plate 8화: 마이클 베이 영화의 퀴어 이론 해석 |
| 91 | [[The Ideology of the First Order [XAVeyXwy3BE]\|The Ideology of the First Order]] | 00:23:40 | 스타워즈 퍼스트 오더의 이데올로기 |
| 90 | [[The Hobbit The Desolation of Warners (Part 32) [Qi7t_g5QObs]\|The Hobbit: The Desolation of Warners (Part 3/2)]] | 00:30:38 | 호빗 3부작 제작사 문제 분석 3부 |
| 89 | [[The Hobbit Battle of Five Studios (Part 22) [ElPJr_tKkO4]\|The Hobbit: Battle of Five Studios (Part 2/2)]] | 00:34:43 | 호빗 3부작 제작사 문제 분석 2부 |
| 88 | [[The Hobbit A Long-Expected Autopsy (Part 12) [uTRUQ-RKfUs]\|The Hobbit: A Long-Expected Autopsy (Part 1/2)]] | 00:36:49 | 호빗 3부작 제작 과정 '부검' 1부 |
| 87 | [[My Monster Boyfriend [YesMWAxqJ60]\|My Monster Boyfriend]] | 00:24:23 | 괴물 남자친구 로맨스 장르(셰이프 오브 워터 등) |
| 86 | [[Bright The Apotheosis of Lazy Worldbuilding  Video Essay [gLOxQxMnEz8]\|Bright: The Apotheosis of Lazy Worldbuilding / Video Essay]] | 00:44:34 | 넷플릭스 영화 Bright의 게으른 세계관 비평 |
| 85 | [[Dear Stephenie Meyer [8O06tMbIKh0]\|Dear Stephenie Meyer]] | 00:19:09 | 트와일라잇 작가 스테프니 메이어에게 보내는 편지 형식 에세이 |
| 84 | [[Stranger Things, IT and the Upside Down of Nostalgia [Radg-Kn0jLs]\|Stranger Things, IT and the Upside Down of Nostalgia]] | 00:13:12 | 기묘한 이야기, IT와 향수 마케팅 |
| 83 | [[The Case for Disney's The Hunchback of Notre Dame [AIIWy3TZ1eI]\|The Case for Disney's The Hunchback of Notre Dame]] | 00:38:11 | 디즈니 노트르담의 꼽추를 옹호하는 영상 |
| 82 | [[The Revisionist World of Disney Mary Poppins, Walt Disney and Saving Mr. Banks [w9dCWUuJZLw]\|The Revisionist World of Disney: Mary Poppins, Walt Disney and Saving Mr. Banks]] | 00:25:40 | 메리 포핀스, 월트 디즈니, 세이빙 MR. 뱅크스로 본 디즈니의 역사 수정 |
| 81 | [[Framing Megan Fox Feminist Theory Part 3  The Whole Plate Episode 7 [tKyrUMUervU]\|Framing Megan Fox: Feminist Theory Part 3 / The Whole Plate: Episode 7]] | 00:14:23 | The Whole Plate 7화: 메간 폭스와 페미니즘 이론 3부 |
| 80 | [[The Male Gaze vs. The Men Feminist Theory Part 2  The Whole Plate Episode 6 [oNkTeHpHj_I]\|The Male Gaze vs. The Men: Feminist Theory Part 2 / The Whole Plate: Episode 6]] | 00:13:40 | The Whole Plate 6화: 남성 응시 이론 2부 |
| 79 | [[The Complex Feels of Guardians of the Galaxy v.2 [8VulkN5OLEM]\|The Complex Feels of Guardians of the Galaxy v.2]] | 00:34:25 | 가디언즈 오브 갤럭시 2의 감정 구조 |
| 78 | [[Pocahontas Was a Mistake, and Here's Why! [2ARX0-AylFI]\|Pocahontas Was a Mistake, and Here's Why!]] | 00:32:56 | 디즈니 포카혼타스가 실수였던 이유 |
| 77 | [[The Problem of Lady Robots Feminist Theory Part 1  The Whole Plate Episode 5 [uMfV7S5hfUo]\|The Problem of Lady Robots: Feminist Theory Part 1 / The Whole Plate: Episode 5]] | 00:12:27 | The Whole Plate 5화: 여성 로봇 표상과 페미니즘 이론 1부 |
| 76 | [[Genre  The Whole Plate Episode 4 [ZhmyIb5CF9s]\|Genre / The Whole Plate: Episode 4]] | 00:12:01 | The Whole Plate 4화: 장르 이론 |
| 75 | [[Screenwriting, Staying Motivated and Microbudget Filmmaking - Conversation with David McCr [DdkiG07iWKs]\|Screenwriting, Staying Motivated and Microbudget Filmmaking - Conversation with David McCracken]] | 00:25:48 | David McCracken과의 대화: 각본, 동기 유지, 초저예산 영화 |
| 74 | [[Mel Brooks, The Producers and the Ethics of Satire about N@zis [62cPPSyoQkE]\|Mel Brooks, The Producers and the Ethics of Satire about N@zis]] | 00:40:46 | 멜 브룩스의 프로듀서스와 나치 풍자의 윤리 |
| 73 | [[Why is it So Hard to Remember What Happens in Transformers  The Whole Plate Episode 3 [aE-6M7IbNSI]\|Why is it So Hard to Remember What Happens in Transformers? / The Whole Plate: Episode 3]] | 00:14:07 | The Whole Plate 3화: 트랜스포머 내용이 기억에 안 남는 이유 |
| 72 | [[Auteur Theory vs. Michael Bay  The Whole Plate Episode Two [srk-tPbQVcs]\|Auteur Theory vs. Michael Bay / The Whole Plate: Episode Two]] | 00:12:32 | The Whole Plate 2화: 작가주의 이론과 마이클 베이 |
| 71 | [[Transformers and Film Studies  The Whole Plate Episode 1 [PRXI__Wixas]\|Transformers and Film Studies / The Whole Plate: Episode 1]] | 00:08:14 | The Whole Plate 1화: 트랜스포머로 배우는 영화학 |
| 70 | [[Is Beauty and the Beast About Stockholm Syndrome [syYCO0QVkZo]\|Is Beauty and the Beast About Stockholm Syndrome?]] | 00:17:07 | 미녀와 야수는 스톡홀름 증후군 이야기인가 |
| 69 | [[Loose Canon Nightcrawler [puw0JxMj3eE]\|Loose Canon: Nightcrawler]] | 00:20:02 | Loose Canon: 엑스맨 나이트크롤러의 각색사 |
| 68 | [[Loose Canon Death [9aNax1Rhs-w]\|Loose Canon: Death]] | 00:24:07 | Loose Canon: '죽음'의 의인화 묘사사 |
| 67 | [[Loose Canon King Kong [HOfnPnfp3aw]\|Loose Canon: King Kong]] | 00:21:42 | Loose Canon: 킹콩 각색사 |
| 66 | [[Loose Canon The Wicked Witch of the West [xiZB4WgjJmA]\|Loose Canon: The Wicked Witch of the West]] | 00:27:18 | Loose Canon: 오즈의 서쪽 마녀 각색사 |
| 65 | [[Loose Canon The Jacks of King Kong [KHy37toiqzA]\|Loose Canon: The Jacks of King Kong]] | 00:10:29 | Loose Canon: 킹콩 영화를 만든 '잭'들 |
| 64 | [[Loose Canon Captain America [FS7mCUgd9eI]\|Loose Canon: Captain America]] | 00:27:24 | Loose Canon: 캡틴 아메리카 각색사 |
| 63 | [[Loose Canon Hades [kmcV90cya1Y]\|Loose Canon: Hades]] | 00:22:11 | Loose Canon: 하데스 각색사 |
| 62 | [[Mini-Canon Mad Max [9C047mGP6i4]\|Mini-Canon: Mad Max]] | 00:12:05 | Mini-Canon: 매드 맥스 |
| 61 | [[Loose Canon Starscream [b3ysMBXTXDk]\|Loose Canon: Starscream]] | 00:19:59 | Loose Canon: 트랜스포머 스타스크림 |
| 60 | [[Are Disney Villains Going Extinct [doQB5d3Gggw]\|Are Disney Villains Going Extinct?]] | 00:15:20 | 디즈니 악당은 사라지고 있는가 |
| 59 | [[Planting and Payoff - Featuring Mad Max Fury Road [PLLGN7zv-3k]\|Planting and Payoff - Featuring Mad Max: Fury Road]] | 00:12:11 | 복선과 회수: 매드 맥스 분노의 도로 사례 |
| 58 | [[RENT - Look Pretty and Do As Little as Possible A Video Essay [q0qfFbtIj5w]\|RENT - Look Pretty and Do As Little as Possible: A Video Essay]] | 00:45:54 | 뮤지컬 렌트 영화판 비평 에세이 |
| 57 | [[Loose Canon  Santa Claus [ICfD1lACsm4]\|Loose Canon:  Santa Claus]] | 00:17:25 | Loose Canon: 산타클로스 |
| 56 | [[Should You Go To Film School - Conversation with Dan Olson [hrxKwUi78zc]\|Should You Go To Film School? - Conversation with Dan Olson]] | 00:28:56 | Dan Olson과의 대화: 영화학교에 가야 하나 |
| 55 | [[Designing the Other Aliens on Film [srul5Xd2kT4]\|Designing the Other: Aliens on Film]] | 00:11:48 | 영화 속 외계인 디자인과 타자화 |
| 54 | [[How to Survive (and maybe even engage) Your Family This Thanksgiving [ds5U_0AOZ5I]\|How to Survive (and maybe even engage?) Your Family This Thanksgiving]] | 00:10:25 | 추수감사절 가족 모임에서 살아남는 법 |
| 53 | [[Loose Canon Jack the Ripper [i-3gmyEluKk]\|Loose Canon: Jack the Ripper]] | 00:22:13 | Loose Canon: 잭 더 리퍼 |
| 52 | [[How Three-Act Screenplays Work (and why it matters) [o0QO7YuKKdI]\|How Three-Act Screenplays Work (and why it matters)]] | 00:17:04 | 3막 구조 각본이 작동하는 방식 |
| 51 | [[Hercules, Disney's Beautiful Hot Mess a Video Essay [KznZcK7ksf4]\|Hercules, Disney's Beautiful Hot Mess: a Video Essay]] | 00:37:02 | 디즈니 헤라클레스 비평 에세이 |
| 50 | [[Loose Canon Hillary Clinton [yMi8_7UOnto]\|Loose Canon: Hillary Clinton]] | 00:17:30 | Loose Canon: 힐러리 클린턴의 대중문화 이미지 |
| 49 | [[Loose Canon Mystique [uQB0vMwAUqI]\|Loose Canon: Mystique]] | 00:17:16 | Loose Canon: 미스틱 |
| 48 | [[Loose Canon 911- Part 2 [waL2lJVbAf4]\|Loose Canon: 9/11- Part 2]] | 00:27:37 | Loose Canon: 9/11 영화적 재현 2부 |
| 47 | [[Loose Canon 911 - Part 1 [NZbH72rWAhQ]\|Loose Canon: 9/11 - Part 1]] | 00:21:56 | Loose Canon: 9/11 영화적 재현 1부 |
| 46 | [[Mini-Canon Marilyn Monroe [MvyzRXFnqXI]\|Mini-Canon: Marilyn Monroe]] | 00:10:17 | Mini-Canon: 마릴린 먼로 |
| 45 | [[Mini-Canon X-men Dying (and un-dying) [eegVnInQtfo]\|Mini-Canon: X-men Dying (and un-dying)]] | 00:07:45 | Mini-Canon: 엑스맨 캐릭터들의 죽음과 부활 |
| 44 | [[The Epcot Challenge Drinking Around the World 2016 [gI4T6pvbIAY]\|The Epcot Challenge: Drinking Around the World 2016]] | 00:14:16 | 엡콧 '세계 일주 음주' 챌린지 브이로그 |
| 43 | [[Loose Canon Aphrodite [vTcWJYUFsxg]\|Loose Canon: Aphrodite]] | 00:20:39 | Loose Canon: 아프로디테 |
| 42 | [[Nostalgic Woman - Lord of the Rings Return Of The King (Part 2) [2MDNYhUdd2s]\|Nostalgic Woman - Lord of the Rings: Return Of The King (Part 2)]] | 00:15:50 | Nostalgic Woman: 반지의 제왕 왕의 귀환 2부 |
| 41 | [[Nostalgic Woman - Lord of the Rings Return of the King (Part 1) [Zi_zw3xDTa8]\|Nostalgic Woman - Lord of the Rings: Return of the King (Part 1)]] | 00:17:03 | Nostalgic Woman: 반지의 제왕 왕의 귀환 1부 |
| 40 | [[Nostalgic Woman - Lord Of The Rings The Two Towers [SpsdoR1hmQc]\|Nostalgic Woman - Lord Of The Rings: The Two Towers]] | 00:18:06 | Nostalgic Woman: 반지의 제왕 두 개의 탑 |
| 39 | [[Nostalgic Woman - Lord of the Rings The Fellowship of the Ring [XP6uMQL9Od4]\|Nostalgic Woman - Lord of the Rings: The Fellowship of the Ring]] | 00:19:40 | Nostalgic Woman: 반지의 제왕 반지 원정대 |
| 38 | [[Joel Schumacher's Phantom of the Opera A Video Essay [-m5I_5Vnh6A]\|Joel Schumacher's Phantom of the Opera: A Video Essay]] | 00:41:25 | 조엘 슈마허판 오페라의 유령 비평 에세이 |
| 37 | [[Mini-Canon - Superhero v. Superhero A History [Lw-HyPmQn4E]\|Mini-Canon - Superhero v. Superhero: A History]] | 00:09:44 | Mini-Canon: 히어로끼리 싸우는 영화의 역사 |
| 36 | [[Loose Canon Queen Elizabeth I [RZBS7HJi-n0]\|Loose Canon: Queen Elizabeth I]] | 00:19:58 | Loose Canon: 엘리자베스 1세 |
| 35 | [[Loose Canon Phantom of the Opera (Part 2) After Lord Andy [hV3aptwQX94]\|Loose Canon: Phantom of the Opera (Part 2): After Lord Andy]] | 00:23:25 | Loose Canon: 오페라의 유령 2부(앤드루 로이드 웨버 이후) |
| 34 | [[Loose Canon Phantom of the Opera (Part 1) - Before Broadway [6srPCZhecOY]\|Loose Canon: Phantom of the Opera (Part 1) - Before Broadway]] | 00:18:34 | Loose Canon: 오페라의 유령 1부(브로드웨이 이전) |
| 33 | [[Mini - Canon Oscar Bait A History [nxkjLQdFmRI]\|Mini - Canon: "Oscar Bait": A History]] | 00:10:24 | Mini-Canon: '오스카 베이트' 영화의 역사 |
| 32 | [[Is Freddy Got Fingered a Dadaist Masterpiece [3v_wfECtCvQ]\|Is Freddy Got Fingered a Dadaist Masterpiece?]] | 00:19:40 | Freddy Got Fingered는 다다이즘 걸작인가 |
| 31 | [[S3E3 - Glory O'Brien's History of the Future by AS King [eUUfNsJdaDk]\|S3E3 - Glory O'Brien's History of the Future by AS King]] | 00:15:12 | Chick Lit S3E3: A.S. King 소설 리뷰 |
| 30 | [[S3E2 - The Girl With All The Gifts [iIWNagGq3ms]\|S3E2 - The Girl With All The Gifts]] | 00:14:22 | Chick Lit S3E2: The Girl With All The Gifts 리뷰 |
| 29 | [[S3E1 - Where We Left Off [2zRvownVlfQ]\|S3E1 - Where We Left Off]] | 00:16:04 | Chick Lit S3E1: 시즌 3 시작 |
| 28 | [[S2E9 - Author Interview Lindsay Ribar - The Fourth Wish [89WwIosrOt0]\|S2E9 - Author Interview: Lindsay Ribar - The Fourth Wish]] | 00:17:14 | Chick Lit S2E9: 작가 Lindsay Ribar 인터뷰 |
| 27 | [[S2E11 - Lock In By John Scalzi [Yh5AIEHGC0s]\|S2E11 - Lock In By John Scalzi]] | 00:25:26 | Chick Lit S2E11: 존 스칼지 Lock In 리뷰 |
| 26 | [[S2E6.5 - BEA And BookCon Roundup [-JVdZMmnfN0]\|S2E6.5 - BEA And BookCon Roundup]] | 00:10:44 | Chick Lit S2E6.5: BEA/BookCon 행사 정리 |
| 25 | [[S2E7 - Shades Of Rage [m3Xm1JFu034]\|S2E7 - Shades Of Rage]] | 00:16:16 | Chick Lit S2E7: Shades of Rage (제목 기준) |
| 24 | [[S2E8 - The Outline [cURHEvT7hTE]\|S2E8 - The Outline]] | 00:16:26 | Chick Lit S2E8: 소설 개요 짜기 |
| 23 | [[S2E5 - A Peculiar Review [IpG3KmRHHXg]\|S2E5 - A Peculiar Review]] | 00:15:27 | Chick Lit S2E5: 미스 페레그린 리뷰 |
| 22 | [[S2E4 - Topical Parody [RNkjDGwhg5Y]\|S2E4 - Topical Parody]] | 00:14:33 | Chick Lit S2E4: 시사 패러디 |
| 21 | [[S2E3 - Fire and Cinder [4XgPFyuuBKk]\|S2E3 - Fire and Cinder]] | 00:14:40 | Chick Lit S2E3: Fire and Cinder (제목 기준) |
| 20 | [[S2E2 - 50 Shades of (Still) Rebranding [G6NEz_wIf6M]\|S2E2 - 50 Shades of (Still) Rebranding]] | 00:13:52 | Chick Lit S2E2: 50 Shades 리브랜딩 2 |
| 19 | [[S2E1 - 50 Shades of Rebranding [0D_tbK9tBz4]\|S2E1 - 50 Shades of Rebranding]] | 00:10:18 | Chick Lit S2E1: 50 Shades 리브랜딩 |
| 18 | [[S1E18 - Parody, Satire, and Serra [plR8KFz6jVA]\|S1E18 - Parody, Satire, and Serra]] | 00:14:03 | Chick Lit S1E18: 패러디와 풍자 |
| 17 | [[S1E17 - Dramatic Reading At The Launch Party [V2ubKQpKtCE]\|S1E17 - Dramatic Reading At The Launch Party]] | 00:10:16 | Chick Lit S1E17: 출간 파티 낭독회 |
| 16 | [[S1E11 - Naked Came The Cthulhu [qjjaD_wbdkU]\|S1E11 - Naked Came The Cthulhu]] | 00:12:09 | Chick Lit S1E11: Naked Came The Cthulhu |
| 15 | [[S1E12 - Traditional vs. Self Publishing [mGzFUKH8948]\|S1E12 - Traditional vs. Self Publishing]] | 00:11:26 | Chick Lit S1E12: 전통 출판 대 자가 출판 |
| 14 | [[S1E14 - The Cover Art Contest [lCsykiors6I]\|S1E14 - The Cover Art Contest]] | 00:09:39 | Chick Lit S1E14: 표지 공모전 |
| 13 | [[S1E15 - Art Contest Finalists [FdiY1kXM-2k]\|S1E15 - Art Contest Finalists]] | 00:12:14 | Chick Lit S1E15: 표지 공모전 결선작 |
| 12 | [[S1E16 - Cover Winner Launch Party [LmpFZFkcZcY]\|S1E16 - Cover Winner Launch Party]] | 00:04:33 | Chick Lit S1E16: 표지 당선작과 출간 파티 |
| 11 | [[S1E13 - Poe's Law [J-T8XESu_vI]\|S1E13 - Poe's Law]] | 00:09:50 | Chick Lit S1E13: 포의 법칙(패러디와 진심 구분) |
| 10 | [[S1E10 Completion Of A Great Opus [9uNIQ4LZrg0]\|S1E10 Completion Of A Great Opus]] | 00:10:47 | Chick Lit S1E10: 패러디 소설 탈고 |
| 9 | [[S1E9 - The Journey Begins [HS4N6S9EeYE]\|S1E9 - The Journey Begins]] | 00:05:56 | Chick Lit S1E9: 여정의 시작 |
| 8 | [[S1E8 - Stiff Competition [3i9fJfamjgY]\|S1E8 - Stiff Competition]] | 00:05:20 | Chick Lit S1E8: Stiff Competition |
| 7 | [[S1E7 - Young Adult And Purple Prose [JeV90Pu5T0E]\|S1E7 - Young Adult And Purple Prose]] | 00:10:39 | Chick Lit S1E7: YA 장르와 과장된 문체 |
| 6 | [[S1E6 - Dead Cthulhu Lies Dreaming... Of Her [1cRlVdL_b_g]\|S1E6 - Dead Cthulhu Lies Dreaming... Of Her]] | 00:14:18 | Chick Lit S1E6: 크툴루 패러디 소설 집필 |
| 5 | [[S1E5 - Cementing An Outline [AOvW5TfJPjU]\|S1E5 - Cementing An Outline]] | 00:12:18 | Chick Lit S1E5: 개요 확정 |
| 4 | [[S1E4 - Our Hollow Female Protagonist [_1jkc8YHukQ]\|S1E4 - Our Hollow Female Protagonist]] | 00:12:04 | Chick Lit S1E4: 텅 빈 여주인공 만들기 |
| 3 | [[S1E3 - Crafting A Lovecraftian Love Story [ADjXkizEDs4]\|S1E3 - Crafting A Lovecraftian Love Story]] | 00:13:13 | Chick Lit S1E3: 러브크래프트풍 연애소설 기획 |
| 2 | [[S1E2 - What's Our Gimmick [sw8iTiYfWHM]\|S1E2 - What's Our Gimmick?]] | 00:09:21 | Chick Lit S1E2: 우리의 콘셉트 |
| 1 | [[S1E1 - Intro to the 50 Shades [6UWCbCRVpVo]\|S1E1 - Intro to the 50 Shades]] | 00:05:44 | Chick Lit S1E1: 50 Shades 패러디 소설 쓰기 시리즈 소개 |
| 9 | [[Ed Sheeran’s non-complicity merch [OPE7pTKNstM]\|Ed Sheeran’s non-complicity merch]] |  | [Shorts] 에드 시런 굿즈 관련 짧은 영상 |
| 8 | [[What happened to the South Park guys [WjtWvygG5wI]\|What happened to the South Park guys?]] |  | [Shorts] 사우스 파크 제작진은 어떻게 됐나 |
| 7 | [[Watch the video here on Nebula httpsnebula.tvvideoslindsayellis-bodycam-youtube [_H0zzRDQRvU]\|Watch the video here on Nebula https://nebula.tv/videos/lindsayellis-bodycam-youtube]] |  | [Shorts] Nebula 영상(바디캠 유튜브) 홍보 |
| 6 | [[Bluey adults! Only on Nebula and only for adults. httpsnebula.tvvideoslindsayellis-bluey-a [lkx4jLg41kc]\|Bluey adults! Only on Nebula and only for adults. https://nebula.tv/videos/lindsayellis-bluey-adults]] |  | [Shorts] Nebula 영상(Bluey 성인 팬) 홍보 |
| 5 | [[Comparing and contrasting Disney’s flop eras, now on Nebula [97mjYqcu4lk]\|Comparing and contrasting Disney’s flop eras, now on Nebula]] |  | [Shorts] 디즈니 흥행 실패기 비교 Nebula 홍보 |
| 4 | [[Trash Disney Rebrands  Nebula Original [6-qeMzrdKs4]\|Trash Disney Rebrands / Nebula Original]] |  | [Shorts] 디즈니 리브랜딩 Nebula 오리지널 홍보 |
| 3 | [[Stop helping @Little Joel [kv6YQamfBFM]\|Stop helping @Little Joel]] |  | [Shorts] Little Joel 콜라보 짧은 영상 |
| 2 | [[Advance reader copies pt. 1 ft little Joel [lu95IhDV1ng]\|Advance reader copies pt. 1 ft little Joel]] |  | [Shorts] 사전 리뷰본 1부(Little Joel 출연) |
| 1 | [[Attention Canada!  Sale ends 128! httpswww.indigo.caen-casalemost-anticipated-sci-fi-fanta [cUTRYlIPE7I]\|Attention Canada!  Sale ends 1/28!: https://www.indigo.ca/en-ca/sale/most-anticipated-sci-fi-fantasy]] |  | [Shorts] 캐나다 서점 할인 홍보 |
