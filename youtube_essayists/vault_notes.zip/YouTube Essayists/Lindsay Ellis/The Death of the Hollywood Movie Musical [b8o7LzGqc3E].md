---
title: "The Death of the Hollywood Movie Musical"
channel: "Lindsay Ellis"
type: "video"
video_id: "b8o7LzGqc3E"
url: "https://www.youtube.com/watch?v=b8o7LzGqc3E"
duration: "00:24:57"
upload_order: 96
about_ko: "할리우드 뮤지컬 영화의 쇠퇴"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Death of the Hollywood Movie Musical

채널: [[Lindsay Ellis]] · 길이 00:24:57 · [YouTube](https://www.youtube.com/watch?v=b8o7LzGqc3E)

## 어떤 영상인가

할리우드 뮤지컬 영화의 쇠퇴

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
