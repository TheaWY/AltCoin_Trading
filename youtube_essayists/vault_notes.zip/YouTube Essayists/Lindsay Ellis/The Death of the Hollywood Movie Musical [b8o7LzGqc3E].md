---
title: "The Death of the Hollywood Movie Musical"
channel: "Lindsay Ellis"
type: "video"
video_id: "b8o7LzGqc3E"
url: "https://www.youtube.com/watch?v=b8o7LzGqc3E"
duration: "00:24:57"
upload_order: 96
about: "The decline of the Hollywood movie musical"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Death of the Hollywood Movie Musical

Channel: [[Lindsay Ellis]] · Length 00:24:57 · [YouTube](https://www.youtube.com/watch?v=b8o7LzGqc3E)

## What it is

The decline of the Hollywood movie musical

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
