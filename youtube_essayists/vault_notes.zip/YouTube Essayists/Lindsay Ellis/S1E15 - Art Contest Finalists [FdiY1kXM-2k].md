---
title: "S1E15 - Art Contest Finalists"
channel: "Lindsay Ellis"
type: "video"
video_id: "FdiY1kXM-2k"
url: "https://www.youtube.com/watch?v=FdiY1kXM-2k"
duration: "00:12:14"
upload_order: 13
about_ko: "Chick Lit S1E15: 표지 공모전 결선작"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E15 - Art Contest Finalists

채널: [[Lindsay Ellis]] · 길이 00:12:14 · [YouTube](https://www.youtube.com/watch?v=FdiY1kXM-2k)

## 어떤 영상인가

Chick Lit S1E15: 표지 공모전 결선작

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
