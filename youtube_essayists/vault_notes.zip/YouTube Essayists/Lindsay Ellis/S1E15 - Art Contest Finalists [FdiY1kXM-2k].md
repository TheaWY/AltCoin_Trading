---
title: "S1E15 - Art Contest Finalists"
channel: "Lindsay Ellis"
type: "video"
video_id: "FdiY1kXM-2k"
url: "https://www.youtube.com/watch?v=FdiY1kXM-2k"
duration: "00:12:14"
upload_order: 13
about: "Chick Lit S1E15: cover contest finalists"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E15 - Art Contest Finalists

Channel: [[Lindsay Ellis]] · Length 00:12:14 · [YouTube](https://www.youtube.com/watch?v=FdiY1kXM-2k)

## What it is

Chick Lit S1E15: cover contest finalists

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
