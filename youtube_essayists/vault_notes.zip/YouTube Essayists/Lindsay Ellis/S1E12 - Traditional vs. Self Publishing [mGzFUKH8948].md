---
title: "S1E12 - Traditional vs. Self Publishing"
channel: "Lindsay Ellis"
type: "video"
video_id: "mGzFUKH8948"
url: "https://www.youtube.com/watch?v=mGzFUKH8948"
duration: "00:11:26"
upload_order: 15
about: "Chick Lit S1E12: traditional vs self-publishing"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E12 - Traditional vs. Self Publishing

Channel: [[Lindsay Ellis]] · Length 00:11:26 · [YouTube](https://www.youtube.com/watch?v=mGzFUKH8948)

## What it is

Chick Lit S1E12: traditional vs self-publishing

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
