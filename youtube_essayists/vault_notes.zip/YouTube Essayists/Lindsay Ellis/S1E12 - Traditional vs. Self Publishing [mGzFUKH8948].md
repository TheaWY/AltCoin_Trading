---
title: "S1E12 - Traditional vs. Self Publishing"
channel: "Lindsay Ellis"
type: "video"
video_id: "mGzFUKH8948"
url: "https://www.youtube.com/watch?v=mGzFUKH8948"
duration: "00:11:26"
upload_order: 15
about_ko: "Chick Lit S1E12: 전통 출판 대 자가 출판"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E12 - Traditional vs. Self Publishing

채널: [[Lindsay Ellis]] · 길이 00:11:26 · [YouTube](https://www.youtube.com/watch?v=mGzFUKH8948)

## 어떤 영상인가

Chick Lit S1E12: 전통 출판 대 자가 출판

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
