---
title: "Independence Day vs. War of the Worlds"
channel: "Lindsay Ellis"
type: "video"
video_id: "KioF1sTQFtE"
url: "https://www.youtube.com/watch?v=KioF1sTQFtE"
duration: "00:37:10"
upload_order: 99
about: "Independence Day compared with War of the Worlds"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Independence Day vs. War of the Worlds

Channel: [[Lindsay Ellis]] · Length 00:37:10 · [YouTube](https://www.youtube.com/watch?v=KioF1sTQFtE)

## What it is

Independence Day compared with War of the Worlds

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
