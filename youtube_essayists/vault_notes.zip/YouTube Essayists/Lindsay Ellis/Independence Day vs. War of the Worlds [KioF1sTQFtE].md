---
title: "Independence Day vs. War of the Worlds"
channel: "Lindsay Ellis"
type: "video"
video_id: "KioF1sTQFtE"
url: "https://www.youtube.com/watch?v=KioF1sTQFtE"
duration: "00:37:10"
upload_order: 99
about_ko: "인디펜던스 데이와 우주전쟁 비교"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Independence Day vs. War of the Worlds

채널: [[Lindsay Ellis]] · 길이 00:37:10 · [YouTube](https://www.youtube.com/watch?v=KioF1sTQFtE)

## 어떤 영상인가

인디펜던스 데이와 우주전쟁 비교

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
