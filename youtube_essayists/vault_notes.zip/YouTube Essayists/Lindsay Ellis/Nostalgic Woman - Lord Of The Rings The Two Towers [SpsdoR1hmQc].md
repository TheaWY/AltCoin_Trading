---
title: "Nostalgic Woman - Lord Of The Rings: The Two Towers"
channel: "Lindsay Ellis"
type: "video"
video_id: "SpsdoR1hmQc"
url: "https://www.youtube.com/watch?v=SpsdoR1hmQc"
duration: "00:18:06"
upload_order: 40
about_ko: "Nostalgic Woman: 반지의 제왕 두 개의 탑"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Nostalgic Woman - Lord Of The Rings: The Two Towers

채널: [[Lindsay Ellis]] · 길이 00:18:06 · [YouTube](https://www.youtube.com/watch?v=SpsdoR1hmQc)

## 어떤 영상인가

Nostalgic Woman: 반지의 제왕 두 개의 탑

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
