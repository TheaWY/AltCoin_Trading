---
title: "Nostalgic Woman - Lord Of The Rings: The Two Towers"
channel: "Lindsay Ellis"
type: "video"
video_id: "SpsdoR1hmQc"
url: "https://www.youtube.com/watch?v=SpsdoR1hmQc"
duration: "00:18:06"
upload_order: 40
about: "Nostalgic Woman: The Two Towers"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Nostalgic Woman - Lord Of The Rings: The Two Towers

Channel: [[Lindsay Ellis]] · Length 00:18:06 · [YouTube](https://www.youtube.com/watch?v=SpsdoR1hmQc)

## What it is

Nostalgic Woman: The Two Towers

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
