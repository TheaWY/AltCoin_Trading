---
title: "S2E9 - Author Interview: Lindsay Ribar - The Fourth Wish"
channel: "Lindsay Ellis"
type: "video"
video_id: "89WwIosrOt0"
url: "https://www.youtube.com/watch?v=89WwIosrOt0"
duration: "00:17:14"
upload_order: 28
about_ko: "Chick Lit S2E9: 작가 Lindsay Ribar 인터뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E9 - Author Interview: Lindsay Ribar - The Fourth Wish

채널: [[Lindsay Ellis]] · 길이 00:17:14 · [YouTube](https://www.youtube.com/watch?v=89WwIosrOt0)

## 어떤 영상인가

Chick Lit S2E9: 작가 Lindsay Ribar 인터뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
