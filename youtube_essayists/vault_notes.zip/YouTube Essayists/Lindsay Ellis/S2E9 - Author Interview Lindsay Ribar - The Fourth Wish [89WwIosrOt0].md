---
title: "S2E9 - Author Interview: Lindsay Ribar - The Fourth Wish"
channel: "Lindsay Ellis"
type: "video"
video_id: "89WwIosrOt0"
url: "https://www.youtube.com/watch?v=89WwIosrOt0"
duration: "00:17:14"
upload_order: 28
about: "Chick Lit S2E9: interview with author Lindsay Ribar"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E9 - Author Interview: Lindsay Ribar - The Fourth Wish

Channel: [[Lindsay Ellis]] · Length 00:17:14 · [YouTube](https://www.youtube.com/watch?v=89WwIosrOt0)

## What it is

Chick Lit S2E9: interview with author Lindsay Ribar

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
