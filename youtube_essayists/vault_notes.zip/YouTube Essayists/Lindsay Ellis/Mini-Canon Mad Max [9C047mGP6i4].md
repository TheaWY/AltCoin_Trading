---
title: "Mini-Canon: Mad Max"
channel: "Lindsay Ellis"
type: "video"
video_id: "9C047mGP6i4"
url: "https://www.youtube.com/watch?v=9C047mGP6i4"
duration: "00:12:05"
upload_order: 62
about_ko: "Mini-Canon: 매드 맥스"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Mini-Canon: Mad Max

채널: [[Lindsay Ellis]] · 길이 00:12:05 · [YouTube](https://www.youtube.com/watch?v=9C047mGP6i4)

## 어떤 영상인가

Mini-Canon: 매드 맥스

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
