---
title: "Mini-Canon: Mad Max"
channel: "Lindsay Ellis"
type: "video"
video_id: "9C047mGP6i4"
url: "https://www.youtube.com/watch?v=9C047mGP6i4"
duration: "00:12:05"
upload_order: 62
about: "Mini-Canon: Mad Max"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Mini-Canon: Mad Max

Channel: [[Lindsay Ellis]] · Length 00:12:05 · [YouTube](https://www.youtube.com/watch?v=9C047mGP6i4)

## What it is

Mini-Canon: Mad Max

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
