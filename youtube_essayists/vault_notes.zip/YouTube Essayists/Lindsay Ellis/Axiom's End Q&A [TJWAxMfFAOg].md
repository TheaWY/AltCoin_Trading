---
title: "Axiom's End Q&A"
channel: "Lindsay Ellis"
type: "video"
video_id: "TJWAxMfFAOg"
url: "https://www.youtube.com/watch?v=TJWAxMfFAOg"
duration: "00:42:18"
upload_order: 114
about: "Q&A about her novel Axiom's End"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Axiom's End Q&A

Channel: [[Lindsay Ellis]] · Length 00:42:18 · [YouTube](https://www.youtube.com/watch?v=TJWAxMfFAOg)

## What it is

Q&A about her novel Axiom's End

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
