---
title: "Axiom's End Q&A"
channel: "Lindsay Ellis"
type: "video"
video_id: "TJWAxMfFAOg"
url: "https://www.youtube.com/watch?v=TJWAxMfFAOg"
duration: "00:42:18"
upload_order: 114
about_ko: "본인 소설 Axiom's End에 대한 Q&A"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Axiom's End Q&A

채널: [[Lindsay Ellis]] · 길이 00:42:18 · [YouTube](https://www.youtube.com/watch?v=TJWAxMfFAOg)

## 어떤 영상인가

본인 소설 Axiom's End에 대한 Q&A

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
