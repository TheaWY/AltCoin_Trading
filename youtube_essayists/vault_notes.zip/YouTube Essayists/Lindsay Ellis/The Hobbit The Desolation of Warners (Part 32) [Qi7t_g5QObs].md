---
title: "The Hobbit: The Desolation of Warners (Part 3/2)"
channel: "Lindsay Ellis"
type: "video"
video_id: "Qi7t_g5QObs"
url: "https://www.youtube.com/watch?v=Qi7t_g5QObs"
duration: "00:30:38"
upload_order: 90
about_ko: "호빗 3부작 제작사 문제 분석 3부"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Hobbit: The Desolation of Warners (Part 3/2)

채널: [[Lindsay Ellis]] · 길이 00:30:38 · [YouTube](https://www.youtube.com/watch?v=Qi7t_g5QObs)

## 어떤 영상인가

호빗 3부작 제작사 문제 분석 3부

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
