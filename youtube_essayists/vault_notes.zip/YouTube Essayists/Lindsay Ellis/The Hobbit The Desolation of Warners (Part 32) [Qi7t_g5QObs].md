---
title: "The Hobbit: The Desolation of Warners (Part 3/2)"
channel: "Lindsay Ellis"
type: "video"
video_id: "Qi7t_g5QObs"
url: "https://www.youtube.com/watch?v=Qi7t_g5QObs"
duration: "00:30:38"
upload_order: 90
about: "The Hobbit trilogy's studio problems, part 3"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Hobbit: The Desolation of Warners (Part 3/2)

Channel: [[Lindsay Ellis]] · Length 00:30:38 · [YouTube](https://www.youtube.com/watch?v=Qi7t_g5QObs)

## What it is

The Hobbit trilogy's studio problems, part 3

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
