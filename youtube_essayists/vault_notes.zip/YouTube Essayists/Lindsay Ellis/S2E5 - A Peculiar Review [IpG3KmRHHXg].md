---
title: "S2E5 - A Peculiar Review"
channel: "Lindsay Ellis"
type: "video"
video_id: "IpG3KmRHHXg"
url: "https://www.youtube.com/watch?v=IpG3KmRHHXg"
duration: "00:15:27"
upload_order: 23
about_ko: "Chick Lit S2E5: 미스 페레그린 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E5 - A Peculiar Review

채널: [[Lindsay Ellis]] · 길이 00:15:27 · [YouTube](https://www.youtube.com/watch?v=IpG3KmRHHXg)

## 어떤 영상인가

Chick Lit S2E5: 미스 페레그린 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
