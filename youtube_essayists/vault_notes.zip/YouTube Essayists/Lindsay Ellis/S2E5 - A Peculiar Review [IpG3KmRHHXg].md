---
title: "S2E5 - A Peculiar Review"
channel: "Lindsay Ellis"
type: "video"
video_id: "IpG3KmRHHXg"
url: "https://www.youtube.com/watch?v=IpG3KmRHHXg"
duration: "00:15:27"
upload_order: 23
about: "Chick Lit S2E5: review of Miss Peregrine"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E5 - A Peculiar Review

Channel: [[Lindsay Ellis]] · Length 00:15:27 · [YouTube](https://www.youtube.com/watch?v=IpG3KmRHHXg)

## What it is

Chick Lit S2E5: review of Miss Peregrine

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
