---
title: "Love Never Dies: The Magnificent Trashfire Sequel to Phantom of the Opera"
channel: "Lindsay Ellis"
type: "video"
video_id: "Pfz-_WxGu3Y"
url: "https://www.youtube.com/watch?v=Pfz-_WxGu3Y"
duration: "00:44:00"
upload_order: 119
about_ko: "오페라의 유령 속편 뮤지컬 Love Never Dies 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Love Never Dies: The Magnificent Trashfire Sequel to Phantom of the Opera

채널: [[Lindsay Ellis]] · 길이 00:44:00 · [YouTube](https://www.youtube.com/watch?v=Pfz-_WxGu3Y)

## 어떤 영상인가

오페라의 유령 속편 뮤지컬 Love Never Dies 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
