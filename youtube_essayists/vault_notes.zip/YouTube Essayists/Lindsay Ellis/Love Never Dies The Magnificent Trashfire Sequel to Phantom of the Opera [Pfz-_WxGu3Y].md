---
title: "Love Never Dies: The Magnificent Trashfire Sequel to Phantom of the Opera"
channel: "Lindsay Ellis"
type: "video"
video_id: "Pfz-_WxGu3Y"
url: "https://www.youtube.com/watch?v=Pfz-_WxGu3Y"
duration: "00:44:00"
upload_order: 119
about: "Critique of Love Never Dies, the Phantom of the Opera sequel musical"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Love Never Dies: The Magnificent Trashfire Sequel to Phantom of the Opera

Channel: [[Lindsay Ellis]] · Length 00:44:00 · [YouTube](https://www.youtube.com/watch?v=Pfz-_WxGu3Y)

## What it is

Critique of Love Never Dies, the Phantom of the Opera sequel musical

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
