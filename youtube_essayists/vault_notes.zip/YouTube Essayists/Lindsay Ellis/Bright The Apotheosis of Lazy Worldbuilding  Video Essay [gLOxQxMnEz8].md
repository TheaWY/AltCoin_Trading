---
title: "Bright: The Apotheosis of Lazy Worldbuilding | Video Essay"
channel: "Lindsay Ellis"
type: "video"
video_id: "gLOxQxMnEz8"
url: "https://www.youtube.com/watch?v=gLOxQxMnEz8"
duration: "00:44:34"
upload_order: 86
about: "Critique of the lazy worldbuilding in Netflix's Bright"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Bright: The Apotheosis of Lazy Worldbuilding | Video Essay

Channel: [[Lindsay Ellis]] · Length 00:44:34 · [YouTube](https://www.youtube.com/watch?v=gLOxQxMnEz8)

## What it is

Critique of the lazy worldbuilding in Netflix's Bright

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
