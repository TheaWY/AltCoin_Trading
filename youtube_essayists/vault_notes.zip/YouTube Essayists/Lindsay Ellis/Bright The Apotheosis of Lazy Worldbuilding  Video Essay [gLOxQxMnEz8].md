---
title: "Bright: The Apotheosis of Lazy Worldbuilding | Video Essay"
channel: "Lindsay Ellis"
type: "video"
video_id: "gLOxQxMnEz8"
url: "https://www.youtube.com/watch?v=gLOxQxMnEz8"
duration: "00:44:34"
upload_order: 86
about_ko: "넷플릭스 영화 Bright의 게으른 세계관 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Bright: The Apotheosis of Lazy Worldbuilding | Video Essay

채널: [[Lindsay Ellis]] · 길이 00:44:34 · [YouTube](https://www.youtube.com/watch?v=gLOxQxMnEz8)

## 어떤 영상인가

넷플릭스 영화 Bright의 게으른 세계관 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
