---
title: "The Revisionist World of Disney: Mary Poppins, Walt Disney and Saving Mr. Banks"
channel: "Lindsay Ellis"
type: "video"
video_id: "w9dCWUuJZLw"
url: "https://www.youtube.com/watch?v=w9dCWUuJZLw"
duration: "00:25:40"
upload_order: 82
about_ko: "메리 포핀스, 월트 디즈니, 세이빙 MR. 뱅크스로 본 디즈니의 역사 수정"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Revisionist World of Disney: Mary Poppins, Walt Disney and Saving Mr. Banks

채널: [[Lindsay Ellis]] · 길이 00:25:40 · [YouTube](https://www.youtube.com/watch?v=w9dCWUuJZLw)

## 어떤 영상인가

메리 포핀스, 월트 디즈니, 세이빙 MR. 뱅크스로 본 디즈니의 역사 수정

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
