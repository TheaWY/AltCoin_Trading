---
title: "The Revisionist World of Disney: Mary Poppins, Walt Disney and Saving Mr. Banks"
channel: "Lindsay Ellis"
type: "video"
video_id: "w9dCWUuJZLw"
url: "https://www.youtube.com/watch?v=w9dCWUuJZLw"
duration: "00:25:40"
upload_order: 82
about: "Disney's revisionism seen through Mary Poppins, Walt Disney and Saving Mr. Banks"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Revisionist World of Disney: Mary Poppins, Walt Disney and Saving Mr. Banks

Channel: [[Lindsay Ellis]] · Length 00:25:40 · [YouTube](https://www.youtube.com/watch?v=w9dCWUuJZLw)

## What it is

Disney's revisionism seen through Mary Poppins, Walt Disney and Saving Mr. Banks

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
