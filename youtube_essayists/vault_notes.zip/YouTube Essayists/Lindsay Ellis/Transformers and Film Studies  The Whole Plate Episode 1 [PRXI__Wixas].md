---
title: "Transformers and Film Studies | The Whole Plate: Episode 1"
channel: "Lindsay Ellis"
type: "video"
video_id: "PRXI__Wixas"
url: "https://www.youtube.com/watch?v=PRXI__Wixas"
duration: "00:08:14"
upload_order: 71
about: "The Whole Plate ep. 1: learning film studies through Transformers"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Transformers and Film Studies | The Whole Plate: Episode 1

Channel: [[Lindsay Ellis]] · Length 00:08:14 · [YouTube](https://www.youtube.com/watch?v=PRXI__Wixas)

## What it is

The Whole Plate ep. 1: learning film studies through Transformers

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
