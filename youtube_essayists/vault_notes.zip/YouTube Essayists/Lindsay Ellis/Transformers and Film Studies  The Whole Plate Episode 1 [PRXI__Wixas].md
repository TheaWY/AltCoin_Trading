---
title: "Transformers and Film Studies | The Whole Plate: Episode 1"
channel: "Lindsay Ellis"
type: "video"
video_id: "PRXI__Wixas"
url: "https://www.youtube.com/watch?v=PRXI__Wixas"
duration: "00:08:14"
upload_order: 71
about_ko: "The Whole Plate 1화: 트랜스포머로 배우는 영화학"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Transformers and Film Studies | The Whole Plate: Episode 1

채널: [[Lindsay Ellis]] · 길이 00:08:14 · [YouTube](https://www.youtube.com/watch?v=PRXI__Wixas)

## 어떤 영상인가

The Whole Plate 1화: 트랜스포머로 배우는 영화학

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
