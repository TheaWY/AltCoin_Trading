---
title: "S2E2 - 50 Shades of (Still) Rebranding"
channel: "Lindsay Ellis"
type: "video"
video_id: "G6NEz_wIf6M"
url: "https://www.youtube.com/watch?v=G6NEz_wIf6M"
duration: "00:13:52"
upload_order: 20
about: "Chick Lit S2E2: rebranding 50 Shades, part 2"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E2 - 50 Shades of (Still) Rebranding

Channel: [[Lindsay Ellis]] · Length 00:13:52 · [YouTube](https://www.youtube.com/watch?v=G6NEz_wIf6M)

## What it is

Chick Lit S2E2: rebranding 50 Shades, part 2

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
