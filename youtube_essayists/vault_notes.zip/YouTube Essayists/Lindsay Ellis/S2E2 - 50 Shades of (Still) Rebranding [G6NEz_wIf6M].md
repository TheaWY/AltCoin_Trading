---
title: "S2E2 - 50 Shades of (Still) Rebranding"
channel: "Lindsay Ellis"
type: "video"
video_id: "G6NEz_wIf6M"
url: "https://www.youtube.com/watch?v=G6NEz_wIf6M"
duration: "00:13:52"
upload_order: 20
about_ko: "Chick Lit S2E2: 50 Shades 리브랜딩 2"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E2 - 50 Shades of (Still) Rebranding

채널: [[Lindsay Ellis]] · 길이 00:13:52 · [YouTube](https://www.youtube.com/watch?v=G6NEz_wIf6M)

## 어떤 영상인가

Chick Lit S2E2: 50 Shades 리브랜딩 2

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
