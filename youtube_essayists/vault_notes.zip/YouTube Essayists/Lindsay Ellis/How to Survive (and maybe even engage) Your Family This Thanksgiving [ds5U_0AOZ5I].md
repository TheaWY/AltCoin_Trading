---
title: "How to Survive (and maybe even engage?) Your Family This Thanksgiving"
channel: "Lindsay Ellis"
type: "video"
video_id: "ds5U_0AOZ5I"
url: "https://www.youtube.com/watch?v=ds5U_0AOZ5I"
duration: "00:10:25"
upload_order: 54
about_ko: "추수감사절 가족 모임에서 살아남는 법"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# How to Survive (and maybe even engage?) Your Family This Thanksgiving

채널: [[Lindsay Ellis]] · 길이 00:10:25 · [YouTube](https://www.youtube.com/watch?v=ds5U_0AOZ5I)

## 어떤 영상인가

추수감사절 가족 모임에서 살아남는 법

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
