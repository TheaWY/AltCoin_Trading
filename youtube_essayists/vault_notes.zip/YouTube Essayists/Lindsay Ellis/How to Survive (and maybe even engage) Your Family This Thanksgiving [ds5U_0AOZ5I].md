---
title: "How to Survive (and maybe even engage?) Your Family This Thanksgiving"
channel: "Lindsay Ellis"
type: "video"
video_id: "ds5U_0AOZ5I"
url: "https://www.youtube.com/watch?v=ds5U_0AOZ5I"
duration: "00:10:25"
upload_order: 54
about: "How to survive a family Thanksgiving"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# How to Survive (and maybe even engage?) Your Family This Thanksgiving

Channel: [[Lindsay Ellis]] · Length 00:10:25 · [YouTube](https://www.youtube.com/watch?v=ds5U_0AOZ5I)

## What it is

How to survive a family Thanksgiving

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
