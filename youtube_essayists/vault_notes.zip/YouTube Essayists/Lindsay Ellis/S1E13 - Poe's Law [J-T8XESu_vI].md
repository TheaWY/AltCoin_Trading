---
title: "S1E13 - Poe's Law"
channel: "Lindsay Ellis"
type: "video"
video_id: "J-T8XESu_vI"
url: "https://www.youtube.com/watch?v=J-T8XESu_vI"
duration: "00:09:50"
upload_order: 11
about: "Chick Lit S1E13: Poe's Law"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E13 - Poe's Law

Channel: [[Lindsay Ellis]] · Length 00:09:50 · [YouTube](https://www.youtube.com/watch?v=J-T8XESu_vI)

## What it is

Chick Lit S1E13: Poe's Law

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
