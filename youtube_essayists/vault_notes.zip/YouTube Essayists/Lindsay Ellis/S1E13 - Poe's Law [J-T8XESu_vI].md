---
title: "S1E13 - Poe's Law"
channel: "Lindsay Ellis"
type: "video"
video_id: "J-T8XESu_vI"
url: "https://www.youtube.com/watch?v=J-T8XESu_vI"
duration: "00:09:50"
upload_order: 11
about_ko: "Chick Lit S1E13: 포의 법칙(패러디와 진심 구분)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E13 - Poe's Law

채널: [[Lindsay Ellis]] · 길이 00:09:50 · [YouTube](https://www.youtube.com/watch?v=J-T8XESu_vI)

## 어떤 영상인가

Chick Lit S1E13: 포의 법칙(패러디와 진심 구분)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
