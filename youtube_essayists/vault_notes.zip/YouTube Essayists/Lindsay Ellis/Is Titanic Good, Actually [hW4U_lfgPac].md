---
title: "Is Titanic Good, Actually?"
channel: "Lindsay Ellis"
type: "video"
video_id: "hW4U_lfgPac"
url: "https://www.youtube.com/watch?v=hW4U_lfgPac"
duration: "00:40:37"
upload_order: 109
about: "Is Titanic actually a good movie?"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Is Titanic Good, Actually?

Channel: [[Lindsay Ellis]] · Length 00:40:37 · [YouTube](https://www.youtube.com/watch?v=hW4U_lfgPac)

## What it is

Is Titanic actually a good movie?

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
