---
title: "Is Titanic Good, Actually?"
channel: "Lindsay Ellis"
type: "video"
video_id: "hW4U_lfgPac"
url: "https://www.youtube.com/watch?v=hW4U_lfgPac"
duration: "00:40:37"
upload_order: 109
about_ko: "영화 타이타닉은 사실 좋은 영화인가"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Is Titanic Good, Actually?

채널: [[Lindsay Ellis]] · 길이 00:40:37 · [YouTube](https://www.youtube.com/watch?v=hW4U_lfgPac)

## 어떤 영상인가

영화 타이타닉은 사실 좋은 영화인가

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
