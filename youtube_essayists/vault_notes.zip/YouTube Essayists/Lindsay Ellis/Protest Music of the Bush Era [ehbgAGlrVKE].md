---
title: "Protest Music of the Bush Era"
channel: "Lindsay Ellis"
type: "video"
video_id: "ehbgAGlrVKE"
url: "https://www.youtube.com/watch?v=ehbgAGlrVKE"
duration: "00:37:47"
upload_order: 108
about_ko: "부시 정권 시절 저항 음악의 역사"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Protest Music of the Bush Era

채널: [[Lindsay Ellis]] · 길이 00:37:47 · [YouTube](https://www.youtube.com/watch?v=ehbgAGlrVKE)

## 어떤 영상인가

부시 정권 시절 저항 음악의 역사

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
