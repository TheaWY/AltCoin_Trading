---
title: "Protest Music of the Bush Era"
channel: "Lindsay Ellis"
type: "video"
video_id: "ehbgAGlrVKE"
url: "https://www.youtube.com/watch?v=ehbgAGlrVKE"
duration: "00:37:47"
upload_order: 108
about: "History of protest music during the Bush years"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Protest Music of the Bush Era

Channel: [[Lindsay Ellis]] · Length 00:37:47 · [YouTube](https://www.youtube.com/watch?v=ehbgAGlrVKE)

## What it is

History of protest music during the Bush years

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
