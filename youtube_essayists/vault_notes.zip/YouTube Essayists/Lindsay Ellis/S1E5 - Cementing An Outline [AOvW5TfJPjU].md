---
title: "S1E5 - Cementing An Outline"
channel: "Lindsay Ellis"
type: "video"
video_id: "AOvW5TfJPjU"
url: "https://www.youtube.com/watch?v=AOvW5TfJPjU"
duration: "00:12:18"
upload_order: 5
about_ko: "Chick Lit S1E5: 개요 확정"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E5 - Cementing An Outline

채널: [[Lindsay Ellis]] · 길이 00:12:18 · [YouTube](https://www.youtube.com/watch?v=AOvW5TfJPjU)

## 어떤 영상인가

Chick Lit S1E5: 개요 확정

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
