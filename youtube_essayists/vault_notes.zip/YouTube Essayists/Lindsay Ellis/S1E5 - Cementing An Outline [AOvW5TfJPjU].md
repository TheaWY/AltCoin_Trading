---
title: "S1E5 - Cementing An Outline"
channel: "Lindsay Ellis"
type: "video"
video_id: "AOvW5TfJPjU"
url: "https://www.youtube.com/watch?v=AOvW5TfJPjU"
duration: "00:12:18"
upload_order: 5
about: "Chick Lit S1E5: locking the outline"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E5 - Cementing An Outline

Channel: [[Lindsay Ellis]] · Length 00:12:18 · [YouTube](https://www.youtube.com/watch?v=AOvW5TfJPjU)

## What it is

Chick Lit S1E5: locking the outline

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
