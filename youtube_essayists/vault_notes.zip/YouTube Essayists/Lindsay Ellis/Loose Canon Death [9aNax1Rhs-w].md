---
title: "Loose Canon: Death"
channel: "Lindsay Ellis"
type: "video"
video_id: "9aNax1Rhs-w"
url: "https://www.youtube.com/watch?v=9aNax1Rhs-w"
duration: "00:24:07"
upload_order: 68
about_ko: "Loose Canon: '죽음'의 의인화 묘사사"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Death

채널: [[Lindsay Ellis]] · 길이 00:24:07 · [YouTube](https://www.youtube.com/watch?v=9aNax1Rhs-w)

## 어떤 영상인가

Loose Canon: '죽음'의 의인화 묘사사

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
