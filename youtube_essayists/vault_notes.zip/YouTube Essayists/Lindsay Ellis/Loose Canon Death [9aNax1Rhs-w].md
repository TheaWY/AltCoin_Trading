---
title: "Loose Canon: Death"
channel: "Lindsay Ellis"
type: "video"
video_id: "9aNax1Rhs-w"
url: "https://www.youtube.com/watch?v=9aNax1Rhs-w"
duration: "00:24:07"
upload_order: 68
about: "Loose Canon: how Death has been personified"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Death

Channel: [[Lindsay Ellis]] · Length 00:24:07 · [YouTube](https://www.youtube.com/watch?v=9aNax1Rhs-w)

## What it is

Loose Canon: how Death has been personified

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
