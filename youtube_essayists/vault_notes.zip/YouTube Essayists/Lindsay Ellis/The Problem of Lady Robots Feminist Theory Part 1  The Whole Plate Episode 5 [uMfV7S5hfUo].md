---
title: "The Problem of Lady Robots: Feminist Theory Part 1 | The Whole Plate: Episode 5"
channel: "Lindsay Ellis"
type: "video"
video_id: "uMfV7S5hfUo"
url: "https://www.youtube.com/watch?v=uMfV7S5hfUo"
duration: "00:12:27"
upload_order: 77
about_ko: "The Whole Plate 5화: 여성 로봇 표상과 페미니즘 이론 1부"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Problem of Lady Robots: Feminist Theory Part 1 | The Whole Plate: Episode 5

채널: [[Lindsay Ellis]] · 길이 00:12:27 · [YouTube](https://www.youtube.com/watch?v=uMfV7S5hfUo)

## 어떤 영상인가

The Whole Plate 5화: 여성 로봇 표상과 페미니즘 이론 1부

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
