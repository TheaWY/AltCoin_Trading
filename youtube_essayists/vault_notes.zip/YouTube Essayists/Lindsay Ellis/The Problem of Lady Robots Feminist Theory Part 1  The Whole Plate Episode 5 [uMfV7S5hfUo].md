---
title: "The Problem of Lady Robots: Feminist Theory Part 1 | The Whole Plate: Episode 5"
channel: "Lindsay Ellis"
type: "video"
video_id: "uMfV7S5hfUo"
url: "https://www.youtube.com/watch?v=uMfV7S5hfUo"
duration: "00:12:27"
upload_order: 77
about: "The Whole Plate ep. 5: female robots and feminist theory, part 1"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Problem of Lady Robots: Feminist Theory Part 1 | The Whole Plate: Episode 5

Channel: [[Lindsay Ellis]] · Length 00:12:27 · [YouTube](https://www.youtube.com/watch?v=uMfV7S5hfUo)

## What it is

The Whole Plate ep. 5: female robots and feminist theory, part 1

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
