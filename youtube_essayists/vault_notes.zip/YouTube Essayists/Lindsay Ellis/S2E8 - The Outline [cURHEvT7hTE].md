---
title: "S2E8 - The Outline"
channel: "Lindsay Ellis"
type: "video"
video_id: "cURHEvT7hTE"
url: "https://www.youtube.com/watch?v=cURHEvT7hTE"
duration: "00:16:26"
upload_order: 24
about: "Chick Lit S2E8: outlining a novel"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E8 - The Outline

Channel: [[Lindsay Ellis]] · Length 00:16:26 · [YouTube](https://www.youtube.com/watch?v=cURHEvT7hTE)

## What it is

Chick Lit S2E8: outlining a novel

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
