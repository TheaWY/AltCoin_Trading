---
title: "S2E8 - The Outline"
channel: "Lindsay Ellis"
type: "video"
video_id: "cURHEvT7hTE"
url: "https://www.youtube.com/watch?v=cURHEvT7hTE"
duration: "00:16:26"
upload_order: 24
about_ko: "Chick Lit S2E8: 소설 개요 짜기"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E8 - The Outline

채널: [[Lindsay Ellis]] · 길이 00:16:26 · [YouTube](https://www.youtube.com/watch?v=cURHEvT7hTE)

## 어떤 영상인가

Chick Lit S2E8: 소설 개요 짜기

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
