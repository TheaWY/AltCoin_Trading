---
title: "Mini-Canon: X-men Dying (and un-dying)"
channel: "Lindsay Ellis"
type: "video"
video_id: "eegVnInQtfo"
url: "https://www.youtube.com/watch?v=eegVnInQtfo"
duration: "00:07:45"
upload_order: 45
about_ko: "Mini-Canon: 엑스맨 캐릭터들의 죽음과 부활"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Mini-Canon: X-men Dying (and un-dying)

채널: [[Lindsay Ellis]] · 길이 00:07:45 · [YouTube](https://www.youtube.com/watch?v=eegVnInQtfo)

## 어떤 영상인가

Mini-Canon: 엑스맨 캐릭터들의 죽음과 부활

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
