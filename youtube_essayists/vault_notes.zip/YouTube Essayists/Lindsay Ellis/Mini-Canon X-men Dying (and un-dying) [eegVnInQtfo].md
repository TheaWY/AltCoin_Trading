---
title: "Mini-Canon: X-men Dying (and un-dying)"
channel: "Lindsay Ellis"
type: "video"
video_id: "eegVnInQtfo"
url: "https://www.youtube.com/watch?v=eegVnInQtfo"
duration: "00:07:45"
upload_order: 45
about: "Mini-Canon: X-Men characters dying and coming back"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Mini-Canon: X-men Dying (and un-dying)

Channel: [[Lindsay Ellis]] · Length 00:07:45 · [YouTube](https://www.youtube.com/watch?v=eegVnInQtfo)

## What it is

Mini-Canon: X-Men characters dying and coming back

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
