---
title: "Advance reader copies pt. 1 ft little Joel"
channel: "Lindsay Ellis"
type: "short"
video_id: "lu95IhDV1ng"
url: "https://www.youtube.com/watch?v=lu95IhDV1ng"
duration: ""
upload_order: 2
about: "[Short] Advance reader copies, part 1, with Little Joel"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Advance reader copies pt. 1 ft little Joel

Channel: [[Lindsay Ellis]] · Length  · [YouTube](https://www.youtube.com/watch?v=lu95IhDV1ng)

## What it is

[Short] Advance reader copies, part 1, with Little Joel

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
