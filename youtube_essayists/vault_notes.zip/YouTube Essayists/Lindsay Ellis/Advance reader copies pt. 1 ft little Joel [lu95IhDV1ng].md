---
title: "Advance reader copies pt. 1 ft little Joel"
channel: "Lindsay Ellis"
type: "short"
video_id: "lu95IhDV1ng"
url: "https://www.youtube.com/watch?v=lu95IhDV1ng"
duration: ""
upload_order: 2
about_ko: "[Shorts] 사전 리뷰본 1부(Little Joel 출연)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Advance reader copies pt. 1 ft little Joel

채널: [[Lindsay Ellis]] · 길이  · [YouTube](https://www.youtube.com/watch?v=lu95IhDV1ng)

## 어떤 영상인가

[Shorts] 사전 리뷰본 1부(Little Joel 출연)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
