---
title: "Hercules, Disney's Beautiful Hot Mess: a Video Essay"
channel: "Lindsay Ellis"
type: "video"
video_id: "KznZcK7ksf4"
url: "https://www.youtube.com/watch?v=KznZcK7ksf4"
duration: "00:37:02"
upload_order: 51
about: "Essay on Disney's Hercules"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Hercules, Disney's Beautiful Hot Mess: a Video Essay

Channel: [[Lindsay Ellis]] · Length 00:37:02 · [YouTube](https://www.youtube.com/watch?v=KznZcK7ksf4)

## What it is

Essay on Disney's Hercules

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
