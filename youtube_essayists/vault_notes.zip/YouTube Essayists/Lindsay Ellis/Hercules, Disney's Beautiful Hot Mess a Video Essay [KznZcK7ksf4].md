---
title: "Hercules, Disney's Beautiful Hot Mess: a Video Essay"
channel: "Lindsay Ellis"
type: "video"
video_id: "KznZcK7ksf4"
url: "https://www.youtube.com/watch?v=KznZcK7ksf4"
duration: "00:37:02"
upload_order: 51
about_ko: "디즈니 헤라클레스 비평 에세이"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Hercules, Disney's Beautiful Hot Mess: a Video Essay

채널: [[Lindsay Ellis]] · 길이 00:37:02 · [YouTube](https://www.youtube.com/watch?v=KznZcK7ksf4)

## 어떤 영상인가

디즈니 헤라클레스 비평 에세이

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
