---
title: "Attention Canada!  Sale ends 1/28!: https://www.indigo.ca/en-ca/sale/most-anticipated-sci-fi-fantasy"
channel: "Lindsay Ellis"
type: "short"
video_id: "cUTRYlIPE7I"
url: "https://www.youtube.com/watch?v=cUTRYlIPE7I"
duration: ""
upload_order: 1
about_ko: "[Shorts] 캐나다 서점 할인 홍보"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Attention Canada!  Sale ends 1/28!: https://www.indigo.ca/en-ca/sale/most-anticipated-sci-fi-fantasy

채널: [[Lindsay Ellis]] · 길이  · [YouTube](https://www.youtube.com/watch?v=cUTRYlIPE7I)

## 어떤 영상인가

[Shorts] 캐나다 서점 할인 홍보

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
