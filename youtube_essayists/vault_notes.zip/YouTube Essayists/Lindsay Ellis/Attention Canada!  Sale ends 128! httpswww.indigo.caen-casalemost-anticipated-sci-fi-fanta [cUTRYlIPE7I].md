---
title: "Attention Canada!  Sale ends 1/28!: https://www.indigo.ca/en-ca/sale/most-anticipated-sci-fi-fantasy"
channel: "Lindsay Ellis"
type: "short"
video_id: "cUTRYlIPE7I"
url: "https://www.youtube.com/watch?v=cUTRYlIPE7I"
duration: ""
upload_order: 1
about: "[Short] Canadian bookstore sale promo"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Attention Canada!  Sale ends 1/28!: https://www.indigo.ca/en-ca/sale/most-anticipated-sci-fi-fantasy

Channel: [[Lindsay Ellis]] · Length  · [YouTube](https://www.youtube.com/watch?v=cUTRYlIPE7I)

## What it is

[Short] Canadian bookstore sale promo

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
