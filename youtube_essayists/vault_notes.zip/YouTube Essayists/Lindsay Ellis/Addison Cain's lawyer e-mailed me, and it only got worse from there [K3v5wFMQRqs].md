---
title: "Addison Cain's lawyer e-mailed me, and it only got worse from there"
channel: "Lindsay Ellis"
type: "video"
video_id: "K3v5wFMQRqs"
url: "https://www.youtube.com/watch?v=K3v5wFMQRqs"
duration: "00:53:26"
upload_order: 112
about_ko: "오메가버스 영상 이후 작가 Addison Cain 측 변호사에게 받은 이메일 후일담"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Addison Cain's lawyer e-mailed me, and it only got worse from there

채널: [[Lindsay Ellis]] · 길이 00:53:26 · [YouTube](https://www.youtube.com/watch?v=K3v5wFMQRqs)

## 어떤 영상인가

오메가버스 영상 이후 작가 Addison Cain 측 변호사에게 받은 이메일 후일담

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
