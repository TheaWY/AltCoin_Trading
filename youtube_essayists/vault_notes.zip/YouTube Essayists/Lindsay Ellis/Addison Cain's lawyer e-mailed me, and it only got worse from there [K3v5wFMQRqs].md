---
title: "Addison Cain's lawyer e-mailed me, and it only got worse from there"
channel: "Lindsay Ellis"
type: "video"
video_id: "K3v5wFMQRqs"
url: "https://www.youtube.com/watch?v=K3v5wFMQRqs"
duration: "00:53:26"
upload_order: 112
about: "Follow-up after author Addison Cain's lawyer emailed her about the omegaverse video"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Addison Cain's lawyer e-mailed me, and it only got worse from there

Channel: [[Lindsay Ellis]] · Length 00:53:26 · [YouTube](https://www.youtube.com/watch?v=K3v5wFMQRqs)

## What it is

Follow-up after author Addison Cain's lawyer emailed her about the omegaverse video

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
