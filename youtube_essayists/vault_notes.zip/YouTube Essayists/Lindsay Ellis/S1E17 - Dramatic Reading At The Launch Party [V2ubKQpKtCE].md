---
title: "S1E17 - Dramatic Reading At The Launch Party"
channel: "Lindsay Ellis"
type: "video"
video_id: "V2ubKQpKtCE"
url: "https://www.youtube.com/watch?v=V2ubKQpKtCE"
duration: "00:10:16"
upload_order: 17
about_ko: "Chick Lit S1E17: 출간 파티 낭독회"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E17 - Dramatic Reading At The Launch Party

채널: [[Lindsay Ellis]] · 길이 00:10:16 · [YouTube](https://www.youtube.com/watch?v=V2ubKQpKtCE)

## 어떤 영상인가

Chick Lit S1E17: 출간 파티 낭독회

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
