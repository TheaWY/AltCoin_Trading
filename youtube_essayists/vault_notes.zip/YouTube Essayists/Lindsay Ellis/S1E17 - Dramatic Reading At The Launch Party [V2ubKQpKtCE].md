---
title: "S1E17 - Dramatic Reading At The Launch Party"
channel: "Lindsay Ellis"
type: "video"
video_id: "V2ubKQpKtCE"
url: "https://www.youtube.com/watch?v=V2ubKQpKtCE"
duration: "00:10:16"
upload_order: 17
about: "Chick Lit S1E17: reading at the launch party"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E17 - Dramatic Reading At The Launch Party

Channel: [[Lindsay Ellis]] · Length 00:10:16 · [YouTube](https://www.youtube.com/watch?v=V2ubKQpKtCE)

## What it is

Chick Lit S1E17: reading at the launch party

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
