---
title: "S1E11 - Naked Came The Cthulhu"
channel: "Lindsay Ellis"
type: "video"
video_id: "qjjaD_wbdkU"
url: "https://www.youtube.com/watch?v=qjjaD_wbdkU"
duration: "00:12:09"
upload_order: 16
about_ko: "Chick Lit S1E11: Naked Came The Cthulhu"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E11 - Naked Came The Cthulhu

채널: [[Lindsay Ellis]] · 길이 00:12:09 · [YouTube](https://www.youtube.com/watch?v=qjjaD_wbdkU)

## 어떤 영상인가

Chick Lit S1E11: Naked Came The Cthulhu

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
