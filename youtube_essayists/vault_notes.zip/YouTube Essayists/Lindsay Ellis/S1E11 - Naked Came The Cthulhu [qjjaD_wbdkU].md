---
title: "S1E11 - Naked Came The Cthulhu"
channel: "Lindsay Ellis"
type: "video"
video_id: "qjjaD_wbdkU"
url: "https://www.youtube.com/watch?v=qjjaD_wbdkU"
duration: "00:12:09"
upload_order: 16
about: "Chick Lit S1E11: Naked Came The Cthulhu"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E11 - Naked Came The Cthulhu

Channel: [[Lindsay Ellis]] · Length 00:12:09 · [YouTube](https://www.youtube.com/watch?v=qjjaD_wbdkU)

## What it is

Chick Lit S1E11: Naked Came The Cthulhu

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
