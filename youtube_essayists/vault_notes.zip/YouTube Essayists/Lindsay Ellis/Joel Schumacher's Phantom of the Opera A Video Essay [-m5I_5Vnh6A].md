---
title: "Joel Schumacher's Phantom of the Opera: A Video Essay"
channel: "Lindsay Ellis"
type: "video"
video_id: "-m5I_5Vnh6A"
url: "https://www.youtube.com/watch?v=-m5I_5Vnh6A"
duration: "00:41:25"
upload_order: 38
about: "Essay on Joel Schumacher's Phantom of the Opera"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Joel Schumacher's Phantom of the Opera: A Video Essay

Channel: [[Lindsay Ellis]] · Length 00:41:25 · [YouTube](https://www.youtube.com/watch?v=-m5I_5Vnh6A)

## What it is

Essay on Joel Schumacher's Phantom of the Opera

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
