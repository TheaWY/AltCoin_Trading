---
title: "Joel Schumacher's Phantom of the Opera: A Video Essay"
channel: "Lindsay Ellis"
type: "video"
video_id: "-m5I_5Vnh6A"
url: "https://www.youtube.com/watch?v=-m5I_5Vnh6A"
duration: "00:41:25"
upload_order: 38
about_ko: "조엘 슈마허판 오페라의 유령 비평 에세이"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Joel Schumacher's Phantom of the Opera: A Video Essay

채널: [[Lindsay Ellis]] · 길이 00:41:25 · [YouTube](https://www.youtube.com/watch?v=-m5I_5Vnh6A)

## 어떤 영상인가

조엘 슈마허판 오페라의 유령 비평 에세이

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
