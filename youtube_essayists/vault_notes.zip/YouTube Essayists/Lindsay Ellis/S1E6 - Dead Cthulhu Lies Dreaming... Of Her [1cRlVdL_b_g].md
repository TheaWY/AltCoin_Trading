---
title: "S1E6 - Dead Cthulhu Lies Dreaming... Of Her"
channel: "Lindsay Ellis"
type: "video"
video_id: "1cRlVdL_b_g"
url: "https://www.youtube.com/watch?v=1cRlVdL_b_g"
duration: "00:14:18"
upload_order: 6
about_ko: "Chick Lit S1E6: 크툴루 패러디 소설 집필"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E6 - Dead Cthulhu Lies Dreaming... Of Her

채널: [[Lindsay Ellis]] · 길이 00:14:18 · [YouTube](https://www.youtube.com/watch?v=1cRlVdL_b_g)

## 어떤 영상인가

Chick Lit S1E6: 크툴루 패러디 소설 집필

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
