---
title: "S1E6 - Dead Cthulhu Lies Dreaming... Of Her"
channel: "Lindsay Ellis"
type: "video"
video_id: "1cRlVdL_b_g"
url: "https://www.youtube.com/watch?v=1cRlVdL_b_g"
duration: "00:14:18"
upload_order: 6
about: "Chick Lit S1E6: writing the Cthulhu parody novel"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E6 - Dead Cthulhu Lies Dreaming... Of Her

Channel: [[Lindsay Ellis]] · Length 00:14:18 · [YouTube](https://www.youtube.com/watch?v=1cRlVdL_b_g)

## What it is

Chick Lit S1E6: writing the Cthulhu parody novel

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
