---
title: "Mel Brooks, The Producers and the Ethics of Satire about N@zis"
channel: "Lindsay Ellis"
type: "video"
video_id: "62cPPSyoQkE"
url: "https://www.youtube.com/watch?v=62cPPSyoQkE"
duration: "00:40:46"
upload_order: 74
about_ko: "멜 브룩스의 프로듀서스와 나치 풍자의 윤리"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Mel Brooks, The Producers and the Ethics of Satire about N@zis

채널: [[Lindsay Ellis]] · 길이 00:40:46 · [YouTube](https://www.youtube.com/watch?v=62cPPSyoQkE)

## 어떤 영상인가

멜 브룩스의 프로듀서스와 나치 풍자의 윤리

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
