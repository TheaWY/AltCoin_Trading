---
title: "Mel Brooks, The Producers and the Ethics of Satire about N@zis"
channel: "Lindsay Ellis"
type: "video"
video_id: "62cPPSyoQkE"
url: "https://www.youtube.com/watch?v=62cPPSyoQkE"
duration: "00:40:46"
upload_order: 74
about: "Mel Brooks, The Producers and the ethics of satirizing Nazis"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Mel Brooks, The Producers and the Ethics of Satire about N@zis

Channel: [[Lindsay Ellis]] · Length 00:40:46 · [YouTube](https://www.youtube.com/watch?v=62cPPSyoQkE)

## What it is

Mel Brooks, The Producers and the ethics of satirizing Nazis

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
