---
title: "S3E1 - Where We Left Off"
channel: "Lindsay Ellis"
type: "video"
video_id: "2zRvownVlfQ"
url: "https://www.youtube.com/watch?v=2zRvownVlfQ"
duration: "00:16:04"
upload_order: 29
about_ko: "Chick Lit S3E1: 시즌 3 시작"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S3E1 - Where We Left Off

채널: [[Lindsay Ellis]] · 길이 00:16:04 · [YouTube](https://www.youtube.com/watch?v=2zRvownVlfQ)

## 어떤 영상인가

Chick Lit S3E1: 시즌 3 시작

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
