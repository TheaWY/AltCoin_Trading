---
title: "S3E1 - Where We Left Off"
channel: "Lindsay Ellis"
type: "video"
video_id: "2zRvownVlfQ"
url: "https://www.youtube.com/watch?v=2zRvownVlfQ"
duration: "00:16:04"
upload_order: 29
about: "Chick Lit S3E1: season 3 opener"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S3E1 - Where We Left Off

Channel: [[Lindsay Ellis]] · Length 00:16:04 · [YouTube](https://www.youtube.com/watch?v=2zRvownVlfQ)

## What it is

Chick Lit S3E1: season 3 opener

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
