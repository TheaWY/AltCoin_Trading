---
title: "YouTube: Manufacturing Authenticity (For Fun and Profit!)"
channel: "Lindsay Ellis"
type: "video"
video_id: "8FJEtCvb2Kw"
url: "https://www.youtube.com/watch?v=8FJEtCvb2Kw"
duration: "00:36:02"
upload_order: 97
about_ko: "유튜브가 '진정성'을 상품으로 만드는 방식"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# YouTube: Manufacturing Authenticity (For Fun and Profit!)

채널: [[Lindsay Ellis]] · 길이 00:36:02 · [YouTube](https://www.youtube.com/watch?v=8FJEtCvb2Kw)

## 어떤 영상인가

유튜브가 '진정성'을 상품으로 만드는 방식

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
