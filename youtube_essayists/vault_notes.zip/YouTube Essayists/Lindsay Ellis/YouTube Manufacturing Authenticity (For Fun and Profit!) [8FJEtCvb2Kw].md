---
title: "YouTube: Manufacturing Authenticity (For Fun and Profit!)"
channel: "Lindsay Ellis"
type: "video"
video_id: "8FJEtCvb2Kw"
url: "https://www.youtube.com/watch?v=8FJEtCvb2Kw"
duration: "00:36:02"
upload_order: 97
about: "How YouTube turns authenticity into a product"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# YouTube: Manufacturing Authenticity (For Fun and Profit!)

Channel: [[Lindsay Ellis]] · Length 00:36:02 · [YouTube](https://www.youtube.com/watch?v=8FJEtCvb2Kw)

## What it is

How YouTube turns authenticity into a product

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
