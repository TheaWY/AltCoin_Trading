---
title: "S1E7 - Young Adult And Purple Prose"
channel: "Lindsay Ellis"
type: "video"
video_id: "JeV90Pu5T0E"
url: "https://www.youtube.com/watch?v=JeV90Pu5T0E"
duration: "00:10:39"
upload_order: 7
about_ko: "Chick Lit S1E7: YA 장르와 과장된 문체"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E7 - Young Adult And Purple Prose

채널: [[Lindsay Ellis]] · 길이 00:10:39 · [YouTube](https://www.youtube.com/watch?v=JeV90Pu5T0E)

## 어떤 영상인가

Chick Lit S1E7: YA 장르와 과장된 문체

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
