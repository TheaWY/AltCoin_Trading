---
title: "S1E7 - Young Adult And Purple Prose"
channel: "Lindsay Ellis"
type: "video"
video_id: "JeV90Pu5T0E"
url: "https://www.youtube.com/watch?v=JeV90Pu5T0E"
duration: "00:10:39"
upload_order: 7
about: "Chick Lit S1E7: young adult fiction and purple prose"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E7 - Young Adult And Purple Prose

Channel: [[Lindsay Ellis]] · Length 00:10:39 · [YouTube](https://www.youtube.com/watch?v=JeV90Pu5T0E)

## What it is

Chick Lit S1E7: young adult fiction and purple prose

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
