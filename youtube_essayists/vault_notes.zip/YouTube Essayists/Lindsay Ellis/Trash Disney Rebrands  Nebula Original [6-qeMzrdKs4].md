---
title: "Trash Disney Rebrands | Nebula Original"
channel: "Lindsay Ellis"
type: "short"
video_id: "6-qeMzrdKs4"
url: "https://www.youtube.com/watch?v=6-qeMzrdKs4"
duration: ""
upload_order: 4
about_ko: "[Shorts] 디즈니 리브랜딩 Nebula 오리지널 홍보"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Trash Disney Rebrands | Nebula Original

채널: [[Lindsay Ellis]] · 길이  · [YouTube](https://www.youtube.com/watch?v=6-qeMzrdKs4)

## 어떤 영상인가

[Shorts] 디즈니 리브랜딩 Nebula 오리지널 홍보

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
