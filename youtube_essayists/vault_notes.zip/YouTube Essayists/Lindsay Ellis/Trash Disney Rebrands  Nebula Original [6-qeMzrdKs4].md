---
title: "Trash Disney Rebrands | Nebula Original"
channel: "Lindsay Ellis"
type: "short"
video_id: "6-qeMzrdKs4"
url: "https://www.youtube.com/watch?v=6-qeMzrdKs4"
duration: ""
upload_order: 4
about: "[Short] Promo for a Nebula Original on Disney rebrands"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Trash Disney Rebrands | Nebula Original

Channel: [[Lindsay Ellis]] · Length  · [YouTube](https://www.youtube.com/watch?v=6-qeMzrdKs4)

## What it is

[Short] Promo for a Nebula Original on Disney rebrands

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
