---
title: "Genre | The Whole Plate: Episode 4"
channel: "Lindsay Ellis"
type: "video"
video_id: "ZhmyIb5CF9s"
url: "https://www.youtube.com/watch?v=ZhmyIb5CF9s"
duration: "00:12:01"
upload_order: 76
about_ko: "The Whole Plate 4화: 장르 이론"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Genre | The Whole Plate: Episode 4

채널: [[Lindsay Ellis]] · 길이 00:12:01 · [YouTube](https://www.youtube.com/watch?v=ZhmyIb5CF9s)

## 어떤 영상인가

The Whole Plate 4화: 장르 이론

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
