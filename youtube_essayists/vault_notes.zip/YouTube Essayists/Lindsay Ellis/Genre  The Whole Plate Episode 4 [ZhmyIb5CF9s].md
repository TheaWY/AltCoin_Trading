---
title: "Genre | The Whole Plate: Episode 4"
channel: "Lindsay Ellis"
type: "video"
video_id: "ZhmyIb5CF9s"
url: "https://www.youtube.com/watch?v=ZhmyIb5CF9s"
duration: "00:12:01"
upload_order: 76
about: "The Whole Plate ep. 4: genre theory"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Genre | The Whole Plate: Episode 4

Channel: [[Lindsay Ellis]] · Length 00:12:01 · [YouTube](https://www.youtube.com/watch?v=ZhmyIb5CF9s)

## What it is

The Whole Plate ep. 4: genre theory

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
