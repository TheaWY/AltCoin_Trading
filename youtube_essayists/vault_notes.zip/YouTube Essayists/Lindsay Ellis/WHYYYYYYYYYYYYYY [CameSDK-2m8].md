---
title: "WHYYYYYYYYYYYYYY"
channel: "Lindsay Ellis"
type: "video"
video_id: "CameSDK-2m8"
url: "https://www.youtube.com/watch?v=CameSDK-2m8"
duration: "00:02:41"
upload_order: 107
about_ko: "짧은 반응 영상(제목 기준)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# WHYYYYYYYYYYYYYY

채널: [[Lindsay Ellis]] · 길이 00:02:41 · [YouTube](https://www.youtube.com/watch?v=CameSDK-2m8)

## 어떤 영상인가

짧은 반응 영상(제목 기준)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
