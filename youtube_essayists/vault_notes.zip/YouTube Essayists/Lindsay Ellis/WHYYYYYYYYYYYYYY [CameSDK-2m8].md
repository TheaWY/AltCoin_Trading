---
title: "WHYYYYYYYYYYYYYY"
channel: "Lindsay Ellis"
type: "video"
video_id: "CameSDK-2m8"
url: "https://www.youtube.com/watch?v=CameSDK-2m8"
duration: "00:02:41"
upload_order: 107
about: "Short reaction video (guessed from title)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# WHYYYYYYYYYYYYYY

Channel: [[Lindsay Ellis]] · Length 00:02:41 · [YouTube](https://www.youtube.com/watch?v=CameSDK-2m8)

## What it is

Short reaction video (guessed from title)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
