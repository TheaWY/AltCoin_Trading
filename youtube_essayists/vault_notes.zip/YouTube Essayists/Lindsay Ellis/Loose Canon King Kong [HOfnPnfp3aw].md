---
title: "Loose Canon: King Kong"
channel: "Lindsay Ellis"
type: "video"
video_id: "HOfnPnfp3aw"
url: "https://www.youtube.com/watch?v=HOfnPnfp3aw"
duration: "00:21:42"
upload_order: 67
about_ko: "Loose Canon: 킹콩 각색사"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: King Kong

채널: [[Lindsay Ellis]] · 길이 00:21:42 · [YouTube](https://www.youtube.com/watch?v=HOfnPnfp3aw)

## 어떤 영상인가

Loose Canon: 킹콩 각색사

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
