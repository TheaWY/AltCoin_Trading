---
title: "Loose Canon: King Kong"
channel: "Lindsay Ellis"
type: "video"
video_id: "HOfnPnfp3aw"
url: "https://www.youtube.com/watch?v=HOfnPnfp3aw"
duration: "00:21:42"
upload_order: 67
about: "Loose Canon: King Kong across adaptations"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: King Kong

Channel: [[Lindsay Ellis]] · Length 00:21:42 · [YouTube](https://www.youtube.com/watch?v=HOfnPnfp3aw)

## What it is

Loose Canon: King Kong across adaptations

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
