---
title: "S1E3 - Crafting A Lovecraftian Love Story"
channel: "Lindsay Ellis"
type: "video"
video_id: "ADjXkizEDs4"
url: "https://www.youtube.com/watch?v=ADjXkizEDs4"
duration: "00:13:13"
upload_order: 3
about: "Chick Lit S1E3: planning a Lovecraftian love story"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E3 - Crafting A Lovecraftian Love Story

Channel: [[Lindsay Ellis]] · Length 00:13:13 · [YouTube](https://www.youtube.com/watch?v=ADjXkizEDs4)

## What it is

Chick Lit S1E3: planning a Lovecraftian love story

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
