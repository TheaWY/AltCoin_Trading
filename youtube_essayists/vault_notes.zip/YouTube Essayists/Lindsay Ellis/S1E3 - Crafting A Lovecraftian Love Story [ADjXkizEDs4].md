---
title: "S1E3 - Crafting A Lovecraftian Love Story"
channel: "Lindsay Ellis"
type: "video"
video_id: "ADjXkizEDs4"
url: "https://www.youtube.com/watch?v=ADjXkizEDs4"
duration: "00:13:13"
upload_order: 3
about_ko: "Chick Lit S1E3: 러브크래프트풍 연애소설 기획"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E3 - Crafting A Lovecraftian Love Story

채널: [[Lindsay Ellis]] · 길이 00:13:13 · [YouTube](https://www.youtube.com/watch?v=ADjXkizEDs4)

## 어떤 영상인가

Chick Lit S1E3: 러브크래프트풍 연애소설 기획

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
