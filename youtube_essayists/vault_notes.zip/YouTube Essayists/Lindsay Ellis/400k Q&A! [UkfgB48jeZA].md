---
title: "400k Q&A!"
channel: "Lindsay Ellis"
type: "video"
video_id: "UkfgB48jeZA"
url: "https://www.youtube.com/watch?v=UkfgB48jeZA"
duration: "00:26:14"
upload_order: 95
about: "Q&A for 400k subscribers"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# 400k Q&A!

Channel: [[Lindsay Ellis]] · Length 00:26:14 · [YouTube](https://www.youtube.com/watch?v=UkfgB48jeZA)

## What it is

Q&A for 400k subscribers

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
