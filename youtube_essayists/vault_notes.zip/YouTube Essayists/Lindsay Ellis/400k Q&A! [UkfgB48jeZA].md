---
title: "400k Q&A!"
channel: "Lindsay Ellis"
type: "video"
video_id: "UkfgB48jeZA"
url: "https://www.youtube.com/watch?v=UkfgB48jeZA"
duration: "00:26:14"
upload_order: 95
about_ko: "구독자 40만 기념 Q&A"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# 400k Q&A!

채널: [[Lindsay Ellis]] · 길이 00:26:14 · [YouTube](https://www.youtube.com/watch?v=UkfgB48jeZA)

## 어떤 영상인가

구독자 40만 기념 Q&A

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
