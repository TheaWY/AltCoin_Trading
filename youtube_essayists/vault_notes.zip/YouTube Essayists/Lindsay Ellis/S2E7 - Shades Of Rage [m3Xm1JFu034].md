---
title: "S2E7 - Shades Of Rage"
channel: "Lindsay Ellis"
type: "video"
video_id: "m3Xm1JFu034"
url: "https://www.youtube.com/watch?v=m3Xm1JFu034"
duration: "00:16:16"
upload_order: 25
about: "Chick Lit S2E7: Shades of Rage (guessed from title)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E7 - Shades Of Rage

Channel: [[Lindsay Ellis]] · Length 00:16:16 · [YouTube](https://www.youtube.com/watch?v=m3Xm1JFu034)

## What it is

Chick Lit S2E7: Shades of Rage (guessed from title)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
