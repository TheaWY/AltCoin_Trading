---
title: "S2E7 - Shades Of Rage"
channel: "Lindsay Ellis"
type: "video"
video_id: "m3Xm1JFu034"
url: "https://www.youtube.com/watch?v=m3Xm1JFu034"
duration: "00:16:16"
upload_order: 25
about_ko: "Chick Lit S2E7: Shades of Rage (제목 기준)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E7 - Shades Of Rage

채널: [[Lindsay Ellis]] · 길이 00:16:16 · [YouTube](https://www.youtube.com/watch?v=m3Xm1JFu034)

## 어떤 영상인가

Chick Lit S2E7: Shades of Rage (제목 기준)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
