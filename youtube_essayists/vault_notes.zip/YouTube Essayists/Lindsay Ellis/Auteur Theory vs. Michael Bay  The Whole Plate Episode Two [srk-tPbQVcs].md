---
title: "Auteur Theory vs. Michael Bay | The Whole Plate: Episode Two"
channel: "Lindsay Ellis"
type: "video"
video_id: "srk-tPbQVcs"
url: "https://www.youtube.com/watch?v=srk-tPbQVcs"
duration: "00:12:32"
upload_order: 72
about: "The Whole Plate ep. 2: auteur theory and Michael Bay"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Auteur Theory vs. Michael Bay | The Whole Plate: Episode Two

Channel: [[Lindsay Ellis]] · Length 00:12:32 · [YouTube](https://www.youtube.com/watch?v=srk-tPbQVcs)

## What it is

The Whole Plate ep. 2: auteur theory and Michael Bay

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
