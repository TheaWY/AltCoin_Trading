---
title: "Auteur Theory vs. Michael Bay | The Whole Plate: Episode Two"
channel: "Lindsay Ellis"
type: "video"
video_id: "srk-tPbQVcs"
url: "https://www.youtube.com/watch?v=srk-tPbQVcs"
duration: "00:12:32"
upload_order: 72
about_ko: "The Whole Plate 2화: 작가주의 이론과 마이클 베이"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Auteur Theory vs. Michael Bay | The Whole Plate: Episode Two

채널: [[Lindsay Ellis]] · 길이 00:12:32 · [YouTube](https://www.youtube.com/watch?v=srk-tPbQVcs)

## 어떤 영상인가

The Whole Plate 2화: 작가주의 이론과 마이클 베이

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
