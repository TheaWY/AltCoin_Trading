---
title: "Loose Canon: Starscream"
channel: "Lindsay Ellis"
type: "video"
video_id: "b3ysMBXTXDk"
url: "https://www.youtube.com/watch?v=b3ysMBXTXDk"
duration: "00:19:59"
upload_order: 61
about_ko: "Loose Canon: 트랜스포머 스타스크림"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Starscream

채널: [[Lindsay Ellis]] · 길이 00:19:59 · [YouTube](https://www.youtube.com/watch?v=b3ysMBXTXDk)

## 어떤 영상인가

Loose Canon: 트랜스포머 스타스크림

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
