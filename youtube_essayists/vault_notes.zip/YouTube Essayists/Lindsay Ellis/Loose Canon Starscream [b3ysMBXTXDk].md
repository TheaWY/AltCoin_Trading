---
title: "Loose Canon: Starscream"
channel: "Lindsay Ellis"
type: "video"
video_id: "b3ysMBXTXDk"
url: "https://www.youtube.com/watch?v=b3ysMBXTXDk"
duration: "00:19:59"
upload_order: 61
about: "Loose Canon: Starscream from Transformers"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Starscream

Channel: [[Lindsay Ellis]] · Length 00:19:59 · [YouTube](https://www.youtube.com/watch?v=b3ysMBXTXDk)

## What it is

Loose Canon: Starscream from Transformers

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
