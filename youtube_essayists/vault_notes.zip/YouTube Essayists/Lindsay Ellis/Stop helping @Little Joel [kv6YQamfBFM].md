---
title: "Stop helping @Little Joel"
channel: "Lindsay Ellis"
type: "short"
video_id: "kv6YQamfBFM"
url: "https://www.youtube.com/watch?v=kv6YQamfBFM"
duration: ""
upload_order: 3
about: "[Short] Collab clip with Little Joel"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Stop helping @Little Joel

Channel: [[Lindsay Ellis]] · Length  · [YouTube](https://www.youtube.com/watch?v=kv6YQamfBFM)

## What it is

[Short] Collab clip with Little Joel

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
