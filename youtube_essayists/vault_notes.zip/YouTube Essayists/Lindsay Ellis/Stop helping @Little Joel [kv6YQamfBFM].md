---
title: "Stop helping @Little Joel"
channel: "Lindsay Ellis"
type: "short"
video_id: "kv6YQamfBFM"
url: "https://www.youtube.com/watch?v=kv6YQamfBFM"
duration: ""
upload_order: 3
about_ko: "[Shorts] Little Joel 콜라보 짧은 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Stop helping @Little Joel

채널: [[Lindsay Ellis]] · 길이  · [YouTube](https://www.youtube.com/watch?v=kv6YQamfBFM)

## 어떤 영상인가

[Shorts] Little Joel 콜라보 짧은 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
