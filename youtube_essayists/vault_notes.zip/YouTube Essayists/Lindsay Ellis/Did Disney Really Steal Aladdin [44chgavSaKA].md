---
title: "Did Disney Really Steal Aladdin?"
channel: "Lindsay Ellis"
type: "video"
video_id: "44chgavSaKA"
url: "https://www.youtube.com/watch?v=44chgavSaKA"
duration: "01:07:07"
upload_order: 122
about: "Testing the claim that Disney's Aladdin plagiarized another work"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Did Disney Really Steal Aladdin?

Channel: [[Lindsay Ellis]] · Length 01:07:07 · [YouTube](https://www.youtube.com/watch?v=44chgavSaKA)

## What it is

Testing the claim that Disney's Aladdin plagiarized another work

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
