---
title: "Did Disney Really Steal Aladdin?"
channel: "Lindsay Ellis"
type: "video"
video_id: "44chgavSaKA"
url: "https://www.youtube.com/watch?v=44chgavSaKA"
duration: "01:07:07"
upload_order: 122
about_ko: "디즈니 알라딘이 다른 작품을 표절했다는 주장을 검증하는 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Did Disney Really Steal Aladdin?

채널: [[Lindsay Ellis]] · 길이 01:07:07 · [YouTube](https://www.youtube.com/watch?v=44chgavSaKA)

## 어떤 영상인가

디즈니 알라딘이 다른 작품을 표절했다는 주장을 검증하는 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
