---
title: "S1E14 - The Cover Art Contest"
channel: "Lindsay Ellis"
type: "video"
video_id: "lCsykiors6I"
url: "https://www.youtube.com/watch?v=lCsykiors6I"
duration: "00:09:39"
upload_order: 14
about_ko: "Chick Lit S1E14: 표지 공모전"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E14 - The Cover Art Contest

채널: [[Lindsay Ellis]] · 길이 00:09:39 · [YouTube](https://www.youtube.com/watch?v=lCsykiors6I)

## 어떤 영상인가

Chick Lit S1E14: 표지 공모전

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
