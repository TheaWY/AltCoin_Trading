---
title: "S1E14 - The Cover Art Contest"
channel: "Lindsay Ellis"
type: "video"
video_id: "lCsykiors6I"
url: "https://www.youtube.com/watch?v=lCsykiors6I"
duration: "00:09:39"
upload_order: 14
about: "Chick Lit S1E14: cover art contest"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E14 - The Cover Art Contest

Channel: [[Lindsay Ellis]] · Length 00:09:39 · [YouTube](https://www.youtube.com/watch?v=lCsykiors6I)

## What it is

Chick Lit S1E14: cover art contest

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
