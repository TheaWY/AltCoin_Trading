---
title: "Are Disney Villains Going Extinct?"
channel: "Lindsay Ellis"
type: "video"
video_id: "doQB5d3Gggw"
url: "https://www.youtube.com/watch?v=doQB5d3Gggw"
duration: "00:15:20"
upload_order: 60
about_ko: "디즈니 악당은 사라지고 있는가"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Are Disney Villains Going Extinct?

채널: [[Lindsay Ellis]] · 길이 00:15:20 · [YouTube](https://www.youtube.com/watch?v=doQB5d3Gggw)

## 어떤 영상인가

디즈니 악당은 사라지고 있는가

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
