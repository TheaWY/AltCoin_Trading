---
title: "Are Disney Villains Going Extinct?"
channel: "Lindsay Ellis"
type: "video"
video_id: "doQB5d3Gggw"
url: "https://www.youtube.com/watch?v=doQB5d3Gggw"
duration: "00:15:20"
upload_order: 60
about: "Are Disney villains disappearing?"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Are Disney Villains Going Extinct?

Channel: [[Lindsay Ellis]] · Length 00:15:20 · [YouTube](https://www.youtube.com/watch?v=doQB5d3Gggw)

## What it is

Are Disney villains disappearing?

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
