---
title: "RENT - Look Pretty and Do As Little as Possible: A Video Essay"
channel: "Lindsay Ellis"
type: "video"
video_id: "q0qfFbtIj5w"
url: "https://www.youtube.com/watch?v=q0qfFbtIj5w"
duration: "00:45:54"
upload_order: 58
about: "Essay critiquing the film version of RENT"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# RENT - Look Pretty and Do As Little as Possible: A Video Essay

Channel: [[Lindsay Ellis]] · Length 00:45:54 · [YouTube](https://www.youtube.com/watch?v=q0qfFbtIj5w)

## What it is

Essay critiquing the film version of RENT

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
