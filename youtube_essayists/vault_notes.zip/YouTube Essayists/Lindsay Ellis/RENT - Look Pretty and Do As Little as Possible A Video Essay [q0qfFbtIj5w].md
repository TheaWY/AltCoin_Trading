---
title: "RENT - Look Pretty and Do As Little as Possible: A Video Essay"
channel: "Lindsay Ellis"
type: "video"
video_id: "q0qfFbtIj5w"
url: "https://www.youtube.com/watch?v=q0qfFbtIj5w"
duration: "00:45:54"
upload_order: 58
about_ko: "뮤지컬 렌트 영화판 비평 에세이"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# RENT - Look Pretty and Do As Little as Possible: A Video Essay

채널: [[Lindsay Ellis]] · 길이 00:45:54 · [YouTube](https://www.youtube.com/watch?v=q0qfFbtIj5w)

## 어떤 영상인가

뮤지컬 렌트 영화판 비평 에세이

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
