---
title: "Mini-Canon - Superhero v. Superhero: A History"
channel: "Lindsay Ellis"
type: "video"
video_id: "Lw-HyPmQn4E"
url: "https://www.youtube.com/watch?v=Lw-HyPmQn4E"
duration: "00:09:44"
upload_order: 37
about_ko: "Mini-Canon: 히어로끼리 싸우는 영화의 역사"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Mini-Canon - Superhero v. Superhero: A History

채널: [[Lindsay Ellis]] · 길이 00:09:44 · [YouTube](https://www.youtube.com/watch?v=Lw-HyPmQn4E)

## 어떤 영상인가

Mini-Canon: 히어로끼리 싸우는 영화의 역사

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
