---
title: "Mini-Canon - Superhero v. Superhero: A History"
channel: "Lindsay Ellis"
type: "video"
video_id: "Lw-HyPmQn4E"
url: "https://www.youtube.com/watch?v=Lw-HyPmQn4E"
duration: "00:09:44"
upload_order: 37
about: "Mini-Canon: history of hero-versus-hero films"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Mini-Canon - Superhero v. Superhero: A History

Channel: [[Lindsay Ellis]] · Length 00:09:44 · [YouTube](https://www.youtube.com/watch?v=Lw-HyPmQn4E)

## What it is

Mini-Canon: history of hero-versus-hero films

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
