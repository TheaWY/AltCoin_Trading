---
title: "Reevaluating The Little Mermaid before Disney horks up another live action remake"
channel: "Lindsay Ellis"
type: "video"
video_id: "NeuLEu9ZePc"
url: "https://www.youtube.com/watch?v=NeuLEu9ZePc"
duration: "00:35:46"
upload_order: 116
about_ko: "실사판 리메이크 전에 애니메이션 인어공주를 다시 평가"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Reevaluating The Little Mermaid before Disney horks up another live action remake

채널: [[Lindsay Ellis]] · 길이 00:35:46 · [YouTube](https://www.youtube.com/watch?v=NeuLEu9ZePc)

## 어떤 영상인가

실사판 리메이크 전에 애니메이션 인어공주를 다시 평가

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
