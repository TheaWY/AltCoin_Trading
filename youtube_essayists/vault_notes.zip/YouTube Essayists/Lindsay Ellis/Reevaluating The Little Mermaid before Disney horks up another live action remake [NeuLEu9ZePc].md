---
title: "Reevaluating The Little Mermaid before Disney horks up another live action remake"
channel: "Lindsay Ellis"
type: "video"
video_id: "NeuLEu9ZePc"
url: "https://www.youtube.com/watch?v=NeuLEu9ZePc"
duration: "00:35:46"
upload_order: 116
about: "Reassessing animated The Little Mermaid ahead of the live-action remake"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Reevaluating The Little Mermaid before Disney horks up another live action remake

Channel: [[Lindsay Ellis]] · Length 00:35:46 · [YouTube](https://www.youtube.com/watch?v=NeuLEu9ZePc)

## What it is

Reassessing animated The Little Mermaid ahead of the live-action remake

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
