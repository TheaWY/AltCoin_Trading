---
title: "The Ideology of the First Order"
channel: "Lindsay Ellis"
type: "video"
video_id: "XAVeyXwy3BE"
url: "https://www.youtube.com/watch?v=XAVeyXwy3BE"
duration: "00:23:40"
upload_order: 91
about: "The ideology of the First Order in Star Wars"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Ideology of the First Order

Channel: [[Lindsay Ellis]] · Length 00:23:40 · [YouTube](https://www.youtube.com/watch?v=XAVeyXwy3BE)

## What it is

The ideology of the First Order in Star Wars

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
