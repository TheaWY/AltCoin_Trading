---
title: "The Ideology of the First Order"
channel: "Lindsay Ellis"
type: "video"
video_id: "XAVeyXwy3BE"
url: "https://www.youtube.com/watch?v=XAVeyXwy3BE"
duration: "00:23:40"
upload_order: 91
about_ko: "스타워즈 퍼스트 오더의 이데올로기"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Ideology of the First Order

채널: [[Lindsay Ellis]] · 길이 00:23:40 · [YouTube](https://www.youtube.com/watch?v=XAVeyXwy3BE)

## 어떤 영상인가

스타워즈 퍼스트 오더의 이데올로기

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
