---
title: "Screenwriting, Staying Motivated and Microbudget Filmmaking - Conversation with David McCracken"
channel: "Lindsay Ellis"
type: "video"
video_id: "DdkiG07iWKs"
url: "https://www.youtube.com/watch?v=DdkiG07iWKs"
duration: "00:25:48"
upload_order: 75
about_ko: "David McCracken과의 대화: 각본, 동기 유지, 초저예산 영화"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Screenwriting, Staying Motivated and Microbudget Filmmaking - Conversation with David McCracken

채널: [[Lindsay Ellis]] · 길이 00:25:48 · [YouTube](https://www.youtube.com/watch?v=DdkiG07iWKs)

## 어떤 영상인가

David McCracken과의 대화: 각본, 동기 유지, 초저예산 영화

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
