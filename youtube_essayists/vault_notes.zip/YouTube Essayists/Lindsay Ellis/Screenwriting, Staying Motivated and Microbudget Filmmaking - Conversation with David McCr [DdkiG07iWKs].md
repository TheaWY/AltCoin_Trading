---
title: "Screenwriting, Staying Motivated and Microbudget Filmmaking - Conversation with David McCracken"
channel: "Lindsay Ellis"
type: "video"
video_id: "DdkiG07iWKs"
url: "https://www.youtube.com/watch?v=DdkiG07iWKs"
duration: "00:25:48"
upload_order: 75
about: "Conversation with David McCracken on screenwriting, motivation and microbudget film"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Screenwriting, Staying Motivated and Microbudget Filmmaking - Conversation with David McCracken

Channel: [[Lindsay Ellis]] · Length 00:25:48 · [YouTube](https://www.youtube.com/watch?v=DdkiG07iWKs)

## What it is

Conversation with David McCracken on screenwriting, motivation and microbudget film

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
