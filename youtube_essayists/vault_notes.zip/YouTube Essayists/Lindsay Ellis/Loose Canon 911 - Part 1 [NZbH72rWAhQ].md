---
title: "Loose Canon: 9/11 - Part 1"
channel: "Lindsay Ellis"
type: "video"
video_id: "NZbH72rWAhQ"
url: "https://www.youtube.com/watch?v=NZbH72rWAhQ"
duration: "00:21:56"
upload_order: 47
about_ko: "Loose Canon: 9/11 영화적 재현 1부"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: 9/11 - Part 1

채널: [[Lindsay Ellis]] · 길이 00:21:56 · [YouTube](https://www.youtube.com/watch?v=NZbH72rWAhQ)

## 어떤 영상인가

Loose Canon: 9/11 영화적 재현 1부

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
