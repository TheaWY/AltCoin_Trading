---
title: "Loose Canon: 9/11 - Part 1"
channel: "Lindsay Ellis"
type: "video"
video_id: "NZbH72rWAhQ"
url: "https://www.youtube.com/watch?v=NZbH72rWAhQ"
duration: "00:21:56"
upload_order: 47
about: "Loose Canon: 9/11 on film, part 1"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: 9/11 - Part 1

Channel: [[Lindsay Ellis]] · Length 00:21:56 · [YouTube](https://www.youtube.com/watch?v=NZbH72rWAhQ)

## What it is

Loose Canon: 9/11 on film, part 1

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
