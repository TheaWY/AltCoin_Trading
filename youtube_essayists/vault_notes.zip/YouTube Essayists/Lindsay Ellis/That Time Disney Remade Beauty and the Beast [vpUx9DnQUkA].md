---
title: "That Time Disney Remade Beauty and the Beast"
channel: "Lindsay Ellis"
type: "video"
video_id: "vpUx9DnQUkA"
url: "https://www.youtube.com/watch?v=vpUx9DnQUkA"
duration: "00:36:53"
upload_order: 94
about: "Critique of Disney's live-action Beauty and the Beast remake"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# That Time Disney Remade Beauty and the Beast

Channel: [[Lindsay Ellis]] · Length 00:36:53 · [YouTube](https://www.youtube.com/watch?v=vpUx9DnQUkA)

## What it is

Critique of Disney's live-action Beauty and the Beast remake

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
