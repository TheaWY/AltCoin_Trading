---
title: "That Time Disney Remade Beauty and the Beast"
channel: "Lindsay Ellis"
type: "video"
video_id: "vpUx9DnQUkA"
url: "https://www.youtube.com/watch?v=vpUx9DnQUkA"
duration: "00:36:53"
upload_order: 94
about_ko: "디즈니가 미녀와 야수를 실사로 리메이크한 일 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# That Time Disney Remade Beauty and the Beast

채널: [[Lindsay Ellis]] · 길이 00:36:53 · [YouTube](https://www.youtube.com/watch?v=vpUx9DnQUkA)

## 어떤 영상인가

디즈니가 미녀와 야수를 실사로 리메이크한 일 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
