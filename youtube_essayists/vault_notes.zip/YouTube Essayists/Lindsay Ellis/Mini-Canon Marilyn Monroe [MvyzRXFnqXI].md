---
title: "Mini-Canon: Marilyn Monroe"
channel: "Lindsay Ellis"
type: "video"
video_id: "MvyzRXFnqXI"
url: "https://www.youtube.com/watch?v=MvyzRXFnqXI"
duration: "00:10:17"
upload_order: 46
about_ko: "Mini-Canon: 마릴린 먼로"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Mini-Canon: Marilyn Monroe

채널: [[Lindsay Ellis]] · 길이 00:10:17 · [YouTube](https://www.youtube.com/watch?v=MvyzRXFnqXI)

## 어떤 영상인가

Mini-Canon: 마릴린 먼로

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
