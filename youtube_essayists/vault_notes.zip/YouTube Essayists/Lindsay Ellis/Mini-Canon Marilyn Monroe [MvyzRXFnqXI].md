---
title: "Mini-Canon: Marilyn Monroe"
channel: "Lindsay Ellis"
type: "video"
video_id: "MvyzRXFnqXI"
url: "https://www.youtube.com/watch?v=MvyzRXFnqXI"
duration: "00:10:17"
upload_order: 46
about: "Mini-Canon: Marilyn Monroe"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Mini-Canon: Marilyn Monroe

Channel: [[Lindsay Ellis]] · Length 00:10:17 · [YouTube](https://www.youtube.com/watch?v=MvyzRXFnqXI)

## What it is

Mini-Canon: Marilyn Monroe

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
