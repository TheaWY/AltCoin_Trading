---
title: "Comparing and contrasting Disney’s flop eras, now on Nebula"
channel: "Lindsay Ellis"
type: "short"
video_id: "97mjYqcu4lk"
url: "https://www.youtube.com/watch?v=97mjYqcu4lk"
duration: ""
upload_order: 5
about: "[Short] Promo for a Nebula video comparing Disney's flop eras"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Comparing and contrasting Disney’s flop eras, now on Nebula

Channel: [[Lindsay Ellis]] · Length  · [YouTube](https://www.youtube.com/watch?v=97mjYqcu4lk)

## What it is

[Short] Promo for a Nebula video comparing Disney's flop eras

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
