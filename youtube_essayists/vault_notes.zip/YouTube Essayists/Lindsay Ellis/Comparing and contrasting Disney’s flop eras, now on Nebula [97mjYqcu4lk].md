---
title: "Comparing and contrasting Disney’s flop eras, now on Nebula"
channel: "Lindsay Ellis"
type: "short"
video_id: "97mjYqcu4lk"
url: "https://www.youtube.com/watch?v=97mjYqcu4lk"
duration: ""
upload_order: 5
about_ko: "[Shorts] 디즈니 흥행 실패기 비교 Nebula 홍보"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Comparing and contrasting Disney’s flop eras, now on Nebula

채널: [[Lindsay Ellis]] · 길이  · [YouTube](https://www.youtube.com/watch?v=97mjYqcu4lk)

## 어떤 영상인가

[Shorts] 디즈니 흥행 실패기 비교 Nebula 홍보

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
