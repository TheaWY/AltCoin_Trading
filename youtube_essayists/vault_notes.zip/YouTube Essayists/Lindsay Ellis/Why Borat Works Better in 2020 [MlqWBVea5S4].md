---
title: "Why Borat Works Better in 2020"
channel: "Lindsay Ellis"
type: "video"
video_id: "MlqWBVea5S4"
url: "https://www.youtube.com/watch?v=MlqWBVea5S4"
duration: "00:31:00"
upload_order: 113
about_ko: "보랏 속편이 2020년에 더 잘 먹히는 이유"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Why Borat Works Better in 2020

채널: [[Lindsay Ellis]] · 길이 00:31:00 · [YouTube](https://www.youtube.com/watch?v=MlqWBVea5S4)

## 어떤 영상인가

보랏 속편이 2020년에 더 잘 먹히는 이유

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
