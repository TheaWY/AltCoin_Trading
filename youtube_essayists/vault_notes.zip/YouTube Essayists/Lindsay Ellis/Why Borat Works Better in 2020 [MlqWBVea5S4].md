---
title: "Why Borat Works Better in 2020"
channel: "Lindsay Ellis"
type: "video"
video_id: "MlqWBVea5S4"
url: "https://www.youtube.com/watch?v=MlqWBVea5S4"
duration: "00:31:00"
upload_order: 113
about: "Why the Borat sequel works better in 2020"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Why Borat Works Better in 2020

Channel: [[Lindsay Ellis]] · Length 00:31:00 · [YouTube](https://www.youtube.com/watch?v=MlqWBVea5S4)

## What it is

Why the Borat sequel works better in 2020

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
