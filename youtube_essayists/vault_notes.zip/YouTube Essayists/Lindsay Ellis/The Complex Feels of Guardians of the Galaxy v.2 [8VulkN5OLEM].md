---
title: "The Complex Feels of Guardians of the Galaxy v.2"
channel: "Lindsay Ellis"
type: "video"
video_id: "8VulkN5OLEM"
url: "https://www.youtube.com/watch?v=8VulkN5OLEM"
duration: "00:34:25"
upload_order: 79
about: "The emotional structure of Guardians of the Galaxy Vol. 2"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Complex Feels of Guardians of the Galaxy v.2

Channel: [[Lindsay Ellis]] · Length 00:34:25 · [YouTube](https://www.youtube.com/watch?v=8VulkN5OLEM)

## What it is

The emotional structure of Guardians of the Galaxy Vol. 2

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
