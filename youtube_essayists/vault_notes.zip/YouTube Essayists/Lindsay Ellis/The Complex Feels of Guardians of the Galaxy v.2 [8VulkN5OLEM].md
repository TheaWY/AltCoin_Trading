---
title: "The Complex Feels of Guardians of the Galaxy v.2"
channel: "Lindsay Ellis"
type: "video"
video_id: "8VulkN5OLEM"
url: "https://www.youtube.com/watch?v=8VulkN5OLEM"
duration: "00:34:25"
upload_order: 79
about_ko: "가디언즈 오브 갤럭시 2의 감정 구조"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Complex Feels of Guardians of the Galaxy v.2

채널: [[Lindsay Ellis]] · 길이 00:34:25 · [YouTube](https://www.youtube.com/watch?v=8VulkN5OLEM)

## 어떤 영상인가

가디언즈 오브 갤럭시 2의 감정 구조

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
