---
title: "Death of the Author"
channel: "Lindsay Ellis"
type: "video"
video_id: "MGn9x4-Y_7A"
url: "https://www.youtube.com/watch?v=MGn9x4-Y_7A"
duration: "00:30:17"
upload_order: 98
about: "Explainer on the critical theory \"death of the author\""
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Death of the Author

Channel: [[Lindsay Ellis]] · Length 00:30:17 · [YouTube](https://www.youtube.com/watch?v=MGn9x4-Y_7A)

## What it is

Explainer on the critical theory "death of the author"

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
