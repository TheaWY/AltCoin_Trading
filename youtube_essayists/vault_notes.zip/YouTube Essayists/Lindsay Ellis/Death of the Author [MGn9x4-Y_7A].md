---
title: "Death of the Author"
channel: "Lindsay Ellis"
type: "video"
video_id: "MGn9x4-Y_7A"
url: "https://www.youtube.com/watch?v=MGn9x4-Y_7A"
duration: "00:30:17"
upload_order: 98
about_ko: "비평 이론 '작가의 죽음' 해설"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Death of the Author

채널: [[Lindsay Ellis]] · 길이 00:30:17 · [YouTube](https://www.youtube.com/watch?v=MGn9x4-Y_7A)

## 어떤 영상인가

비평 이론 '작가의 죽음' 해설

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
