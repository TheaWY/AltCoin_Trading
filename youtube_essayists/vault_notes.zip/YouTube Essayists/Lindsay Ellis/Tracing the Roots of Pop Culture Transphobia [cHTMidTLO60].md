---
title: "Tracing the Roots of Pop Culture Transphobia"
channel: "Lindsay Ellis"
type: "video"
video_id: "cHTMidTLO60"
url: "https://www.youtube.com/watch?v=cHTMidTLO60"
duration: "00:58:57"
upload_order: 115
about_ko: "대중문화 속 트랜스젠더 혐오 묘사의 역사"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Tracing the Roots of Pop Culture Transphobia

채널: [[Lindsay Ellis]] · 길이 00:58:57 · [YouTube](https://www.youtube.com/watch?v=cHTMidTLO60)

## 어떤 영상인가

대중문화 속 트랜스젠더 혐오 묘사의 역사

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
