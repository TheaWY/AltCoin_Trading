---
title: "Tracing the Roots of Pop Culture Transphobia"
channel: "Lindsay Ellis"
type: "video"
video_id: "cHTMidTLO60"
url: "https://www.youtube.com/watch?v=cHTMidTLO60"
duration: "00:58:57"
upload_order: 115
about: "History of transphobic portrayals in pop culture"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Tracing the Roots of Pop Culture Transphobia

Channel: [[Lindsay Ellis]] · Length 00:58:57 · [YouTube](https://www.youtube.com/watch?v=cHTMidTLO60)

## What it is

History of transphobic portrayals in pop culture

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
