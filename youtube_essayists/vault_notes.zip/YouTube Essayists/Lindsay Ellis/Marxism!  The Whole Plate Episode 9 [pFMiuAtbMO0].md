---
title: "Marxism! | The Whole Plate: Episode 9"
channel: "Lindsay Ellis"
type: "video"
video_id: "pFMiuAtbMO0"
url: "https://www.youtube.com/watch?v=pFMiuAtbMO0"
duration: "00:19:02"
upload_order: 93
about: "The Whole Plate ep. 9: Marxist criticism, using Transformers"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Marxism! | The Whole Plate: Episode 9

Channel: [[Lindsay Ellis]] · Length 00:19:02 · [YouTube](https://www.youtube.com/watch?v=pFMiuAtbMO0)

## What it is

The Whole Plate ep. 9: Marxist criticism, using Transformers

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
