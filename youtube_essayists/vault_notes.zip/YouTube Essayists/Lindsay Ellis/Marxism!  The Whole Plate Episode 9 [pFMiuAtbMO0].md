---
title: "Marxism! | The Whole Plate: Episode 9"
channel: "Lindsay Ellis"
type: "video"
video_id: "pFMiuAtbMO0"
url: "https://www.youtube.com/watch?v=pFMiuAtbMO0"
duration: "00:19:02"
upload_order: 93
about_ko: "The Whole Plate 9화: 마르크스주의 비평(트랜스포머 기반)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Marxism! | The Whole Plate: Episode 9

채널: [[Lindsay Ellis]] · 길이 00:19:02 · [YouTube](https://www.youtube.com/watch?v=pFMiuAtbMO0)

## 어떤 영상인가

The Whole Plate 9화: 마르크스주의 비평(트랜스포머 기반)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
