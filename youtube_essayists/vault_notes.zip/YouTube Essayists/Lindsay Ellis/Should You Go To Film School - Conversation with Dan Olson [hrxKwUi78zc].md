---
title: "Should You Go To Film School? - Conversation with Dan Olson"
channel: "Lindsay Ellis"
type: "video"
video_id: "hrxKwUi78zc"
url: "https://www.youtube.com/watch?v=hrxKwUi78zc"
duration: "00:28:56"
upload_order: 56
about: "Conversation with Dan Olson on whether to go to film school"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Should You Go To Film School? - Conversation with Dan Olson

Channel: [[Lindsay Ellis]] · Length 00:28:56 · [YouTube](https://www.youtube.com/watch?v=hrxKwUi78zc)

## What it is

Conversation with Dan Olson on whether to go to film school

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
