---
title: "Should You Go To Film School? - Conversation with Dan Olson"
channel: "Lindsay Ellis"
type: "video"
video_id: "hrxKwUi78zc"
url: "https://www.youtube.com/watch?v=hrxKwUi78zc"
duration: "00:28:56"
upload_order: 56
about_ko: "Dan Olson과의 대화: 영화학교에 가야 하나"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Should You Go To Film School? - Conversation with Dan Olson

채널: [[Lindsay Ellis]] · 길이 00:28:56 · [YouTube](https://www.youtube.com/watch?v=hrxKwUi78zc)

## 어떤 영상인가

Dan Olson과의 대화: 영화학교에 가야 하나

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
