---
title: "S1E18 - Parody, Satire, and Serra"
channel: "Lindsay Ellis"
type: "video"
video_id: "plR8KFz6jVA"
url: "https://www.youtube.com/watch?v=plR8KFz6jVA"
duration: "00:14:03"
upload_order: 18
about: "Chick Lit S1E18: parody and satire"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E18 - Parody, Satire, and Serra

Channel: [[Lindsay Ellis]] · Length 00:14:03 · [YouTube](https://www.youtube.com/watch?v=plR8KFz6jVA)

## What it is

Chick Lit S1E18: parody and satire

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
