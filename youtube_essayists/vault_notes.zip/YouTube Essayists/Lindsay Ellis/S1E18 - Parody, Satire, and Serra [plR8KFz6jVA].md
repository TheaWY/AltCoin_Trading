---
title: "S1E18 - Parody, Satire, and Serra"
channel: "Lindsay Ellis"
type: "video"
video_id: "plR8KFz6jVA"
url: "https://www.youtube.com/watch?v=plR8KFz6jVA"
duration: "00:14:03"
upload_order: 18
about_ko: "Chick Lit S1E18: 패러디와 풍자"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E18 - Parody, Satire, and Serra

채널: [[Lindsay Ellis]] · 길이 00:14:03 · [YouTube](https://www.youtube.com/watch?v=plR8KFz6jVA)

## 어떤 영상인가

Chick Lit S1E18: 패러디와 풍자

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
