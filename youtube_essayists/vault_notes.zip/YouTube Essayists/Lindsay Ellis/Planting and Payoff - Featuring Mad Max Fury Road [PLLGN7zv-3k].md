---
title: "Planting and Payoff - Featuring Mad Max: Fury Road"
channel: "Lindsay Ellis"
type: "video"
video_id: "PLLGN7zv-3k"
url: "https://www.youtube.com/watch?v=PLLGN7zv-3k"
duration: "00:12:11"
upload_order: 59
about_ko: "복선과 회수: 매드 맥스 분노의 도로 사례"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Planting and Payoff - Featuring Mad Max: Fury Road

채널: [[Lindsay Ellis]] · 길이 00:12:11 · [YouTube](https://www.youtube.com/watch?v=PLLGN7zv-3k)

## 어떤 영상인가

복선과 회수: 매드 맥스 분노의 도로 사례

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
