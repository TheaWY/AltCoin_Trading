---
title: "Planting and Payoff - Featuring Mad Max: Fury Road"
channel: "Lindsay Ellis"
type: "video"
video_id: "PLLGN7zv-3k"
url: "https://www.youtube.com/watch?v=PLLGN7zv-3k"
duration: "00:12:11"
upload_order: 59
about: "Planting and payoff, using Mad Max: Fury Road"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Planting and Payoff - Featuring Mad Max: Fury Road

Channel: [[Lindsay Ellis]] · Length 00:12:11 · [YouTube](https://www.youtube.com/watch?v=PLLGN7zv-3k)

## What it is

Planting and payoff, using Mad Max: Fury Road

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
