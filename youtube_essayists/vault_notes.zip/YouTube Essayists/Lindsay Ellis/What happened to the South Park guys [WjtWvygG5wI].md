---
title: "What happened to the South Park guys?"
channel: "Lindsay Ellis"
type: "short"
video_id: "WjtWvygG5wI"
url: "https://www.youtube.com/watch?v=WjtWvygG5wI"
duration: ""
upload_order: 8
about: "[Short] What happened to the South Park creators?"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# What happened to the South Park guys?

Channel: [[Lindsay Ellis]] · Length  · [YouTube](https://www.youtube.com/watch?v=WjtWvygG5wI)

## What it is

[Short] What happened to the South Park creators?

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
