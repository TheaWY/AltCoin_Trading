---
title: "What happened to the South Park guys?"
channel: "Lindsay Ellis"
type: "short"
video_id: "WjtWvygG5wI"
url: "https://www.youtube.com/watch?v=WjtWvygG5wI"
duration: ""
upload_order: 8
about_ko: "[Shorts] 사우스 파크 제작진은 어떻게 됐나"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# What happened to the South Park guys?

채널: [[Lindsay Ellis]] · 길이  · [YouTube](https://www.youtube.com/watch?v=WjtWvygG5wI)

## 어떤 영상인가

[Shorts] 사우스 파크 제작진은 어떻게 됐나

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
