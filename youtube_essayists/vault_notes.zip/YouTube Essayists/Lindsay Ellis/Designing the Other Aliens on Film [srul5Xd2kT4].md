---
title: "Designing the Other: Aliens on Film"
channel: "Lindsay Ellis"
type: "video"
video_id: "srul5Xd2kT4"
url: "https://www.youtube.com/watch?v=srul5Xd2kT4"
duration: "00:11:48"
upload_order: 55
about: "Alien design in film and the idea of the Other"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Designing the Other: Aliens on Film

Channel: [[Lindsay Ellis]] · Length 00:11:48 · [YouTube](https://www.youtube.com/watch?v=srul5Xd2kT4)

## What it is

Alien design in film and the idea of the Other

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
