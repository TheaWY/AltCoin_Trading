---
title: "Designing the Other: Aliens on Film"
channel: "Lindsay Ellis"
type: "video"
video_id: "srul5Xd2kT4"
url: "https://www.youtube.com/watch?v=srul5Xd2kT4"
duration: "00:11:48"
upload_order: 55
about_ko: "영화 속 외계인 디자인과 타자화"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Designing the Other: Aliens on Film

채널: [[Lindsay Ellis]] · 길이 00:11:48 · [YouTube](https://www.youtube.com/watch?v=srul5Xd2kT4)

## 어떤 영상인가

영화 속 외계인 디자인과 타자화

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
