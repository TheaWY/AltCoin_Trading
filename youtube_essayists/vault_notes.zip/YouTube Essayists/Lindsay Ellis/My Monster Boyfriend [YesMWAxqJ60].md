---
title: "My Monster Boyfriend"
channel: "Lindsay Ellis"
type: "video"
video_id: "YesMWAxqJ60"
url: "https://www.youtube.com/watch?v=YesMWAxqJ60"
duration: "00:24:23"
upload_order: 87
about_ko: "괴물 남자친구 로맨스 장르(셰이프 오브 워터 등)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# My Monster Boyfriend

채널: [[Lindsay Ellis]] · 길이 00:24:23 · [YouTube](https://www.youtube.com/watch?v=YesMWAxqJ60)

## 어떤 영상인가

괴물 남자친구 로맨스 장르(셰이프 오브 워터 등)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
