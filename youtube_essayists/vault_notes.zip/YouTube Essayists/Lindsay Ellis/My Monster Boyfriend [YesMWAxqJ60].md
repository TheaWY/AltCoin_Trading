---
title: "My Monster Boyfriend"
channel: "Lindsay Ellis"
type: "video"
video_id: "YesMWAxqJ60"
url: "https://www.youtube.com/watch?v=YesMWAxqJ60"
duration: "00:24:23"
upload_order: 87
about: "The monster-boyfriend romance genre (The Shape of Water and others)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# My Monster Boyfriend

Channel: [[Lindsay Ellis]] · Length 00:24:23 · [YouTube](https://www.youtube.com/watch?v=YesMWAxqJ60)

## What it is

The monster-boyfriend romance genre (The Shape of Water and others)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
