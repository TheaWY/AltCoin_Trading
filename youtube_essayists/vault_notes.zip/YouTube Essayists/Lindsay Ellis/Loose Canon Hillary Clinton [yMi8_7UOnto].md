---
title: "Loose Canon: Hillary Clinton"
channel: "Lindsay Ellis"
type: "video"
video_id: "yMi8_7UOnto"
url: "https://www.youtube.com/watch?v=yMi8_7UOnto"
duration: "00:17:30"
upload_order: 50
about: "Loose Canon: Hillary Clinton's pop culture image"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Hillary Clinton

Channel: [[Lindsay Ellis]] · Length 00:17:30 · [YouTube](https://www.youtube.com/watch?v=yMi8_7UOnto)

## What it is

Loose Canon: Hillary Clinton's pop culture image

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
