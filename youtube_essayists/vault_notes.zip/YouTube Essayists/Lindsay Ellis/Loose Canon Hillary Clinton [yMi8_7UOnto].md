---
title: "Loose Canon: Hillary Clinton"
channel: "Lindsay Ellis"
type: "video"
video_id: "yMi8_7UOnto"
url: "https://www.youtube.com/watch?v=yMi8_7UOnto"
duration: "00:17:30"
upload_order: 50
about_ko: "Loose Canon: 힐러리 클린턴의 대중문화 이미지"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Hillary Clinton

채널: [[Lindsay Ellis]] · 길이 00:17:30 · [YouTube](https://www.youtube.com/watch?v=yMi8_7UOnto)

## 어떤 영상인가

Loose Canon: 힐러리 클린턴의 대중문화 이미지

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
