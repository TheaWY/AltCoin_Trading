---
title: "9 things I wish I knew before publishing my first novel"
channel: "Lindsay Ellis"
type: "video"
video_id: "7hZdOGB7Tgk"
url: "https://www.youtube.com/watch?v=7hZdOGB7Tgk"
duration: "00:23:13"
upload_order: 117
about: "Nine things she wishes she'd known before publishing her first novel"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# 9 things I wish I knew before publishing my first novel

Channel: [[Lindsay Ellis]] · Length 00:23:13 · [YouTube](https://www.youtube.com/watch?v=7hZdOGB7Tgk)

## What it is

Nine things she wishes she'd known before publishing her first novel

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
