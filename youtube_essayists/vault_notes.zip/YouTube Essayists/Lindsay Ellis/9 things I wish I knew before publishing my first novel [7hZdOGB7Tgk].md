---
title: "9 things I wish I knew before publishing my first novel"
channel: "Lindsay Ellis"
type: "video"
video_id: "7hZdOGB7Tgk"
url: "https://www.youtube.com/watch?v=7hZdOGB7Tgk"
duration: "00:23:13"
upload_order: 117
about_ko: "첫 소설 출간 전에 알았으면 좋았을 9가지"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# 9 things I wish I knew before publishing my first novel

채널: [[Lindsay Ellis]] · 길이 00:23:13 · [YouTube](https://www.youtube.com/watch?v=7hZdOGB7Tgk)

## 어떤 영상인가

첫 소설 출간 전에 알았으면 좋았을 9가지

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
