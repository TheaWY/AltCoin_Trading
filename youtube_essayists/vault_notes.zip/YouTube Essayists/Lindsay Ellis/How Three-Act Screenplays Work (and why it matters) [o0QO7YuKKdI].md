---
title: "How Three-Act Screenplays Work (and why it matters)"
channel: "Lindsay Ellis"
type: "video"
video_id: "o0QO7YuKKdI"
url: "https://www.youtube.com/watch?v=o0QO7YuKKdI"
duration: "00:17:04"
upload_order: 52
about_ko: "3막 구조 각본이 작동하는 방식"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# How Three-Act Screenplays Work (and why it matters)

채널: [[Lindsay Ellis]] · 길이 00:17:04 · [YouTube](https://www.youtube.com/watch?v=o0QO7YuKKdI)

## 어떤 영상인가

3막 구조 각본이 작동하는 방식

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
