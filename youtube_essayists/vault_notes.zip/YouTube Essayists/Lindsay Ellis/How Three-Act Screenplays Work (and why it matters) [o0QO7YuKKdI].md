---
title: "How Three-Act Screenplays Work (and why it matters)"
channel: "Lindsay Ellis"
type: "video"
video_id: "o0QO7YuKKdI"
url: "https://www.youtube.com/watch?v=o0QO7YuKKdI"
duration: "00:17:04"
upload_order: 52
about: "How three-act screenplays work"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# How Three-Act Screenplays Work (and why it matters)

Channel: [[Lindsay Ellis]] · Length 00:17:04 · [YouTube](https://www.youtube.com/watch?v=o0QO7YuKKdI)

## What it is

How three-act screenplays work

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
