---
title: "S1E2 - What's Our Gimmick?"
channel: "Lindsay Ellis"
type: "video"
video_id: "sw8iTiYfWHM"
url: "https://www.youtube.com/watch?v=sw8iTiYfWHM"
duration: "00:09:21"
upload_order: 2
about: "Chick Lit S1E2: picking the gimmick"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E2 - What's Our Gimmick?

Channel: [[Lindsay Ellis]] · Length 00:09:21 · [YouTube](https://www.youtube.com/watch?v=sw8iTiYfWHM)

## What it is

Chick Lit S1E2: picking the gimmick

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
