---
title: "S1E2 - What's Our Gimmick?"
channel: "Lindsay Ellis"
type: "video"
video_id: "sw8iTiYfWHM"
url: "https://www.youtube.com/watch?v=sw8iTiYfWHM"
duration: "00:09:21"
upload_order: 2
about_ko: "Chick Lit S1E2: 우리의 콘셉트"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E2 - What's Our Gimmick?

채널: [[Lindsay Ellis]] · 길이 00:09:21 · [YouTube](https://www.youtube.com/watch?v=sw8iTiYfWHM)

## 어떤 영상인가

Chick Lit S1E2: 우리의 콘셉트

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
