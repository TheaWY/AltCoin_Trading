---
title: "Loose Canon: The Jacks of King Kong"
channel: "Lindsay Ellis"
type: "video"
video_id: "KHy37toiqzA"
url: "https://www.youtube.com/watch?v=KHy37toiqzA"
duration: "00:10:29"
upload_order: 65
about: "Loose Canon: the Jacks who made the King Kong films"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: The Jacks of King Kong

Channel: [[Lindsay Ellis]] · Length 00:10:29 · [YouTube](https://www.youtube.com/watch?v=KHy37toiqzA)

## What it is

Loose Canon: the Jacks who made the King Kong films

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
