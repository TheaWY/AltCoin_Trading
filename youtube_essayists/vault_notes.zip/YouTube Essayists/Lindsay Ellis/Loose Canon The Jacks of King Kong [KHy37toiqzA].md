---
title: "Loose Canon: The Jacks of King Kong"
channel: "Lindsay Ellis"
type: "video"
video_id: "KHy37toiqzA"
url: "https://www.youtube.com/watch?v=KHy37toiqzA"
duration: "00:10:29"
upload_order: 65
about_ko: "Loose Canon: 킹콩 영화를 만든 '잭'들"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: The Jacks of King Kong

채널: [[Lindsay Ellis]] · 길이 00:10:29 · [YouTube](https://www.youtube.com/watch?v=KHy37toiqzA)

## 어떤 영상인가

Loose Canon: 킹콩 영화를 만든 '잭'들

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
