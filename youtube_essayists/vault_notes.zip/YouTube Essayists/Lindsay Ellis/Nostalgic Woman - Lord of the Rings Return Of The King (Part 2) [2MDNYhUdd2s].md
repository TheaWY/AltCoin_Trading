---
title: "Nostalgic Woman - Lord of the Rings: Return Of The King (Part 2)"
channel: "Lindsay Ellis"
type: "video"
video_id: "2MDNYhUdd2s"
url: "https://www.youtube.com/watch?v=2MDNYhUdd2s"
duration: "00:15:50"
upload_order: 42
about: "Nostalgic Woman: The Return of the King, part 2"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Nostalgic Woman - Lord of the Rings: Return Of The King (Part 2)

Channel: [[Lindsay Ellis]] · Length 00:15:50 · [YouTube](https://www.youtube.com/watch?v=2MDNYhUdd2s)

## What it is

Nostalgic Woman: The Return of the King, part 2

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
