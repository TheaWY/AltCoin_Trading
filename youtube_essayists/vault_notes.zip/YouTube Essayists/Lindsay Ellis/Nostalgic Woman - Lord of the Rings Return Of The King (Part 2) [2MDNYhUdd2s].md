---
title: "Nostalgic Woman - Lord of the Rings: Return Of The King (Part 2)"
channel: "Lindsay Ellis"
type: "video"
video_id: "2MDNYhUdd2s"
url: "https://www.youtube.com/watch?v=2MDNYhUdd2s"
duration: "00:15:50"
upload_order: 42
about_ko: "Nostalgic Woman: 반지의 제왕 왕의 귀환 2부"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Nostalgic Woman - Lord of the Rings: Return Of The King (Part 2)

채널: [[Lindsay Ellis]] · 길이 00:15:50 · [YouTube](https://www.youtube.com/watch?v=2MDNYhUdd2s)

## 어떤 영상인가

Nostalgic Woman: 반지의 제왕 왕의 귀환 2부

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
