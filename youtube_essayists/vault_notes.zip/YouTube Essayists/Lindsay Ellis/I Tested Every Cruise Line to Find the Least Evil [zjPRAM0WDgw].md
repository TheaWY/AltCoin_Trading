---
title: "I Tested Every Cruise Line to Find the Least Evil"
channel: "Lindsay Ellis"
type: "video"
video_id: "zjPRAM0WDgw"
url: "https://www.youtube.com/watch?v=zjPRAM0WDgw"
duration: "02:20:41"
upload_order: 123
about_ko: "여러 크루즈 회사를 직접 타보며 그중 '가장 덜 나쁜' 곳을 찾는 장편 체험 에세이"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# I Tested Every Cruise Line to Find the Least Evil

채널: [[Lindsay Ellis]] · 길이 02:20:41 · [YouTube](https://www.youtube.com/watch?v=zjPRAM0WDgw)

## 어떤 영상인가

여러 크루즈 회사를 직접 타보며 그중 '가장 덜 나쁜' 곳을 찾는 장편 체험 에세이

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
