---
title: "I Tested Every Cruise Line to Find the Least Evil"
channel: "Lindsay Ellis"
type: "video"
video_id: "zjPRAM0WDgw"
url: "https://www.youtube.com/watch?v=zjPRAM0WDgw"
duration: "02:20:41"
upload_order: 123
about: "Long first-person essay riding several cruise lines to find the least bad one"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# I Tested Every Cruise Line to Find the Least Evil

Channel: [[Lindsay Ellis]] · Length 02:20:41 · [YouTube](https://www.youtube.com/watch?v=zjPRAM0WDgw)

## What it is

Long first-person essay riding several cruise lines to find the least bad one

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
