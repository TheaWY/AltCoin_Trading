---
title: "Loose Canon: Phantom of the Opera (Part 1) - Before Broadway"
channel: "Lindsay Ellis"
type: "video"
video_id: "6srPCZhecOY"
url: "https://www.youtube.com/watch?v=6srPCZhecOY"
duration: "00:18:34"
upload_order: 34
about: "Loose Canon: Phantom of the Opera, part 1 (before Broadway)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Phantom of the Opera (Part 1) - Before Broadway

Channel: [[Lindsay Ellis]] · Length 00:18:34 · [YouTube](https://www.youtube.com/watch?v=6srPCZhecOY)

## What it is

Loose Canon: Phantom of the Opera, part 1 (before Broadway)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
