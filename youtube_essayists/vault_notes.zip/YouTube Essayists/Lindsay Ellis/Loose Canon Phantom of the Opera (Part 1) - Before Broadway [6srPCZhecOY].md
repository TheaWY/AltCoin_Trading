---
title: "Loose Canon: Phantom of the Opera (Part 1) - Before Broadway"
channel: "Lindsay Ellis"
type: "video"
video_id: "6srPCZhecOY"
url: "https://www.youtube.com/watch?v=6srPCZhecOY"
duration: "00:18:34"
upload_order: 34
about_ko: "Loose Canon: 오페라의 유령 1부(브로드웨이 이전)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Phantom of the Opera (Part 1) - Before Broadway

채널: [[Lindsay Ellis]] · 길이 00:18:34 · [YouTube](https://www.youtube.com/watch?v=6srPCZhecOY)

## 어떤 영상인가

Loose Canon: 오페라의 유령 1부(브로드웨이 이전)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
