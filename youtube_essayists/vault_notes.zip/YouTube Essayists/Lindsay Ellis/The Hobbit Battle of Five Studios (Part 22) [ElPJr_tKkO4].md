---
title: "The Hobbit: Battle of Five Studios (Part 2/2)"
channel: "Lindsay Ellis"
type: "video"
video_id: "ElPJr_tKkO4"
url: "https://www.youtube.com/watch?v=ElPJr_tKkO4"
duration: "00:34:43"
upload_order: 89
about: "The Hobbit trilogy's studio problems, part 2"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Hobbit: Battle of Five Studios (Part 2/2)

Channel: [[Lindsay Ellis]] · Length 00:34:43 · [YouTube](https://www.youtube.com/watch?v=ElPJr_tKkO4)

## What it is

The Hobbit trilogy's studio problems, part 2

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
