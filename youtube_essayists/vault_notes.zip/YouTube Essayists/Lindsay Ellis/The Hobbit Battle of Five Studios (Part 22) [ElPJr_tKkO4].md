---
title: "The Hobbit: Battle of Five Studios (Part 2/2)"
channel: "Lindsay Ellis"
type: "video"
video_id: "ElPJr_tKkO4"
url: "https://www.youtube.com/watch?v=ElPJr_tKkO4"
duration: "00:34:43"
upload_order: 89
about_ko: "호빗 3부작 제작사 문제 분석 2부"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Hobbit: Battle of Five Studios (Part 2/2)

채널: [[Lindsay Ellis]] · 길이 00:34:43 · [YouTube](https://www.youtube.com/watch?v=ElPJr_tKkO4)

## 어떤 영상인가

호빗 3부작 제작사 문제 분석 2부

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
