---
title: "The Male Gaze vs. The Men: Feminist Theory Part 2 | The Whole Plate: Episode 6"
channel: "Lindsay Ellis"
type: "video"
video_id: "oNkTeHpHj_I"
url: "https://www.youtube.com/watch?v=oNkTeHpHj_I"
duration: "00:13:40"
upload_order: 80
about: "The Whole Plate ep. 6: male gaze theory, part 2"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Male Gaze vs. The Men: Feminist Theory Part 2 | The Whole Plate: Episode 6

Channel: [[Lindsay Ellis]] · Length 00:13:40 · [YouTube](https://www.youtube.com/watch?v=oNkTeHpHj_I)

## What it is

The Whole Plate ep. 6: male gaze theory, part 2

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
