---
title: "The Male Gaze vs. The Men: Feminist Theory Part 2 | The Whole Plate: Episode 6"
channel: "Lindsay Ellis"
type: "video"
video_id: "oNkTeHpHj_I"
url: "https://www.youtube.com/watch?v=oNkTeHpHj_I"
duration: "00:13:40"
upload_order: 80
about_ko: "The Whole Plate 6화: 남성 응시 이론 2부"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Male Gaze vs. The Men: Feminist Theory Part 2 | The Whole Plate: Episode 6

채널: [[Lindsay Ellis]] · 길이 00:13:40 · [YouTube](https://www.youtube.com/watch?v=oNkTeHpHj_I)

## 어떤 영상인가

The Whole Plate 6화: 남성 응시 이론 2부

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
