---
title: "Dear Stephenie Meyer"
channel: "Lindsay Ellis"
type: "video"
video_id: "8O06tMbIKh0"
url: "https://www.youtube.com/watch?v=8O06tMbIKh0"
duration: "00:19:09"
upload_order: 85
about: "Essay framed as a letter to Twilight author Stephenie Meyer"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Dear Stephenie Meyer

Channel: [[Lindsay Ellis]] · Length 00:19:09 · [YouTube](https://www.youtube.com/watch?v=8O06tMbIKh0)

## What it is

Essay framed as a letter to Twilight author Stephenie Meyer

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
