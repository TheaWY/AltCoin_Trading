---
title: "Dear Stephenie Meyer"
channel: "Lindsay Ellis"
type: "video"
video_id: "8O06tMbIKh0"
url: "https://www.youtube.com/watch?v=8O06tMbIKh0"
duration: "00:19:09"
upload_order: 85
about_ko: "트와일라잇 작가 스테프니 메이어에게 보내는 편지 형식 에세이"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Dear Stephenie Meyer

채널: [[Lindsay Ellis]] · 길이 00:19:09 · [YouTube](https://www.youtube.com/watch?v=8O06tMbIKh0)

## 어떤 영상인가

트와일라잇 작가 스테프니 메이어에게 보내는 편지 형식 에세이

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
