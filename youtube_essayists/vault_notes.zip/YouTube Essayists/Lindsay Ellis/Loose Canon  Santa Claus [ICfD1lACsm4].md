---
title: "Loose Canon:  Santa Claus"
channel: "Lindsay Ellis"
type: "video"
video_id: "ICfD1lACsm4"
url: "https://www.youtube.com/watch?v=ICfD1lACsm4"
duration: "00:17:25"
upload_order: 57
about: "Loose Canon: Santa Claus"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon:  Santa Claus

Channel: [[Lindsay Ellis]] · Length 00:17:25 · [YouTube](https://www.youtube.com/watch?v=ICfD1lACsm4)

## What it is

Loose Canon: Santa Claus

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
