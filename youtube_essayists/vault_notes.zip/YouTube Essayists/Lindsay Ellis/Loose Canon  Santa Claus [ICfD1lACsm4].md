---
title: "Loose Canon:  Santa Claus"
channel: "Lindsay Ellis"
type: "video"
video_id: "ICfD1lACsm4"
url: "https://www.youtube.com/watch?v=ICfD1lACsm4"
duration: "00:17:25"
upload_order: 57
about_ko: "Loose Canon: 산타클로스"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon:  Santa Claus

채널: [[Lindsay Ellis]] · 길이 00:17:25 · [YouTube](https://www.youtube.com/watch?v=ICfD1lACsm4)

## 어떤 영상인가

Loose Canon: 산타클로스

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
