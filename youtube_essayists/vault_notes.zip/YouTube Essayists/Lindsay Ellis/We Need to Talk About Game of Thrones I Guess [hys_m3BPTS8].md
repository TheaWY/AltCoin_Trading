---
title: "We Need to Talk About Game of Thrones I Guess"
channel: "Lindsay Ellis"
type: "video"
video_id: "hys_m3BPTS8"
url: "https://www.youtube.com/watch?v=hys_m3BPTS8"
duration: "00:44:04"
upload_order: 101
about: "On the later seasons of Game of Thrones"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# We Need to Talk About Game of Thrones I Guess

Channel: [[Lindsay Ellis]] · Length 00:44:04 · [YouTube](https://www.youtube.com/watch?v=hys_m3BPTS8)

## What it is

On the later seasons of Game of Thrones

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
