---
title: "We Need to Talk About Game of Thrones I Guess"
channel: "Lindsay Ellis"
type: "video"
video_id: "hys_m3BPTS8"
url: "https://www.youtube.com/watch?v=hys_m3BPTS8"
duration: "00:44:04"
upload_order: 101
about_ko: "왕좌의 게임 후반 시즌에 대한 이야기"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# We Need to Talk About Game of Thrones I Guess

채널: [[Lindsay Ellis]] · 길이 00:44:04 · [YouTube](https://www.youtube.com/watch?v=hys_m3BPTS8)

## 어떤 영상인가

왕좌의 게임 후반 시즌에 대한 이야기

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
