---
title: "Nostalgic Woman - Lord of the Rings: Return of the King (Part 1)"
channel: "Lindsay Ellis"
type: "video"
video_id: "Zi_zw3xDTa8"
url: "https://www.youtube.com/watch?v=Zi_zw3xDTa8"
duration: "00:17:03"
upload_order: 41
about: "Nostalgic Woman: The Return of the King, part 1"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Nostalgic Woman - Lord of the Rings: Return of the King (Part 1)

Channel: [[Lindsay Ellis]] · Length 00:17:03 · [YouTube](https://www.youtube.com/watch?v=Zi_zw3xDTa8)

## What it is

Nostalgic Woman: The Return of the King, part 1

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
