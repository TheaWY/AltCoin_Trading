---
title: "Nostalgic Woman - Lord of the Rings: Return of the King (Part 1)"
channel: "Lindsay Ellis"
type: "video"
video_id: "Zi_zw3xDTa8"
url: "https://www.youtube.com/watch?v=Zi_zw3xDTa8"
duration: "00:17:03"
upload_order: 41
about_ko: "Nostalgic Woman: 반지의 제왕 왕의 귀환 1부"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Nostalgic Woman - Lord of the Rings: Return of the King (Part 1)

채널: [[Lindsay Ellis]] · 길이 00:17:03 · [YouTube](https://www.youtube.com/watch?v=Zi_zw3xDTa8)

## 어떤 영상인가

Nostalgic Woman: 반지의 제왕 왕의 귀환 1부

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
