---
title: "S2E4 - Topical Parody"
channel: "Lindsay Ellis"
type: "video"
video_id: "RNkjDGwhg5Y"
url: "https://www.youtube.com/watch?v=RNkjDGwhg5Y"
duration: "00:14:33"
upload_order: 22
about: "Chick Lit S2E4: topical parody"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E4 - Topical Parody

Channel: [[Lindsay Ellis]] · Length 00:14:33 · [YouTube](https://www.youtube.com/watch?v=RNkjDGwhg5Y)

## What it is

Chick Lit S2E4: topical parody

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
