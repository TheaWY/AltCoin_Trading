---
title: "S2E4 - Topical Parody"
channel: "Lindsay Ellis"
type: "video"
video_id: "RNkjDGwhg5Y"
url: "https://www.youtube.com/watch?v=RNkjDGwhg5Y"
duration: "00:14:33"
upload_order: 22
about_ko: "Chick Lit S2E4: 시사 패러디"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E4 - Topical Parody

채널: [[Lindsay Ellis]] · 길이 00:14:33 · [YouTube](https://www.youtube.com/watch?v=RNkjDGwhg5Y)

## 어떤 영상인가

Chick Lit S2E4: 시사 패러디

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
