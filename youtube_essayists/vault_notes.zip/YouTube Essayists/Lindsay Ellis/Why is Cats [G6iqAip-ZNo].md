---
title: "Why is Cats?"
channel: "Lindsay Ellis"
type: "video"
video_id: "G6iqAip-ZNo"
url: "https://www.youtube.com/watch?v=G6iqAip-ZNo"
duration: "00:57:30"
upload_order: 106
about_ko: "영화/뮤지컬 캣츠는 왜 존재하는가"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Why is Cats?

채널: [[Lindsay Ellis]] · 길이 00:57:30 · [YouTube](https://www.youtube.com/watch?v=G6iqAip-ZNo)

## 어떤 영상인가

영화/뮤지컬 캣츠는 왜 존재하는가

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
