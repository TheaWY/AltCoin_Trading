---
title: "Why is Cats?"
channel: "Lindsay Ellis"
type: "video"
video_id: "G6iqAip-ZNo"
url: "https://www.youtube.com/watch?v=G6iqAip-ZNo"
duration: "00:57:30"
upload_order: 106
about: "Why does Cats (the film and musical) exist?"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Why is Cats?

Channel: [[Lindsay Ellis]] · Length 00:57:30 · [YouTube](https://www.youtube.com/watch?v=G6iqAip-ZNo)

## What it is

Why does Cats (the film and musical) exist?

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
