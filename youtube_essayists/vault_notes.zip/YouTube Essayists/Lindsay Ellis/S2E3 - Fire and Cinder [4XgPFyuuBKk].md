---
title: "S2E3 - Fire and Cinder"
channel: "Lindsay Ellis"
type: "video"
video_id: "4XgPFyuuBKk"
url: "https://www.youtube.com/watch?v=4XgPFyuuBKk"
duration: "00:14:40"
upload_order: 21
about_ko: "Chick Lit S2E3: Fire and Cinder (제목 기준)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E3 - Fire and Cinder

채널: [[Lindsay Ellis]] · 길이 00:14:40 · [YouTube](https://www.youtube.com/watch?v=4XgPFyuuBKk)

## 어떤 영상인가

Chick Lit S2E3: Fire and Cinder (제목 기준)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
