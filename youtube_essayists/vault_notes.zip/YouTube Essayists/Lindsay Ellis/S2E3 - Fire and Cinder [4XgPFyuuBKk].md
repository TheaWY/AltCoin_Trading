---
title: "S2E3 - Fire and Cinder"
channel: "Lindsay Ellis"
type: "video"
video_id: "4XgPFyuuBKk"
url: "https://www.youtube.com/watch?v=4XgPFyuuBKk"
duration: "00:14:40"
upload_order: 21
about: "Chick Lit S2E3: Fire and Cinder (guessed from title)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E3 - Fire and Cinder

Channel: [[Lindsay Ellis]] · Length 00:14:40 · [YouTube](https://www.youtube.com/watch?v=4XgPFyuuBKk)

## What it is

Chick Lit S2E3: Fire and Cinder (guessed from title)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
