---
title: "The Hobbit: A Long-Expected Autopsy (Part 1/2)"
channel: "Lindsay Ellis"
type: "video"
video_id: "uTRUQ-RKfUs"
url: "https://www.youtube.com/watch?v=uTRUQ-RKfUs"
duration: "00:36:49"
upload_order: 88
about: "Autopsy of how the Hobbit trilogy was made, part 1"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Hobbit: A Long-Expected Autopsy (Part 1/2)

Channel: [[Lindsay Ellis]] · Length 00:36:49 · [YouTube](https://www.youtube.com/watch?v=uTRUQ-RKfUs)

## What it is

Autopsy of how the Hobbit trilogy was made, part 1

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
