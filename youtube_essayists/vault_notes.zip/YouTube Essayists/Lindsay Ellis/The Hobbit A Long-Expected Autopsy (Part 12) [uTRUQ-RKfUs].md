---
title: "The Hobbit: A Long-Expected Autopsy (Part 1/2)"
channel: "Lindsay Ellis"
type: "video"
video_id: "uTRUQ-RKfUs"
url: "https://www.youtube.com/watch?v=uTRUQ-RKfUs"
duration: "00:36:49"
upload_order: 88
about_ko: "호빗 3부작 제작 과정 '부검' 1부"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# The Hobbit: A Long-Expected Autopsy (Part 1/2)

채널: [[Lindsay Ellis]] · 길이 00:36:49 · [YouTube](https://www.youtube.com/watch?v=uTRUQ-RKfUs)

## 어떤 영상인가

호빗 3부작 제작 과정 '부검' 1부

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
