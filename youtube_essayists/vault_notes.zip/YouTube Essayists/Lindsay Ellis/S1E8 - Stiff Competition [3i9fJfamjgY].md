---
title: "S1E8 - Stiff Competition"
channel: "Lindsay Ellis"
type: "video"
video_id: "3i9fJfamjgY"
url: "https://www.youtube.com/watch?v=3i9fJfamjgY"
duration: "00:05:20"
upload_order: 8
about_ko: "Chick Lit S1E8: Stiff Competition"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E8 - Stiff Competition

채널: [[Lindsay Ellis]] · 길이 00:05:20 · [YouTube](https://www.youtube.com/watch?v=3i9fJfamjgY)

## 어떤 영상인가

Chick Lit S1E8: Stiff Competition

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
