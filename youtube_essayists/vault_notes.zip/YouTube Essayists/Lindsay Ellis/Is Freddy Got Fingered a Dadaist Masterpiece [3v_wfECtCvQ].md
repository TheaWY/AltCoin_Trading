---
title: "Is Freddy Got Fingered a Dadaist Masterpiece?"
channel: "Lindsay Ellis"
type: "video"
video_id: "3v_wfECtCvQ"
url: "https://www.youtube.com/watch?v=3v_wfECtCvQ"
duration: "00:19:40"
upload_order: 32
about: "Is Freddy Got Fingered a Dadaist masterpiece?"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Is Freddy Got Fingered a Dadaist Masterpiece?

Channel: [[Lindsay Ellis]] · Length 00:19:40 · [YouTube](https://www.youtube.com/watch?v=3v_wfECtCvQ)

## What it is

Is Freddy Got Fingered a Dadaist masterpiece?

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
