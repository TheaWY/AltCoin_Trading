---
title: "Is Freddy Got Fingered a Dadaist Masterpiece?"
channel: "Lindsay Ellis"
type: "video"
video_id: "3v_wfECtCvQ"
url: "https://www.youtube.com/watch?v=3v_wfECtCvQ"
duration: "00:19:40"
upload_order: 32
about_ko: "Freddy Got Fingered는 다다이즘 걸작인가"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Is Freddy Got Fingered a Dadaist Masterpiece?

채널: [[Lindsay Ellis]] · 길이 00:19:40 · [YouTube](https://www.youtube.com/watch?v=3v_wfECtCvQ)

## 어떤 영상인가

Freddy Got Fingered는 다다이즘 걸작인가

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
