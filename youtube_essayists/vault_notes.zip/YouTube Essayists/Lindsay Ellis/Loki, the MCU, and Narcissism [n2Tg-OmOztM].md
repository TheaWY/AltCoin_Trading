---
title: "Loki, the MCU, and Narcissism"
channel: "Lindsay Ellis"
type: "video"
video_id: "n2Tg-OmOztM"
url: "https://www.youtube.com/watch?v=n2Tg-OmOztM"
duration: "00:36:34"
upload_order: 118
about_ko: "드라마 로키와 MCU 서사의 자기도취적 구조"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loki, the MCU, and Narcissism

채널: [[Lindsay Ellis]] · 길이 00:36:34 · [YouTube](https://www.youtube.com/watch?v=n2Tg-OmOztM)

## 어떤 영상인가

드라마 로키와 MCU 서사의 자기도취적 구조

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
