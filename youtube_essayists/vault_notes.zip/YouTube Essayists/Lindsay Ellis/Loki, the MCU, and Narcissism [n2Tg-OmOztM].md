---
title: "Loki, the MCU, and Narcissism"
channel: "Lindsay Ellis"
type: "video"
video_id: "n2Tg-OmOztM"
url: "https://www.youtube.com/watch?v=n2Tg-OmOztM"
duration: "00:36:34"
upload_order: 118
about: "Loki and the self-absorbed structure of MCU storytelling"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loki, the MCU, and Narcissism

Channel: [[Lindsay Ellis]] · Length 00:36:34 · [YouTube](https://www.youtube.com/watch?v=n2Tg-OmOztM)

## What it is

Loki and the self-absorbed structure of MCU storytelling

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
