---
title: "Queering Michael Bay | The Whole Plate: Episode 8"
channel: "Lindsay Ellis"
type: "video"
video_id: "btbAxY6P3Oc"
url: "https://www.youtube.com/watch?v=btbAxY6P3Oc"
duration: "00:16:20"
upload_order: 92
about: "The Whole Plate ep. 8: queer readings of Michael Bay films"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Queering Michael Bay | The Whole Plate: Episode 8

Channel: [[Lindsay Ellis]] · Length 00:16:20 · [YouTube](https://www.youtube.com/watch?v=btbAxY6P3Oc)

## What it is

The Whole Plate ep. 8: queer readings of Michael Bay films

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
