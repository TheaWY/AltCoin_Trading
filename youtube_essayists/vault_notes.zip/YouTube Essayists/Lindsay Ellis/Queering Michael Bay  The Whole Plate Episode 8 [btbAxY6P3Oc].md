---
title: "Queering Michael Bay | The Whole Plate: Episode 8"
channel: "Lindsay Ellis"
type: "video"
video_id: "btbAxY6P3Oc"
url: "https://www.youtube.com/watch?v=btbAxY6P3Oc"
duration: "00:16:20"
upload_order: 92
about_ko: "The Whole Plate 8화: 마이클 베이 영화의 퀴어 이론 해석"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Queering Michael Bay | The Whole Plate: Episode 8

채널: [[Lindsay Ellis]] · 길이 00:16:20 · [YouTube](https://www.youtube.com/watch?v=btbAxY6P3Oc)

## 어떤 영상인가

The Whole Plate 8화: 마이클 베이 영화의 퀴어 이론 해석

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
