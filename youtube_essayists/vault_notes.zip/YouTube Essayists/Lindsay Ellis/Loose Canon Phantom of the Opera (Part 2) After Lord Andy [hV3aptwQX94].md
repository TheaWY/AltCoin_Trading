---
title: "Loose Canon: Phantom of the Opera (Part 2): After Lord Andy"
channel: "Lindsay Ellis"
type: "video"
video_id: "hV3aptwQX94"
url: "https://www.youtube.com/watch?v=hV3aptwQX94"
duration: "00:23:25"
upload_order: 35
about: "Loose Canon: Phantom of the Opera, part 2 (after Andrew Lloyd Webber)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Phantom of the Opera (Part 2): After Lord Andy

Channel: [[Lindsay Ellis]] · Length 00:23:25 · [YouTube](https://www.youtube.com/watch?v=hV3aptwQX94)

## What it is

Loose Canon: Phantom of the Opera, part 2 (after Andrew Lloyd Webber)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
