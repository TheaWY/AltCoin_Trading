---
title: "Loose Canon: Phantom of the Opera (Part 2): After Lord Andy"
channel: "Lindsay Ellis"
type: "video"
video_id: "hV3aptwQX94"
url: "https://www.youtube.com/watch?v=hV3aptwQX94"
duration: "00:23:25"
upload_order: 35
about_ko: "Loose Canon: 오페라의 유령 2부(앤드루 로이드 웨버 이후)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Phantom of the Opera (Part 2): After Lord Andy

채널: [[Lindsay Ellis]] · 길이 00:23:25 · [YouTube](https://www.youtube.com/watch?v=hV3aptwQX94)

## 어떤 영상인가

Loose Canon: 오페라의 유령 2부(앤드루 로이드 웨버 이후)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
