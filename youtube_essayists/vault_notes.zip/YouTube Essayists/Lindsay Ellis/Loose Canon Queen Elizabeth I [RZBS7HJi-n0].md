---
title: "Loose Canon: Queen Elizabeth I"
channel: "Lindsay Ellis"
type: "video"
video_id: "RZBS7HJi-n0"
url: "https://www.youtube.com/watch?v=RZBS7HJi-n0"
duration: "00:19:58"
upload_order: 36
about: "Loose Canon: Queen Elizabeth I"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Queen Elizabeth I

Channel: [[Lindsay Ellis]] · Length 00:19:58 · [YouTube](https://www.youtube.com/watch?v=RZBS7HJi-n0)

## What it is

Loose Canon: Queen Elizabeth I

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
