---
title: "Loose Canon: Queen Elizabeth I"
channel: "Lindsay Ellis"
type: "video"
video_id: "RZBS7HJi-n0"
url: "https://www.youtube.com/watch?v=RZBS7HJi-n0"
duration: "00:19:58"
upload_order: 36
about_ko: "Loose Canon: 엘리자베스 1세"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Queen Elizabeth I

채널: [[Lindsay Ellis]] · 길이 00:19:58 · [YouTube](https://www.youtube.com/watch?v=RZBS7HJi-n0)

## 어떤 영상인가

Loose Canon: 엘리자베스 1세

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
