---
title: "Watch the video here on Nebula https://nebula.tv/videos/lindsayellis-bodycam-youtube"
channel: "Lindsay Ellis"
type: "short"
video_id: "_H0zzRDQRvU"
url: "https://www.youtube.com/watch?v=_H0zzRDQRvU"
duration: ""
upload_order: 7
about: "[Short] Promo for a Nebula video on bodycam YouTube"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Watch the video here on Nebula https://nebula.tv/videos/lindsayellis-bodycam-youtube

Channel: [[Lindsay Ellis]] · Length  · [YouTube](https://www.youtube.com/watch?v=_H0zzRDQRvU)

## What it is

[Short] Promo for a Nebula video on bodycam YouTube

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
