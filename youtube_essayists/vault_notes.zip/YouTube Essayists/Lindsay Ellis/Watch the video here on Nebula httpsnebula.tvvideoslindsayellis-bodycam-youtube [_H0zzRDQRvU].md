---
title: "Watch the video here on Nebula https://nebula.tv/videos/lindsayellis-bodycam-youtube"
channel: "Lindsay Ellis"
type: "short"
video_id: "_H0zzRDQRvU"
url: "https://www.youtube.com/watch?v=_H0zzRDQRvU"
duration: ""
upload_order: 7
about_ko: "[Shorts] Nebula 영상(바디캠 유튜브) 홍보"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Watch the video here on Nebula https://nebula.tv/videos/lindsayellis-bodycam-youtube

채널: [[Lindsay Ellis]] · 길이  · [YouTube](https://www.youtube.com/watch?v=_H0zzRDQRvU)

## 어떤 영상인가

[Shorts] Nebula 영상(바디캠 유튜브) 홍보

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
