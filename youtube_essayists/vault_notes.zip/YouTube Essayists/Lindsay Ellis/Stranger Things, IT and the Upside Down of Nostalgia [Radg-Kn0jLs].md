---
title: "Stranger Things, IT and the Upside Down of Nostalgia"
channel: "Lindsay Ellis"
type: "video"
video_id: "Radg-Kn0jLs"
url: "https://www.youtube.com/watch?v=Radg-Kn0jLs"
duration: "00:13:12"
upload_order: 84
about_ko: "기묘한 이야기, IT와 향수 마케팅"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Stranger Things, IT and the Upside Down of Nostalgia

채널: [[Lindsay Ellis]] · 길이 00:13:12 · [YouTube](https://www.youtube.com/watch?v=Radg-Kn0jLs)

## 어떤 영상인가

기묘한 이야기, IT와 향수 마케팅

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
