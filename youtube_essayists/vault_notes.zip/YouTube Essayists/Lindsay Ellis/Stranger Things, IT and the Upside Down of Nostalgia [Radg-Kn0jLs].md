---
title: "Stranger Things, IT and the Upside Down of Nostalgia"
channel: "Lindsay Ellis"
type: "video"
video_id: "Radg-Kn0jLs"
url: "https://www.youtube.com/watch?v=Radg-Kn0jLs"
duration: "00:13:12"
upload_order: 84
about: "Stranger Things, IT and nostalgia marketing"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Stranger Things, IT and the Upside Down of Nostalgia

Channel: [[Lindsay Ellis]] · Length 00:13:12 · [YouTube](https://www.youtube.com/watch?v=Radg-Kn0jLs)

## What it is

Stranger Things, IT and nostalgia marketing

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
