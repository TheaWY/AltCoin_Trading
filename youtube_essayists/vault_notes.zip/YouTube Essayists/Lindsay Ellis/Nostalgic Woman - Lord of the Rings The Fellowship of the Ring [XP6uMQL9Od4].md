---
title: "Nostalgic Woman - Lord of the Rings: The Fellowship of the Ring"
channel: "Lindsay Ellis"
type: "video"
video_id: "XP6uMQL9Od4"
url: "https://www.youtube.com/watch?v=XP6uMQL9Od4"
duration: "00:19:40"
upload_order: 39
about: "Nostalgic Woman: The Fellowship of the Ring"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Nostalgic Woman - Lord of the Rings: The Fellowship of the Ring

Channel: [[Lindsay Ellis]] · Length 00:19:40 · [YouTube](https://www.youtube.com/watch?v=XP6uMQL9Od4)

## What it is

Nostalgic Woman: The Fellowship of the Ring

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
