---
title: "Nostalgic Woman - Lord of the Rings: The Fellowship of the Ring"
channel: "Lindsay Ellis"
type: "video"
video_id: "XP6uMQL9Od4"
url: "https://www.youtube.com/watch?v=XP6uMQL9Od4"
duration: "00:19:40"
upload_order: 39
about_ko: "Nostalgic Woman: 반지의 제왕 반지 원정대"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Nostalgic Woman - Lord of the Rings: The Fellowship of the Ring

채널: [[Lindsay Ellis]] · 길이 00:19:40 · [YouTube](https://www.youtube.com/watch?v=XP6uMQL9Od4)

## 어떤 영상인가

Nostalgic Woman: 반지의 제왕 반지 원정대

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
