---
title: "Loose Canon: 9/11- Part 2"
channel: "Lindsay Ellis"
type: "video"
video_id: "waL2lJVbAf4"
url: "https://www.youtube.com/watch?v=waL2lJVbAf4"
duration: "00:27:37"
upload_order: 48
about_ko: "Loose Canon: 9/11 영화적 재현 2부"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: 9/11- Part 2

채널: [[Lindsay Ellis]] · 길이 00:27:37 · [YouTube](https://www.youtube.com/watch?v=waL2lJVbAf4)

## 어떤 영상인가

Loose Canon: 9/11 영화적 재현 2부

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
