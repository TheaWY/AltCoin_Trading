---
title: "Loose Canon: 9/11- Part 2"
channel: "Lindsay Ellis"
type: "video"
video_id: "waL2lJVbAf4"
url: "https://www.youtube.com/watch?v=waL2lJVbAf4"
duration: "00:27:37"
upload_order: 48
about: "Loose Canon: 9/11 on film, part 2"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: 9/11- Part 2

Channel: [[Lindsay Ellis]] · Length 00:27:37 · [YouTube](https://www.youtube.com/watch?v=waL2lJVbAf4)

## What it is

Loose Canon: 9/11 on film, part 2

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
