---
title: "S1E9 - The Journey Begins"
channel: "Lindsay Ellis"
type: "video"
video_id: "HS4N6S9EeYE"
url: "https://www.youtube.com/watch?v=HS4N6S9EeYE"
duration: "00:05:56"
upload_order: 9
about: "Chick Lit S1E9: the journey begins"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E9 - The Journey Begins

Channel: [[Lindsay Ellis]] · Length 00:05:56 · [YouTube](https://www.youtube.com/watch?v=HS4N6S9EeYE)

## What it is

Chick Lit S1E9: the journey begins

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
