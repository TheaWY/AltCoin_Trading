---
title: "S1E9 - The Journey Begins"
channel: "Lindsay Ellis"
type: "video"
video_id: "HS4N6S9EeYE"
url: "https://www.youtube.com/watch?v=HS4N6S9EeYE"
duration: "00:05:56"
upload_order: 9
about_ko: "Chick Lit S1E9: 여정의 시작"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E9 - The Journey Begins

채널: [[Lindsay Ellis]] · 길이 00:05:56 · [YouTube](https://www.youtube.com/watch?v=HS4N6S9EeYE)

## 어떤 영상인가

Chick Lit S1E9: 여정의 시작

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
