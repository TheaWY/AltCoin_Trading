---
title: "Loose Canon: Captain America"
channel: "Lindsay Ellis"
type: "video"
video_id: "FS7mCUgd9eI"
url: "https://www.youtube.com/watch?v=FS7mCUgd9eI"
duration: "00:27:24"
upload_order: 64
about_ko: "Loose Canon: 캡틴 아메리카 각색사"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Captain America

채널: [[Lindsay Ellis]] · 길이 00:27:24 · [YouTube](https://www.youtube.com/watch?v=FS7mCUgd9eI)

## 어떤 영상인가

Loose Canon: 캡틴 아메리카 각색사

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
