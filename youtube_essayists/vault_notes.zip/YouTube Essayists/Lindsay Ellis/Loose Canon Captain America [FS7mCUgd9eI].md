---
title: "Loose Canon: Captain America"
channel: "Lindsay Ellis"
type: "video"
video_id: "FS7mCUgd9eI"
url: "https://www.youtube.com/watch?v=FS7mCUgd9eI"
duration: "00:27:24"
upload_order: 64
about: "Loose Canon: Captain America across adaptations"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Captain America

Channel: [[Lindsay Ellis]] · Length 00:27:24 · [YouTube](https://www.youtube.com/watch?v=FS7mCUgd9eI)

## What it is

Loose Canon: Captain America across adaptations

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
