---
title: "Death of the Author 2: Rowling Boogaloo"
channel: "Lindsay Ellis"
type: "video"
video_id: "NViZYL-U8s0"
url: "https://www.youtube.com/watch?v=NViZYL-U8s0"
duration: "00:17:59"
upload_order: 110
about_ko: "'작가의 죽음' 속편: J.K. 롤링 사례"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Death of the Author 2: Rowling Boogaloo

채널: [[Lindsay Ellis]] · 길이 00:17:59 · [YouTube](https://www.youtube.com/watch?v=NViZYL-U8s0)

## 어떤 영상인가

'작가의 죽음' 속편: J.K. 롤링 사례

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
