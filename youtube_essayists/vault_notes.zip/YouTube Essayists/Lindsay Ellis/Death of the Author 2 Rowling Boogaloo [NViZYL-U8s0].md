---
title: "Death of the Author 2: Rowling Boogaloo"
channel: "Lindsay Ellis"
type: "video"
video_id: "NViZYL-U8s0"
url: "https://www.youtube.com/watch?v=NViZYL-U8s0"
duration: "00:17:59"
upload_order: 110
about: "Death of the Author, part two: the J.K. Rowling case"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Death of the Author 2: Rowling Boogaloo

Channel: [[Lindsay Ellis]] · Length 00:17:59 · [YouTube](https://www.youtube.com/watch?v=NViZYL-U8s0)

## What it is

Death of the Author, part two: the J.K. Rowling case

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
