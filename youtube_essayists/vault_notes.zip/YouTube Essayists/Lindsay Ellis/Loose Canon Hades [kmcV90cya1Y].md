---
title: "Loose Canon: Hades"
channel: "Lindsay Ellis"
type: "video"
video_id: "kmcV90cya1Y"
url: "https://www.youtube.com/watch?v=kmcV90cya1Y"
duration: "00:22:11"
upload_order: 63
about: "Loose Canon: Hades across adaptations"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Hades

Channel: [[Lindsay Ellis]] · Length 00:22:11 · [YouTube](https://www.youtube.com/watch?v=kmcV90cya1Y)

## What it is

Loose Canon: Hades across adaptations

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
