---
title: "Loose Canon: Hades"
channel: "Lindsay Ellis"
type: "video"
video_id: "kmcV90cya1Y"
url: "https://www.youtube.com/watch?v=kmcV90cya1Y"
duration: "00:22:11"
upload_order: 63
about_ko: "Loose Canon: 하데스 각색사"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Hades

채널: [[Lindsay Ellis]] · 길이 00:22:11 · [YouTube](https://www.youtube.com/watch?v=kmcV90cya1Y)

## 어떤 영상인가

Loose Canon: 하데스 각색사

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
