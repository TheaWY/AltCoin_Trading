---
title: "Loose Canon: Nightcrawler"
channel: "Lindsay Ellis"
type: "video"
video_id: "puw0JxMj3eE"
url: "https://www.youtube.com/watch?v=puw0JxMj3eE"
duration: "00:20:02"
upload_order: 69
about: "Loose Canon: Nightcrawler's history across adaptations"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Nightcrawler

Channel: [[Lindsay Ellis]] · Length 00:20:02 · [YouTube](https://www.youtube.com/watch?v=puw0JxMj3eE)

## What it is

Loose Canon: Nightcrawler's history across adaptations

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
