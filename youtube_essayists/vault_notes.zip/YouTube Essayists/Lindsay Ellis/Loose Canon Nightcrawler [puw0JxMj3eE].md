---
title: "Loose Canon: Nightcrawler"
channel: "Lindsay Ellis"
type: "video"
video_id: "puw0JxMj3eE"
url: "https://www.youtube.com/watch?v=puw0JxMj3eE"
duration: "00:20:02"
upload_order: 69
about_ko: "Loose Canon: 엑스맨 나이트크롤러의 각색사"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Nightcrawler

채널: [[Lindsay Ellis]] · 길이 00:20:02 · [YouTube](https://www.youtube.com/watch?v=puw0JxMj3eE)

## 어떤 영상인가

Loose Canon: 엑스맨 나이트크롤러의 각색사

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
