---
title: "S3E3 - Glory O'Brien's History of the Future by AS King"
channel: "Lindsay Ellis"
type: "video"
video_id: "eUUfNsJdaDk"
url: "https://www.youtube.com/watch?v=eUUfNsJdaDk"
duration: "00:15:12"
upload_order: 31
about_ko: "Chick Lit S3E3: A.S. King 소설 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S3E3 - Glory O'Brien's History of the Future by AS King

채널: [[Lindsay Ellis]] · 길이 00:15:12 · [YouTube](https://www.youtube.com/watch?v=eUUfNsJdaDk)

## 어떤 영상인가

Chick Lit S3E3: A.S. King 소설 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
