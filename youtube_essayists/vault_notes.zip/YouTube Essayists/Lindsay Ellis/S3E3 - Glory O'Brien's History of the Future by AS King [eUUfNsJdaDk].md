---
title: "S3E3 - Glory O'Brien's History of the Future by AS King"
channel: "Lindsay Ellis"
type: "video"
video_id: "eUUfNsJdaDk"
url: "https://www.youtube.com/watch?v=eUUfNsJdaDk"
duration: "00:15:12"
upload_order: 31
about: "Chick Lit S3E3: review of an A.S. King novel"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S3E3 - Glory O'Brien's History of the Future by AS King

Channel: [[Lindsay Ellis]] · Length 00:15:12 · [YouTube](https://www.youtube.com/watch?v=eUUfNsJdaDk)

## What it is

Chick Lit S3E3: review of an A.S. King novel

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
