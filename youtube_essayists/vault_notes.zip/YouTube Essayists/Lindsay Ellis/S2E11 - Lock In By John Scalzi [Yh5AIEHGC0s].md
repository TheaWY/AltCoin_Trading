---
title: "S2E11 - Lock In By John Scalzi"
channel: "Lindsay Ellis"
type: "video"
video_id: "Yh5AIEHGC0s"
url: "https://www.youtube.com/watch?v=Yh5AIEHGC0s"
duration: "00:25:26"
upload_order: 27
about_ko: "Chick Lit S2E11: 존 스칼지 Lock In 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E11 - Lock In By John Scalzi

채널: [[Lindsay Ellis]] · 길이 00:25:26 · [YouTube](https://www.youtube.com/watch?v=Yh5AIEHGC0s)

## 어떤 영상인가

Chick Lit S2E11: 존 스칼지 Lock In 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
