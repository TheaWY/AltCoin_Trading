---
title: "S2E11 - Lock In By John Scalzi"
channel: "Lindsay Ellis"
type: "video"
video_id: "Yh5AIEHGC0s"
url: "https://www.youtube.com/watch?v=Yh5AIEHGC0s"
duration: "00:25:26"
upload_order: 27
about: "Chick Lit S2E11: review of John Scalzi's Lock In"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S2E11 - Lock In By John Scalzi

Channel: [[Lindsay Ellis]] · Length 00:25:26 · [YouTube](https://www.youtube.com/watch?v=Yh5AIEHGC0s)

## What it is

Chick Lit S2E11: review of John Scalzi's Lock In

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
