---
title: "Loose Canon: The Wicked Witch of the West"
channel: "Lindsay Ellis"
type: "video"
video_id: "xiZB4WgjJmA"
url: "https://www.youtube.com/watch?v=xiZB4WgjJmA"
duration: "00:27:18"
upload_order: 66
about: "Loose Canon: the Wicked Witch of the West across adaptations"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: The Wicked Witch of the West

Channel: [[Lindsay Ellis]] · Length 00:27:18 · [YouTube](https://www.youtube.com/watch?v=xiZB4WgjJmA)

## What it is

Loose Canon: the Wicked Witch of the West across adaptations

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
