---
title: "Loose Canon: The Wicked Witch of the West"
channel: "Lindsay Ellis"
type: "video"
video_id: "xiZB4WgjJmA"
url: "https://www.youtube.com/watch?v=xiZB4WgjJmA"
duration: "00:27:18"
upload_order: 66
about_ko: "Loose Canon: 오즈의 서쪽 마녀 각색사"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: The Wicked Witch of the West

채널: [[Lindsay Ellis]] · 길이 00:27:18 · [YouTube](https://www.youtube.com/watch?v=xiZB4WgjJmA)

## 어떤 영상인가

Loose Canon: 오즈의 서쪽 마녀 각색사

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
