---
title: "Ed Sheeran’s non-complicity merch"
channel: "Lindsay Ellis"
type: "short"
video_id: "OPE7pTKNstM"
url: "https://www.youtube.com/watch?v=OPE7pTKNstM"
duration: ""
upload_order: 9
about_ko: "[Shorts] 에드 시런 굿즈 관련 짧은 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Ed Sheeran’s non-complicity merch

채널: [[Lindsay Ellis]] · 길이  · [YouTube](https://www.youtube.com/watch?v=OPE7pTKNstM)

## 어떤 영상인가

[Shorts] 에드 시런 굿즈 관련 짧은 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
