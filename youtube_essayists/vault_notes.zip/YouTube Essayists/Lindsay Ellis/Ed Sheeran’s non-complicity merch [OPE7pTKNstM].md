---
title: "Ed Sheeran’s non-complicity merch"
channel: "Lindsay Ellis"
type: "short"
video_id: "OPE7pTKNstM"
url: "https://www.youtube.com/watch?v=OPE7pTKNstM"
duration: ""
upload_order: 9
about: "[Short] About Ed Sheeran merch"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Ed Sheeran’s non-complicity merch

Channel: [[Lindsay Ellis]] · Length  · [YouTube](https://www.youtube.com/watch?v=OPE7pTKNstM)

## What it is

[Short] About Ed Sheeran merch

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
