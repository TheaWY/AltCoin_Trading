---
title: "Bluey adults! Only on Nebula and only for adults. https://nebula.tv/videos/lindsayellis-bluey-adults"
channel: "Lindsay Ellis"
type: "short"
video_id: "lkx4jLg41kc"
url: "https://www.youtube.com/watch?v=lkx4jLg41kc"
duration: ""
upload_order: 6
about: "[Short] Promo for a Nebula video on adult Bluey fans"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Bluey adults! Only on Nebula and only for adults. https://nebula.tv/videos/lindsayellis-bluey-adults

Channel: [[Lindsay Ellis]] · Length  · [YouTube](https://www.youtube.com/watch?v=lkx4jLg41kc)

## What it is

[Short] Promo for a Nebula video on adult Bluey fans

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
