---
title: "Bluey adults! Only on Nebula and only for adults. https://nebula.tv/videos/lindsayellis-bluey-adults"
channel: "Lindsay Ellis"
type: "short"
video_id: "lkx4jLg41kc"
url: "https://www.youtube.com/watch?v=lkx4jLg41kc"
duration: ""
upload_order: 6
about_ko: "[Shorts] Nebula 영상(Bluey 성인 팬) 홍보"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Bluey adults! Only on Nebula and only for adults. https://nebula.tv/videos/lindsayellis-bluey-adults

채널: [[Lindsay Ellis]] · 길이  · [YouTube](https://www.youtube.com/watch?v=lkx4jLg41kc)

## 어떤 영상인가

[Shorts] Nebula 영상(Bluey 성인 팬) 홍보

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
