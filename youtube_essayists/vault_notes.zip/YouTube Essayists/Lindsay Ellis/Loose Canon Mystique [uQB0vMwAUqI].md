---
title: "Loose Canon: Mystique"
channel: "Lindsay Ellis"
type: "video"
video_id: "uQB0vMwAUqI"
url: "https://www.youtube.com/watch?v=uQB0vMwAUqI"
duration: "00:17:16"
upload_order: 49
about_ko: "Loose Canon: 미스틱"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Mystique

채널: [[Lindsay Ellis]] · 길이 00:17:16 · [YouTube](https://www.youtube.com/watch?v=uQB0vMwAUqI)

## 어떤 영상인가

Loose Canon: 미스틱

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
