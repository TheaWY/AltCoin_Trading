---
title: "Loose Canon: Mystique"
channel: "Lindsay Ellis"
type: "video"
video_id: "uQB0vMwAUqI"
url: "https://www.youtube.com/watch?v=uQB0vMwAUqI"
duration: "00:17:16"
upload_order: 49
about: "Loose Canon: Mystique"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Mystique

Channel: [[Lindsay Ellis]] · Length 00:17:16 · [YouTube](https://www.youtube.com/watch?v=uQB0vMwAUqI)

## What it is

Loose Canon: Mystique

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
