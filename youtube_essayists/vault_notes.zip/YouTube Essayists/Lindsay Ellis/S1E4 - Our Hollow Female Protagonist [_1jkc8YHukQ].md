---
title: "S1E4 - Our Hollow Female Protagonist"
channel: "Lindsay Ellis"
type: "video"
video_id: "_1jkc8YHukQ"
url: "https://www.youtube.com/watch?v=_1jkc8YHukQ"
duration: "00:12:04"
upload_order: 4
about: "Chick Lit S1E4: building a hollow female protagonist"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E4 - Our Hollow Female Protagonist

Channel: [[Lindsay Ellis]] · Length 00:12:04 · [YouTube](https://www.youtube.com/watch?v=_1jkc8YHukQ)

## What it is

Chick Lit S1E4: building a hollow female protagonist

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
