---
title: "S1E4 - Our Hollow Female Protagonist"
channel: "Lindsay Ellis"
type: "video"
video_id: "_1jkc8YHukQ"
url: "https://www.youtube.com/watch?v=_1jkc8YHukQ"
duration: "00:12:04"
upload_order: 4
about_ko: "Chick Lit S1E4: 텅 빈 여주인공 만들기"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# S1E4 - Our Hollow Female Protagonist

채널: [[Lindsay Ellis]] · 길이 00:12:04 · [YouTube](https://www.youtube.com/watch?v=_1jkc8YHukQ)

## 어떤 영상인가

Chick Lit S1E4: 텅 빈 여주인공 만들기

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
