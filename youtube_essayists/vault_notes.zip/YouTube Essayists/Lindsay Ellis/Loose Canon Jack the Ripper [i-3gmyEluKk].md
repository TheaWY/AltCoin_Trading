---
title: "Loose Canon: Jack the Ripper"
channel: "Lindsay Ellis"
type: "video"
video_id: "i-3gmyEluKk"
url: "https://www.youtube.com/watch?v=i-3gmyEluKk"
duration: "00:22:13"
upload_order: 53
about_ko: "Loose Canon: 잭 더 리퍼"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Jack the Ripper

채널: [[Lindsay Ellis]] · 길이 00:22:13 · [YouTube](https://www.youtube.com/watch?v=i-3gmyEluKk)

## 어떤 영상인가

Loose Canon: 잭 더 리퍼

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
