---
title: "Loose Canon: Jack the Ripper"
channel: "Lindsay Ellis"
type: "video"
video_id: "i-3gmyEluKk"
url: "https://www.youtube.com/watch?v=i-3gmyEluKk"
duration: "00:22:13"
upload_order: 53
about: "Loose Canon: Jack the Ripper"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "lindsay-ellis"]
---

# Loose Canon: Jack the Ripper

Channel: [[Lindsay Ellis]] · Length 00:22:13 · [YouTube](https://www.youtube.com/watch?v=i-3gmyEluKk)

## What it is

Loose Canon: Jack the Ripper

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
