---
title: "Doctor Strange Looks Familiar"
channel: "Jenny Nicholson"
type: "video"
video_id: "IBRUtdzTf8U"
url: "https://www.youtube.com/watch?v=IBRUtdzTf8U"
duration: "00:06:48"
upload_order: 23
about_ko: "닥터 스트레인지가 익숙해 보이는 이유(마블 공식)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Doctor Strange Looks Familiar

채널: [[Jenny Nicholson]] · 길이 00:06:48 · [YouTube](https://www.youtube.com/watch?v=IBRUtdzTf8U)

## 어떤 영상인가

닥터 스트레인지가 익숙해 보이는 이유(마블 공식)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
