---
title: "Doctor Strange Looks Familiar"
channel: "Jenny Nicholson"
type: "video"
video_id: "IBRUtdzTf8U"
url: "https://www.youtube.com/watch?v=IBRUtdzTf8U"
duration: "00:06:48"
upload_order: 23
about: "Why Doctor Strange feels familiar (the Marvel formula)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Doctor Strange Looks Familiar

Channel: [[Jenny Nicholson]] · Length 00:06:48 · [YouTube](https://www.youtube.com/watch?v=IBRUtdzTf8U)

## What it is

Why Doctor Strange feels familiar (the Marvel formula)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
