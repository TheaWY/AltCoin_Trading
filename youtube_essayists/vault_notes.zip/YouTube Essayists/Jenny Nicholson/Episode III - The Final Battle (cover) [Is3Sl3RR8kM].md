---
title: "Episode III - \"The Final Battle\" (cover)"
channel: "Jenny Nicholson"
type: "video"
video_id: "Is3Sl3RR8kM"
url: "https://www.youtube.com/watch?v=Is3Sl3RR8kM"
duration: "00:01:22"
upload_order: 3
about_ko: "스타워즈 에피소드 III 'The Final Battle' 음악 커버"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Episode III - "The Final Battle" (cover)

채널: [[Jenny Nicholson]] · 길이 00:01:22 · [YouTube](https://www.youtube.com/watch?v=Is3Sl3RR8kM)

## 어떤 영상인가

스타워즈 에피소드 III 'The Final Battle' 음악 커버

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
