---
title: "Episode III - \"The Final Battle\" (cover)"
channel: "Jenny Nicholson"
type: "video"
video_id: "Is3Sl3RR8kM"
url: "https://www.youtube.com/watch?v=Is3Sl3RR8kM"
duration: "00:01:22"
upload_order: 3
about: "Music cover of \"The Final Battle\" from Episode III"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Episode III - "The Final Battle" (cover)

Channel: [[Jenny Nicholson]] · Length 00:01:22 · [YouTube](https://www.youtube.com/watch?v=Is3Sl3RR8kM)

## What it is

Music cover of "The Final Battle" from Episode III

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
