---
title: "Should we let Jurassic World 2 get melted by this volcano?"
channel: "Jenny Nicholson"
type: "video"
video_id: "PRwI1unON7A"
url: "https://www.youtube.com/watch?v=PRwI1unON7A"
duration: "00:30:53"
upload_order: 73
about: "Review of Jurassic World: Fallen Kingdom"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Should we let Jurassic World 2 get melted by this volcano?

Channel: [[Jenny Nicholson]] · Length 00:30:53 · [YouTube](https://www.youtube.com/watch?v=PRwI1unON7A)

## What it is

Review of Jurassic World: Fallen Kingdom

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
