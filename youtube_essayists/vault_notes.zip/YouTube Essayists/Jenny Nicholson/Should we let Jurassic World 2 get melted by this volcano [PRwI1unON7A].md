---
title: "Should we let Jurassic World 2 get melted by this volcano?"
channel: "Jenny Nicholson"
type: "video"
video_id: "PRwI1unON7A"
url: "https://www.youtube.com/watch?v=PRwI1unON7A"
duration: "00:30:53"
upload_order: 73
about_ko: "쥬라기 월드: 폴른 킹덤 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Should we let Jurassic World 2 get melted by this volcano?

채널: [[Jenny Nicholson]] · 길이 00:30:53 · [YouTube](https://www.youtube.com/watch?v=PRwI1unON7A)

## 어떤 영상인가

쥬라기 월드: 폴른 킹덤 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
