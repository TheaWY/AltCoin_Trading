---
title: "25 Knights of Ren Theories"
channel: "Jenny Nicholson"
type: "video"
video_id: "pt3ZtY9pIKo"
url: "https://www.youtube.com/watch?v=pt3ZtY9pIKo"
duration: "00:07:52"
upload_order: 78
about_ko: "스타워즈 '렌 기사단' 정체에 대한 25가지 이론"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# 25 Knights of Ren Theories

채널: [[Jenny Nicholson]] · 길이 00:07:52 · [YouTube](https://www.youtube.com/watch?v=pt3ZtY9pIKo)

## 어떤 영상인가

스타워즈 '렌 기사단' 정체에 대한 25가지 이론

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
