---
title: "Oh no! The Rise of Skywalker was real bad :("
channel: "Jenny Nicholson"
type: "video"
video_id: "GErIPKjwuDg"
url: "https://www.youtube.com/watch?v=GErIPKjwuDg"
duration: "01:04:47"
upload_order: 101
about_ko: "스타워즈: 라이즈 오브 스카이워커 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Oh no! The Rise of Skywalker was real bad :(

채널: [[Jenny Nicholson]] · 길이 01:04:47 · [YouTube](https://www.youtube.com/watch?v=GErIPKjwuDg)

## 어떤 영상인가

스타워즈: 라이즈 오브 스카이워커 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
