---
title: "Oh no! The Rise of Skywalker was real bad :("
channel: "Jenny Nicholson"
type: "video"
video_id: "GErIPKjwuDg"
url: "https://www.youtube.com/watch?v=GErIPKjwuDg"
duration: "01:04:47"
upload_order: 101
about: "Critique of Star Wars: The Rise of Skywalker"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Oh no! The Rise of Skywalker was real bad :(

Channel: [[Jenny Nicholson]] · Length 01:04:47 · [YouTube](https://www.youtube.com/watch?v=GErIPKjwuDg)

## What it is

Critique of Star Wars: The Rise of Skywalker

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
