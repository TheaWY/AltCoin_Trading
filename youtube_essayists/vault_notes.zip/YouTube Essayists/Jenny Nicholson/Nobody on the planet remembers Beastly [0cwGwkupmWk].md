---
title: "Nobody on the planet remembers Beastly"
channel: "Jenny Nicholson"
type: "video"
video_id: "0cwGwkupmWk"
url: "https://www.youtube.com/watch?v=0cwGwkupmWk"
duration: "00:46:57"
upload_order: 77
about_ko: "아무도 기억하지 못하는 영화 Beastly(2011) 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Nobody on the planet remembers Beastly

채널: [[Jenny Nicholson]] · 길이 00:46:57 · [YouTube](https://www.youtube.com/watch?v=0cwGwkupmWk)

## 어떤 영상인가

아무도 기억하지 못하는 영화 Beastly(2011) 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
