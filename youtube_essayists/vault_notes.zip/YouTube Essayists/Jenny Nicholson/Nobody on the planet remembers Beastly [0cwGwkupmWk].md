---
title: "Nobody on the planet remembers Beastly"
channel: "Jenny Nicholson"
type: "video"
video_id: "0cwGwkupmWk"
url: "https://www.youtube.com/watch?v=0cwGwkupmWk"
duration: "00:46:57"
upload_order: 77
about: "Review of the forgotten film Beastly (2011)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Nobody on the planet remembers Beastly

Channel: [[Jenny Nicholson]] · Length 00:46:57 · [YouTube](https://www.youtube.com/watch?v=0cwGwkupmWk)

## What it is

Review of the forgotten film Beastly (2011)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
