---
title: "5 Dumbest Episode VIII Theories"
channel: "Jenny Nicholson"
type: "video"
video_id: "Pu-dTtt0BGk"
url: "https://www.youtube.com/watch?v=Pu-dTtt0BGk"
duration: "00:08:12"
upload_order: 17
about_ko: "에피소드 VIII에 대한 가장 바보 같은 팬 이론 5가지"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# 5 Dumbest Episode VIII Theories

채널: [[Jenny Nicholson]] · 길이 00:08:12 · [YouTube](https://www.youtube.com/watch?v=Pu-dTtt0BGk)

## 어떤 영상인가

에피소드 VIII에 대한 가장 바보 같은 팬 이론 5가지

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
