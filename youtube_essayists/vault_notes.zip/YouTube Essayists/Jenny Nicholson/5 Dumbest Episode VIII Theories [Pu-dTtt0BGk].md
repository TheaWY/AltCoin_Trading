---
title: "5 Dumbest Episode VIII Theories"
channel: "Jenny Nicholson"
type: "video"
video_id: "Pu-dTtt0BGk"
url: "https://www.youtube.com/watch?v=Pu-dTtt0BGk"
duration: "00:08:12"
upload_order: 17
about: "The 5 dumbest Episode VIII fan theories"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# 5 Dumbest Episode VIII Theories

Channel: [[Jenny Nicholson]] · Length 00:08:12 · [YouTube](https://www.youtube.com/watch?v=Pu-dTtt0BGk)

## What it is

The 5 dumbest Episode VIII fan theories

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
