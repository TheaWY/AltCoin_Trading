---
title: "I played Battlefront II and"
channel: "Jenny Nicholson"
type: "video"
video_id: "YTDa55gBk_E"
url: "https://www.youtube.com/watch?v=YTDa55gBk_E"
duration: "00:08:44"
upload_order: 52
about: "Thoughts after playing Star Wars Battlefront II (2017)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# I played Battlefront II and

Channel: [[Jenny Nicholson]] · Length 00:08:44 · [YouTube](https://www.youtube.com/watch?v=YTDa55gBk_E)

## What it is

Thoughts after playing Star Wars Battlefront II (2017)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
