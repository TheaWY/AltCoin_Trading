---
title: "I played Battlefront II and"
channel: "Jenny Nicholson"
type: "video"
video_id: "YTDa55gBk_E"
url: "https://www.youtube.com/watch?v=YTDa55gBk_E"
duration: "00:08:44"
upload_order: 52
about_ko: "스타워즈 배틀프론트 II(2017) 플레이 소감"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# I played Battlefront II and

채널: [[Jenny Nicholson]] · 길이 00:08:44 · [YouTube](https://www.youtube.com/watch?v=YTDa55gBk_E)

## 어떤 영상인가

스타워즈 배틀프론트 II(2017) 플레이 소감

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
