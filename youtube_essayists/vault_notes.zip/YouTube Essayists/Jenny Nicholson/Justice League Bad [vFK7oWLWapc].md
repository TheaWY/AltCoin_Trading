---
title: "Justice League Bad"
channel: "Jenny Nicholson"
type: "video"
video_id: "vFK7oWLWapc"
url: "https://www.youtube.com/watch?v=vFK7oWLWapc"
duration: "00:12:37"
upload_order: 53
about_ko: "저스티스 리그(2017) 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Justice League Bad

채널: [[Jenny Nicholson]] · 길이 00:12:37 · [YouTube](https://www.youtube.com/watch?v=vFK7oWLWapc)

## 어떤 영상인가

저스티스 리그(2017) 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
