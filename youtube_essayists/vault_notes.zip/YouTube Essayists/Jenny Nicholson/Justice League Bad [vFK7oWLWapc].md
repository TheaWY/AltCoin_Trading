---
title: "Justice League Bad"
channel: "Jenny Nicholson"
type: "video"
video_id: "vFK7oWLWapc"
url: "https://www.youtube.com/watch?v=vFK7oWLWapc"
duration: "00:12:37"
upload_order: 53
about: "Critique of Justice League (2017)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Justice League Bad

Channel: [[Jenny Nicholson]] · Length 00:12:37 · [YouTube](https://www.youtube.com/watch?v=vFK7oWLWapc)

## What it is

Critique of Justice League (2017)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
