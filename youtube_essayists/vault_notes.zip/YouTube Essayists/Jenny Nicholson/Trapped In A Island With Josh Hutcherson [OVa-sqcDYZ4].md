---
title: "Trapped In A Island With Josh Hutcherson"
channel: "Jenny Nicholson"
type: "video"
video_id: "OVa-sqcDYZ4"
url: "https://www.youtube.com/watch?v=OVa-sqcDYZ4"
duration: "00:26:54"
upload_order: 54
about: "Reading a fanfic about being stranded on an island with Josh Hutcherson"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Trapped In A Island With Josh Hutcherson

Channel: [[Jenny Nicholson]] · Length 00:26:54 · [YouTube](https://www.youtube.com/watch?v=OVa-sqcDYZ4)

## What it is

Reading a fanfic about being stranded on an island with Josh Hutcherson

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
