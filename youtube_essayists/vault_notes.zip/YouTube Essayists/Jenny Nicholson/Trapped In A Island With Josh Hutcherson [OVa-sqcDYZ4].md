---
title: "Trapped In A Island With Josh Hutcherson"
channel: "Jenny Nicholson"
type: "video"
video_id: "OVa-sqcDYZ4"
url: "https://www.youtube.com/watch?v=OVa-sqcDYZ4"
duration: "00:26:54"
upload_order: 54
about_ko: "조시 허처슨과 무인도에 갇히는 팬픽 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Trapped In A Island With Josh Hutcherson

채널: [[Jenny Nicholson]] · 길이 00:26:54 · [YouTube](https://www.youtube.com/watch?v=OVa-sqcDYZ4)

## 어떤 영상인가

조시 허처슨과 무인도에 갇히는 팬픽 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
