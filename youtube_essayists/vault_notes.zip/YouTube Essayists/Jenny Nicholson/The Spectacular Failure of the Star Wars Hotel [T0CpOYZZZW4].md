---
title: "The Spectacular Failure of the Star Wars Hotel"
channel: "Jenny Nicholson"
type: "video"
video_id: "T0CpOYZZZW4"
url: "https://www.youtube.com/watch?v=T0CpOYZZZW4"
duration: "04:05:39"
upload_order: 112
about: "Her stay at Disney's Galactic Starcruiser and why it failed. The channel's best-known video"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Spectacular Failure of the Star Wars Hotel

Channel: [[Jenny Nicholson]] · Length 04:05:39 · [YouTube](https://www.youtube.com/watch?v=T0CpOYZZZW4)

## What it is

Her stay at Disney's Galactic Starcruiser and why it failed. The channel's best-known video

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
