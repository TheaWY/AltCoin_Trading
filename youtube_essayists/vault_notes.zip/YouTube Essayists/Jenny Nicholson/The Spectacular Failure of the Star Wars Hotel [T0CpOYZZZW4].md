---
title: "The Spectacular Failure of the Star Wars Hotel"
channel: "Jenny Nicholson"
type: "video"
video_id: "T0CpOYZZZW4"
url: "https://www.youtube.com/watch?v=T0CpOYZZZW4"
duration: "04:05:39"
upload_order: 112
about_ko: "디즈니 스타워즈 호텔(Galactic Starcruiser)에 직접 묵어본 체험기이자 그 실패 원인 분석. 채널 대표작"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Spectacular Failure of the Star Wars Hotel

채널: [[Jenny Nicholson]] · 길이 04:05:39 · [YouTube](https://www.youtube.com/watch?v=T0CpOYZZZW4)

## 어떤 영상인가

디즈니 스타워즈 호텔(Galactic Starcruiser)에 직접 묵어본 체험기이자 그 실패 원인 분석. 채널 대표작

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
