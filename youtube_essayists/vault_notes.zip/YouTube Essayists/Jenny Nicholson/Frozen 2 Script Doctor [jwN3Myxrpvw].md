---
title: "Frozen 2 Script Doctor"
channel: "Jenny Nicholson"
type: "video"
video_id: "jwN3Myxrpvw"
url: "https://www.youtube.com/watch?v=jwN3Myxrpvw"
duration: "00:28:52"
upload_order: 98
about_ko: "겨울왕국 2 각본을 고쳐 쓰는 Script Doctor 시리즈"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Frozen 2 Script Doctor

채널: [[Jenny Nicholson]] · 길이 00:28:52 · [YouTube](https://www.youtube.com/watch?v=jwN3Myxrpvw)

## 어떤 영상인가

겨울왕국 2 각본을 고쳐 쓰는 Script Doctor 시리즈

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
