---
title: "Frozen 2 Script Doctor"
channel: "Jenny Nicholson"
type: "video"
video_id: "jwN3Myxrpvw"
url: "https://www.youtube.com/watch?v=jwN3Myxrpvw"
duration: "00:28:52"
upload_order: 98
about: "Script Doctor: rewriting Frozen 2"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Frozen 2 Script Doctor

Channel: [[Jenny Nicholson]] · Length 00:28:52 · [YouTube](https://www.youtube.com/watch?v=jwN3Myxrpvw)

## What it is

Script Doctor: rewriting Frozen 2

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
