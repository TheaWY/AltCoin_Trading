---
title: "Escape from Tomorrow is a dumb exercise in misery"
channel: "Jenny Nicholson"
type: "video"
video_id: "38BiNsFFzcs"
url: "https://www.youtube.com/watch?v=38BiNsFFzcs"
duration: "00:47:34"
upload_order: 62
about: "Critique of Escape from Tomorrow, shot guerrilla-style at Disney World"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Escape from Tomorrow is a dumb exercise in misery

Channel: [[Jenny Nicholson]] · Length 00:47:34 · [YouTube](https://www.youtube.com/watch?v=38BiNsFFzcs)

## What it is

Critique of Escape from Tomorrow, shot guerrilla-style at Disney World

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
