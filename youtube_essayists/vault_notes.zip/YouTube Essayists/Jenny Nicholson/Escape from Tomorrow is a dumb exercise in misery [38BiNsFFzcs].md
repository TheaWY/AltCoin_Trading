---
title: "Escape from Tomorrow is a dumb exercise in misery"
channel: "Jenny Nicholson"
type: "video"
video_id: "38BiNsFFzcs"
url: "https://www.youtube.com/watch?v=38BiNsFFzcs"
duration: "00:47:34"
upload_order: 62
about_ko: "디즈니 월드에서 몰래 찍은 영화 Escape from Tomorrow 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Escape from Tomorrow is a dumb exercise in misery

채널: [[Jenny Nicholson]] · 길이 00:47:34 · [YouTube](https://www.youtube.com/watch?v=38BiNsFFzcs)

## 어떤 영상인가

디즈니 월드에서 몰래 찍은 영화 Escape from Tomorrow 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
