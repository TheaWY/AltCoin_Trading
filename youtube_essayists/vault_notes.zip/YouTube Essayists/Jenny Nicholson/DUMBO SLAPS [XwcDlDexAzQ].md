---
title: "DUMBO SLAPS"
channel: "Jenny Nicholson"
type: "video"
video_id: "XwcDlDexAzQ"
url: "https://www.youtube.com/watch?v=XwcDlDexAzQ"
duration: "00:21:41"
upload_order: 88
about: "Review of Tim Burton's live-action Dumbo (2019)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# DUMBO SLAPS

Channel: [[Jenny Nicholson]] · Length 00:21:41 · [YouTube](https://www.youtube.com/watch?v=XwcDlDexAzQ)

## What it is

Review of Tim Burton's live-action Dumbo (2019)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
