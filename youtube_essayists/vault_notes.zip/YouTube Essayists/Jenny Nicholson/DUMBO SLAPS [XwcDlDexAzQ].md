---
title: "DUMBO SLAPS"
channel: "Jenny Nicholson"
type: "video"
video_id: "XwcDlDexAzQ"
url: "https://www.youtube.com/watch?v=XwcDlDexAzQ"
duration: "00:21:41"
upload_order: 88
about_ko: "팀 버튼 실사판 덤보(2019) 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# DUMBO SLAPS

채널: [[Jenny Nicholson]] · 길이 00:21:41 · [YouTube](https://www.youtube.com/watch?v=XwcDlDexAzQ)

## 어떤 영상인가

팀 버튼 실사판 덤보(2019) 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
