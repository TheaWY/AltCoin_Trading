---
title: "Voldemort Isn't Funny"
channel: "Jenny Nicholson"
type: "video"
video_id: "wGj-AWQVBPk"
url: "https://www.youtube.com/watch?v=wGj-AWQVBPk"
duration: "00:01:00"
upload_order: 1
about: "Early short comedy arguing Voldemort isn't funny"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Voldemort Isn't Funny

Channel: [[Jenny Nicholson]] · Length 00:01:00 · [YouTube](https://www.youtube.com/watch?v=wGj-AWQVBPk)

## What it is

Early short comedy arguing Voldemort isn't funny

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
