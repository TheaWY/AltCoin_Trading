---
title: "Voldemort Isn't Funny"
channel: "Jenny Nicholson"
type: "video"
video_id: "wGj-AWQVBPk"
url: "https://www.youtube.com/watch?v=wGj-AWQVBPk"
duration: "00:01:00"
upload_order: 1
about_ko: "볼드모트는 웃기지 않다는 초기 짧은 코미디"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Voldemort Isn't Funny

채널: [[Jenny Nicholson]] · 길이 00:01:00 · [YouTube](https://www.youtube.com/watch?v=wGj-AWQVBPk)

## 어떤 영상인가

볼드모트는 웃기지 않다는 초기 짧은 코미디

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
