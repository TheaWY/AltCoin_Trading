---
title: "If Rey is a Skywalker"
channel: "Jenny Nicholson"
type: "video"
video_id: "mjHEHuNyvME"
url: "https://www.youtube.com/watch?v=mjHEHuNyvME"
duration: "00:04:45"
upload_order: 16
about_ko: "레이가 스카이워커 가문이라면 하는 짧은 고찰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# If Rey is a Skywalker

채널: [[Jenny Nicholson]] · 길이 00:04:45 · [YouTube](https://www.youtube.com/watch?v=mjHEHuNyvME)

## 어떤 영상인가

레이가 스카이워커 가문이라면 하는 짧은 고찰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
