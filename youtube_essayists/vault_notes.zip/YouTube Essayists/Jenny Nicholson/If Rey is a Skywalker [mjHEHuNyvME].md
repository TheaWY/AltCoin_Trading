---
title: "If Rey is a Skywalker"
channel: "Jenny Nicholson"
type: "video"
video_id: "mjHEHuNyvME"
url: "https://www.youtube.com/watch?v=mjHEHuNyvME"
duration: "00:04:45"
upload_order: 16
about: "Short take on what it would mean if Rey were a Skywalker"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# If Rey is a Skywalker

Channel: [[Jenny Nicholson]] · Length 00:04:45 · [YouTube](https://www.youtube.com/watch?v=mjHEHuNyvME)

## What it is

Short take on what it would mean if Rey were a Skywalker

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
