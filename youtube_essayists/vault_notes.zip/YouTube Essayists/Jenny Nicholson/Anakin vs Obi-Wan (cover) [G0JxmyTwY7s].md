---
title: "Anakin vs Obi-Wan (cover)"
channel: "Jenny Nicholson"
type: "video"
video_id: "G0JxmyTwY7s"
url: "https://www.youtube.com/watch?v=G0JxmyTwY7s"
duration: "00:01:58"
upload_order: 6
about: "Music cover of Anakin vs Obi-Wan from Episode III"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Anakin vs Obi-Wan (cover)

Channel: [[Jenny Nicholson]] · Length 00:01:58 · [YouTube](https://www.youtube.com/watch?v=G0JxmyTwY7s)

## What it is

Music cover of Anakin vs Obi-Wan from Episode III

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
