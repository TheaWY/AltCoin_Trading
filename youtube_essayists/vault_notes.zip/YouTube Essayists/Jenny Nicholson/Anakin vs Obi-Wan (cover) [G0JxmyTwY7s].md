---
title: "Anakin vs Obi-Wan (cover)"
channel: "Jenny Nicholson"
type: "video"
video_id: "G0JxmyTwY7s"
url: "https://www.youtube.com/watch?v=G0JxmyTwY7s"
duration: "00:01:58"
upload_order: 6
about_ko: "스타워즈 에피소드 III 아나킨 대 오비완 음악 커버"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Anakin vs Obi-Wan (cover)

채널: [[Jenny Nicholson]] · 길이 00:01:58 · [YouTube](https://www.youtube.com/watch?v=G0JxmyTwY7s)

## 어떤 영상인가

스타워즈 에피소드 III 아나킨 대 오비완 음악 커버

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
