---
title: "Original Star Wars Costume Ideas"
channel: "Jenny Nicholson"
type: "video"
video_id: "FXNwk4fHDOo"
url: "https://www.youtube.com/watch?v=FXNwk4fHDOo"
duration: "00:07:01"
upload_order: 87
about: "Her own original Star Wars costume ideas"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Original Star Wars Costume Ideas

Channel: [[Jenny Nicholson]] · Length 00:07:01 · [YouTube](https://www.youtube.com/watch?v=FXNwk4fHDOo)

## What it is

Her own original Star Wars costume ideas

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
