---
title: "Original Star Wars Costume Ideas"
channel: "Jenny Nicholson"
type: "video"
video_id: "FXNwk4fHDOo"
url: "https://www.youtube.com/watch?v=FXNwk4fHDOo"
duration: "00:07:01"
upload_order: 87
about_ko: "직접 만든 오리지널 스타워즈 코스튬 아이디어 소개"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Original Star Wars Costume Ideas

채널: [[Jenny Nicholson]] · 길이 00:07:01 · [YouTube](https://www.youtube.com/watch?v=FXNwk4fHDOo)

## 어떤 영상인가

직접 만든 오리지널 스타워즈 코스튬 아이디어 소개

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
