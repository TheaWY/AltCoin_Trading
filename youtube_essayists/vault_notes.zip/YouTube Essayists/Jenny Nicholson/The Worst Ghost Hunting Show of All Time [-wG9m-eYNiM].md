---
title: "The Worst Ghost Hunting Show of All Time"
channel: "Jenny Nicholson"
type: "video"
video_id: "-wG9m-eYNiM"
url: "https://www.youtube.com/watch?v=-wG9m-eYNiM"
duration: "00:31:43"
upload_order: 79
about: "Review of the worst ghost hunting reality show"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Worst Ghost Hunting Show of All Time

Channel: [[Jenny Nicholson]] · Length 00:31:43 · [YouTube](https://www.youtube.com/watch?v=-wG9m-eYNiM)

## What it is

Review of the worst ghost hunting reality show

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
