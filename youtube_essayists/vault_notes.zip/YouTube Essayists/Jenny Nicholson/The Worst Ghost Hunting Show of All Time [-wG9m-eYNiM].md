---
title: "The Worst Ghost Hunting Show of All Time"
channel: "Jenny Nicholson"
type: "video"
video_id: "-wG9m-eYNiM"
url: "https://www.youtube.com/watch?v=-wG9m-eYNiM"
duration: "00:31:43"
upload_order: 79
about_ko: "역대 최악의 유령 사냥 리얼리티 쇼 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Worst Ghost Hunting Show of All Time

채널: [[Jenny Nicholson]] · 길이 00:31:43 · [YouTube](https://www.youtube.com/watch?v=-wG9m-eYNiM)

## 어떤 영상인가

역대 최악의 유령 사냥 리얼리티 쇼 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
