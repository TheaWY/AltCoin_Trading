---
title: "Solo Bad"
channel: "Jenny Nicholson"
type: "video"
video_id: "XP8FZ4cBzaI"
url: "https://www.youtube.com/watch?v=XP8FZ4cBzaI"
duration: "00:49:55"
upload_order: 71
about: "Critique of Solo: A Star Wars Story"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Solo Bad

Channel: [[Jenny Nicholson]] · Length 00:49:55 · [YouTube](https://www.youtube.com/watch?v=XP8FZ4cBzaI)

## What it is

Critique of Solo: A Star Wars Story

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
