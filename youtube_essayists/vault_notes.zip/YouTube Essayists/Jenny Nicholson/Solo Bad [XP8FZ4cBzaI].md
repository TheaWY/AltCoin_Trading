---
title: "Solo Bad"
channel: "Jenny Nicholson"
type: "video"
video_id: "XP8FZ4cBzaI"
url: "https://www.youtube.com/watch?v=XP8FZ4cBzaI"
duration: "00:49:55"
upload_order: 71
about_ko: "한 솔로: 스타워즈 스토리 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Solo Bad

채널: [[Jenny Nicholson]] · 길이 00:49:55 · [YouTube](https://www.youtube.com/watch?v=XP8FZ4cBzaI)

## 어떤 영상인가

한 솔로: 스타워즈 스토리 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
