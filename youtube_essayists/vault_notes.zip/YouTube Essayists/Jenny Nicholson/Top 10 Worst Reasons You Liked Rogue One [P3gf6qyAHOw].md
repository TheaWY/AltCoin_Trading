---
title: "Top 10 Worst Reasons You Liked Rogue One"
channel: "Jenny Nicholson"
type: "video"
video_id: "P3gf6qyAHOw"
url: "https://www.youtube.com/watch?v=P3gf6qyAHOw"
duration: "00:24:14"
upload_order: 27
about: "Top 10 worst reasons people liked Rogue One"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Top 10 Worst Reasons You Liked Rogue One

Channel: [[Jenny Nicholson]] · Length 00:24:14 · [YouTube](https://www.youtube.com/watch?v=P3gf6qyAHOw)

## What it is

Top 10 worst reasons people liked Rogue One

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
