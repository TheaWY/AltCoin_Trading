---
title: "Top 10 Worst Reasons You Liked Rogue One"
channel: "Jenny Nicholson"
type: "video"
video_id: "P3gf6qyAHOw"
url: "https://www.youtube.com/watch?v=P3gf6qyAHOw"
duration: "00:24:14"
upload_order: 27
about_ko: "로그 원을 좋아한 최악의 이유 톱 10"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Top 10 Worst Reasons You Liked Rogue One

채널: [[Jenny Nicholson]] · 길이 00:24:14 · [YouTube](https://www.youtube.com/watch?v=P3gf6qyAHOw)

## 어떤 영상인가

로그 원을 좋아한 최악의 이유 톱 10

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
