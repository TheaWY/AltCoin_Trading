---
title: "Rating. Every. Porg."
channel: "Jenny Nicholson"
type: "video"
video_id: "1yw6z9G7p1g"
url: "https://www.youtube.com/watch?v=1yw6z9G7p1g"
duration: "00:08:09"
upload_order: 72
about: "Rating porgs one by one"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Rating. Every. Porg.

Channel: [[Jenny Nicholson]] · Length 00:08:09 · [YouTube](https://www.youtube.com/watch?v=1yw6z9G7p1g)

## What it is

Rating porgs one by one

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
