---
title: "Rating. Every. Porg."
channel: "Jenny Nicholson"
type: "video"
video_id: "1yw6z9G7p1g"
url: "https://www.youtube.com/watch?v=1yw6z9G7p1g"
duration: "00:08:09"
upload_order: 72
about_ko: "스타워즈 포그 굿즈/장면을 하나씩 평가"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Rating. Every. Porg.

채널: [[Jenny Nicholson]] · 길이 00:08:09 · [YouTube](https://www.youtube.com/watch?v=1yw6z9G7p1g)

## 어떤 영상인가

스타워즈 포그 굿즈/장면을 하나씩 평가

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
