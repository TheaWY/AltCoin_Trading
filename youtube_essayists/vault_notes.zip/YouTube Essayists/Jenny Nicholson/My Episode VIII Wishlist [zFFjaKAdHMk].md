---
title: "My Episode VIII Wishlist"
channel: "Jenny Nicholson"
type: "video"
video_id: "zFFjaKAdHMk"
url: "https://www.youtube.com/watch?v=zFFjaKAdHMk"
duration: "00:05:47"
upload_order: 11
about_ko: "에피소드 VIII 위시리스트"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# My Episode VIII Wishlist

채널: [[Jenny Nicholson]] · 길이 00:05:47 · [YouTube](https://www.youtube.com/watch?v=zFFjaKAdHMk)

## 어떤 영상인가

에피소드 VIII 위시리스트

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
