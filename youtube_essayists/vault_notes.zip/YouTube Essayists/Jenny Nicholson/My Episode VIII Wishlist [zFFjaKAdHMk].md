---
title: "My Episode VIII Wishlist"
channel: "Jenny Nicholson"
type: "video"
video_id: "zFFjaKAdHMk"
url: "https://www.youtube.com/watch?v=zFFjaKAdHMk"
duration: "00:05:47"
upload_order: 11
about: "Her wishlist for Episode VIII"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# My Episode VIII Wishlist

Channel: [[Jenny Nicholson]] · Length 00:05:47 · [YouTube](https://www.youtube.com/watch?v=zFFjaKAdHMk)

## What it is

Her wishlist for Episode VIII

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
