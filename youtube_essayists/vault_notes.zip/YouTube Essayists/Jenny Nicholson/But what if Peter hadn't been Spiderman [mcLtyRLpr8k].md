---
title: "But what if Peter hadn't been Spiderman"
channel: "Jenny Nicholson"
type: "video"
video_id: "mcLtyRLpr8k"
url: "https://www.youtube.com/watch?v=mcLtyRLpr8k"
duration: "00:03:13"
upload_order: 42
about_ko: "피터 파커가 스파이더맨이 아니었다면 하는 짧은 상상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# But what if Peter hadn't been Spiderman

채널: [[Jenny Nicholson]] · 길이 00:03:13 · [YouTube](https://www.youtube.com/watch?v=mcLtyRLpr8k)

## 어떤 영상인가

피터 파커가 스파이더맨이 아니었다면 하는 짧은 상상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
