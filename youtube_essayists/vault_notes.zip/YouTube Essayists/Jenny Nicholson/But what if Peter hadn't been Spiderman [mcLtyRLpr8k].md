---
title: "But what if Peter hadn't been Spiderman"
channel: "Jenny Nicholson"
type: "video"
video_id: "mcLtyRLpr8k"
url: "https://www.youtube.com/watch?v=mcLtyRLpr8k"
duration: "00:03:13"
upload_order: 42
about: "Short what-if about Peter Parker not being Spider-Man"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# But what if Peter hadn't been Spiderman

Channel: [[Jenny Nicholson]] · Length 00:03:13 · [YouTube](https://www.youtube.com/watch?v=mcLtyRLpr8k)

## What it is

Short what-if about Peter Parker not being Spider-Man

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
