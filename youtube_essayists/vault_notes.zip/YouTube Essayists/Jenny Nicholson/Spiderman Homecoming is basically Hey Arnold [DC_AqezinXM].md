---
title: "Spiderman Homecoming is basically Hey Arnold"
channel: "Jenny Nicholson"
type: "video"
video_id: "DC_AqezinXM"
url: "https://www.youtube.com/watch?v=DC_AqezinXM"
duration: "00:08:39"
upload_order: 40
about_ko: "스파이더맨: 홈커밍이 사실상 Hey Arnold라는 비교"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Spiderman Homecoming is basically Hey Arnold

채널: [[Jenny Nicholson]] · 길이 00:08:39 · [YouTube](https://www.youtube.com/watch?v=DC_AqezinXM)

## 어떤 영상인가

스파이더맨: 홈커밍이 사실상 Hey Arnold라는 비교

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
