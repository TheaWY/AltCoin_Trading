---
title: "Spiderman Homecoming is basically Hey Arnold"
channel: "Jenny Nicholson"
type: "video"
video_id: "DC_AqezinXM"
url: "https://www.youtube.com/watch?v=DC_AqezinXM"
duration: "00:08:39"
upload_order: 40
about: "Arguing Spider-Man: Homecoming is basically Hey Arnold"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Spiderman Homecoming is basically Hey Arnold

Channel: [[Jenny Nicholson]] · Length 00:08:39 · [YouTube](https://www.youtube.com/watch?v=DC_AqezinXM)

## What it is

Arguing Spider-Man: Homecoming is basically Hey Arnold

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
