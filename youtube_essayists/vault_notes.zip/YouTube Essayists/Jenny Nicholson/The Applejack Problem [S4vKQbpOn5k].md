---
title: "The Applejack Problem"
channel: "Jenny Nicholson"
type: "video"
video_id: "S4vKQbpOn5k"
url: "https://www.youtube.com/watch?v=S4vKQbpOn5k"
duration: "00:19:06"
upload_order: 57
about_ko: "마이 리틀 포니 캐릭터 애플잭의 서사적 문제"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Applejack Problem

채널: [[Jenny Nicholson]] · 길이 00:19:06 · [YouTube](https://www.youtube.com/watch?v=S4vKQbpOn5k)

## 어떤 영상인가

마이 리틀 포니 캐릭터 애플잭의 서사적 문제

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
