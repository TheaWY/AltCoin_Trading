---
title: "The Applejack Problem"
channel: "Jenny Nicholson"
type: "video"
video_id: "S4vKQbpOn5k"
url: "https://www.youtube.com/watch?v=S4vKQbpOn5k"
duration: "00:19:06"
upload_order: 57
about: "The writing problem with Applejack in My Little Pony"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Applejack Problem

Channel: [[Jenny Nicholson]] · Length 00:19:06 · [YouTube](https://www.youtube.com/watch?v=S4vKQbpOn5k)

## What it is

The writing problem with Applejack in My Little Pony

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
