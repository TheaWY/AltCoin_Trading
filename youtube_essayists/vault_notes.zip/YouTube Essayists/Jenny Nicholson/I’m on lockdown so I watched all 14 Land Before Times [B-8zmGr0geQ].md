---
title: "I’m on lockdown so I watched all 14 Land Before Times"
channel: "Jenny Nicholson"
type: "video"
video_id: "B-8zmGr0geQ"
url: "https://www.youtube.com/watch?v=B-8zmGr0geQ"
duration: "00:58:46"
upload_order: 103
about: "Watching and reviewing all 14 Land Before Time films during lockdown"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# I’m on lockdown so I watched all 14 Land Before Times

Channel: [[Jenny Nicholson]] · Length 00:58:46 · [YouTube](https://www.youtube.com/watch?v=B-8zmGr0geQ)

## What it is

Watching and reviewing all 14 Land Before Time films during lockdown

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
