---
title: "I’m on lockdown so I watched all 14 Land Before Times"
channel: "Jenny Nicholson"
type: "video"
video_id: "B-8zmGr0geQ"
url: "https://www.youtube.com/watch?v=B-8zmGr0geQ"
duration: "00:58:46"
upload_order: 103
about_ko: "코로나 봉쇄 중 Land Before Time 시리즈 14편을 전부 보고 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# I’m on lockdown so I watched all 14 Land Before Times

채널: [[Jenny Nicholson]] · 길이 00:58:46 · [YouTube](https://www.youtube.com/watch?v=B-8zmGr0geQ)

## 어떤 영상인가

코로나 봉쇄 중 Land Before Time 시리즈 14편을 전부 보고 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
