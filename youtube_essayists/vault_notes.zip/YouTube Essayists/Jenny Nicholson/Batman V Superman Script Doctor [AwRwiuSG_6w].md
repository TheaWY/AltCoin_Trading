---
title: "Batman V Superman Script Doctor"
channel: "Jenny Nicholson"
type: "video"
video_id: "AwRwiuSG_6w"
url: "https://www.youtube.com/watch?v=AwRwiuSG_6w"
duration: "00:08:09"
upload_order: 18
about: "Script Doctor: rewriting Batman v Superman"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Batman V Superman Script Doctor

Channel: [[Jenny Nicholson]] · Length 00:08:09 · [YouTube](https://www.youtube.com/watch?v=AwRwiuSG_6w)

## What it is

Script Doctor: rewriting Batman v Superman

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
