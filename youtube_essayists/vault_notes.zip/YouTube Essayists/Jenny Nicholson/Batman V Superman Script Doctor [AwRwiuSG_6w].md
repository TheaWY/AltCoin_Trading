---
title: "Batman V Superman Script Doctor"
channel: "Jenny Nicholson"
type: "video"
video_id: "AwRwiuSG_6w"
url: "https://www.youtube.com/watch?v=AwRwiuSG_6w"
duration: "00:08:09"
upload_order: 18
about_ko: "배트맨 대 슈퍼맨 각본 고쳐 쓰기"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Batman V Superman Script Doctor

채널: [[Jenny Nicholson]] · 길이 00:08:09 · [YouTube](https://www.youtube.com/watch?v=AwRwiuSG_6w)

## 어떤 영상인가

배트맨 대 슈퍼맨 각본 고쳐 쓰기

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
