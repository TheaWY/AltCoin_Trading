---
title: "The Grim Dystopia of A Christmas Prince"
channel: "Jenny Nicholson"
type: "video"
video_id: "BsHT1fYouYU"
url: "https://www.youtube.com/watch?v=BsHT1fYouYU"
duration: "00:32:53"
upload_order: 83
about_ko: "넷플릭스 영화 A Christmas Prince의 이상한 세계관 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Grim Dystopia of A Christmas Prince

채널: [[Jenny Nicholson]] · 길이 00:32:53 · [YouTube](https://www.youtube.com/watch?v=BsHT1fYouYU)

## 어떤 영상인가

넷플릭스 영화 A Christmas Prince의 이상한 세계관 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
