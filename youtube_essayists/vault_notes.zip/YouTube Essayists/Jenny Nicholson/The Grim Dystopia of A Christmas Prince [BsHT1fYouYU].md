---
title: "The Grim Dystopia of A Christmas Prince"
channel: "Jenny Nicholson"
type: "video"
video_id: "BsHT1fYouYU"
url: "https://www.youtube.com/watch?v=BsHT1fYouYU"
duration: "00:32:53"
upload_order: 83
about: "The odd world of Netflix's A Christmas Prince"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Grim Dystopia of A Christmas Prince

Channel: [[Jenny Nicholson]] · Length 00:32:53 · [YouTube](https://www.youtube.com/watch?v=BsHT1fYouYU)

## What it is

The odd world of Netflix's A Christmas Prince

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
