---
title: "Well, I didn’t like Joker"
channel: "Jenny Nicholson"
type: "video"
video_id: "0tsdOo_wO44"
url: "https://www.youtube.com/watch?v=0tsdOo_wO44"
duration: "00:33:54"
upload_order: 96
about_ko: "영화 조커(2019)를 왜 싫어했는지 설명하는 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Well, I didn’t like Joker

채널: [[Jenny Nicholson]] · 길이 00:33:54 · [YouTube](https://www.youtube.com/watch?v=0tsdOo_wO44)

## 어떤 영상인가

영화 조커(2019)를 왜 싫어했는지 설명하는 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
