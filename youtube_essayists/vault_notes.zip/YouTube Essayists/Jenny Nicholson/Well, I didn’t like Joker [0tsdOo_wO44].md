---
title: "Well, I didn’t like Joker"
channel: "Jenny Nicholson"
type: "video"
video_id: "0tsdOo_wO44"
url: "https://www.youtube.com/watch?v=0tsdOo_wO44"
duration: "00:33:54"
upload_order: 96
about: "Why she didn't like Joker (2019)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Well, I didn’t like Joker

Channel: [[Jenny Nicholson]] · Length 00:33:54 · [YouTube](https://www.youtube.com/watch?v=0tsdOo_wO44)

## What it is

Why she didn't like Joker (2019)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
