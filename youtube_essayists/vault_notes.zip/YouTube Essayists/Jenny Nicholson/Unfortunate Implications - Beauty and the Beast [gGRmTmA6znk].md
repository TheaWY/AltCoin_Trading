---
title: "Unfortunate Implications - Beauty and the Beast"
channel: "Jenny Nicholson"
type: "video"
video_id: "gGRmTmA6znk"
url: "https://www.youtube.com/watch?v=gGRmTmA6znk"
duration: "00:08:34"
upload_order: 33
about: "Unfortunate implications in Beauty and the Beast"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Unfortunate Implications - Beauty and the Beast

Channel: [[Jenny Nicholson]] · Length 00:08:34 · [YouTube](https://www.youtube.com/watch?v=gGRmTmA6znk)

## What it is

Unfortunate implications in Beauty and the Beast

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
