---
title: "Unfortunate Implications - Beauty and the Beast"
channel: "Jenny Nicholson"
type: "video"
video_id: "gGRmTmA6znk"
url: "https://www.youtube.com/watch?v=gGRmTmA6znk"
duration: "00:08:34"
upload_order: 33
about_ko: "미녀와 야수의 문제적 함의"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Unfortunate Implications - Beauty and the Beast

채널: [[Jenny Nicholson]] · 길이 00:08:34 · [YouTube](https://www.youtube.com/watch?v=gGRmTmA6znk)

## 어떤 영상인가

미녀와 야수의 문제적 함의

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
