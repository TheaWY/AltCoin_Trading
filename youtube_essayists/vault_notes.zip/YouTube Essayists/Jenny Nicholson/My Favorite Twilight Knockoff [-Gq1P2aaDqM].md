---
title: "My Favorite Twilight Knockoff"
channel: "Jenny Nicholson"
type: "video"
video_id: "-Gq1P2aaDqM"
url: "https://www.youtube.com/watch?v=-Gq1P2aaDqM"
duration: "01:40:33"
upload_order: 113
about: "Long review of her favorite Twilight-era YA knockoff"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# My Favorite Twilight Knockoff

Channel: [[Jenny Nicholson]] · Length 01:40:33 · [YouTube](https://www.youtube.com/watch?v=-Gq1P2aaDqM)

## What it is

Long review of her favorite Twilight-era YA knockoff

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
