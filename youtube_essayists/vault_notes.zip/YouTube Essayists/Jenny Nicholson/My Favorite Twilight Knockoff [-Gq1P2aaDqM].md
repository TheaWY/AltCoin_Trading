---
title: "My Favorite Twilight Knockoff"
channel: "Jenny Nicholson"
type: "video"
video_id: "-Gq1P2aaDqM"
url: "https://www.youtube.com/watch?v=-Gq1P2aaDqM"
duration: "01:40:33"
upload_order: 113
about_ko: "트와일라잇 아류 YA 소설/영화들 중 가장 좋아하는 작품을 파고드는 장편 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# My Favorite Twilight Knockoff

채널: [[Jenny Nicholson]] · 길이 01:40:33 · [YouTube](https://www.youtube.com/watch?v=-Gq1P2aaDqM)

## 어떤 영상인가

트와일라잇 아류 YA 소설/영화들 중 가장 좋아하는 작품을 파고드는 장편 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
