---
title: "The Worst Reality Show of All Time"
channel: "Jenny Nicholson"
type: "video"
video_id: "JKFgn6tNU6w"
url: "https://www.youtube.com/watch?v=JKFgn6tNU6w"
duration: "00:25:43"
upload_order: 60
about_ko: "역대 최악의 리얼리티 쇼 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Worst Reality Show of All Time

채널: [[Jenny Nicholson]] · 길이 00:25:43 · [YouTube](https://www.youtube.com/watch?v=JKFgn6tNU6w)

## 어떤 영상인가

역대 최악의 리얼리티 쇼 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
