---
title: "The Worst Reality Show of All Time"
channel: "Jenny Nicholson"
type: "video"
video_id: "JKFgn6tNU6w"
url: "https://www.youtube.com/watch?v=JKFgn6tNU6w"
duration: "00:25:43"
upload_order: 60
about: "Review of the worst reality show"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Worst Reality Show of All Time

Channel: [[Jenny Nicholson]] · Length 00:25:43 · [YouTube](https://www.youtube.com/watch?v=JKFgn6tNU6w)

## What it is

Review of the worst reality show

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
