---
title: "15 Very Dumb Things in Fantastic Beasts 2"
channel: "Jenny Nicholson"
type: "video"
video_id: "QYUJ_ODfc8w"
url: "https://www.youtube.com/watch?v=QYUJ_ODfc8w"
duration: "00:31:03"
upload_order: 81
about_ko: "신비한 동물들과 그린델왈드의 범죄 속 어이없는 지점 15가지"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# 15 Very Dumb Things in Fantastic Beasts 2

채널: [[Jenny Nicholson]] · 길이 00:31:03 · [YouTube](https://www.youtube.com/watch?v=QYUJ_ODfc8w)

## 어떤 영상인가

신비한 동물들과 그린델왈드의 범죄 속 어이없는 지점 15가지

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
