---
title: "15 Very Dumb Things in Fantastic Beasts 2"
channel: "Jenny Nicholson"
type: "video"
video_id: "QYUJ_ODfc8w"
url: "https://www.youtube.com/watch?v=QYUJ_ODfc8w"
duration: "00:31:03"
upload_order: 81
about: "15 dumb things in Fantastic Beasts: The Crimes of Grindelwald"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# 15 Very Dumb Things in Fantastic Beasts 2

Channel: [[Jenny Nicholson]] · Length 00:31:03 · [YouTube](https://www.youtube.com/watch?v=QYUJ_ODfc8w)

## What it is

15 dumb things in Fantastic Beasts: The Crimes of Grindelwald

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
