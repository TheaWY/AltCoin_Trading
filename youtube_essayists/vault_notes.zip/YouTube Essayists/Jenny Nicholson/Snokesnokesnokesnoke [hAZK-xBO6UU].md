---
title: "Snokesnokesnokesnoke"
channel: "Jenny Nicholson"
type: "video"
video_id: "hAZK-xBO6UU"
url: "https://www.youtube.com/watch?v=hAZK-xBO6UU"
duration: "00:01:54"
upload_order: 9
about_ko: "스노크 짧은 코미디 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Snokesnokesnokesnoke

채널: [[Jenny Nicholson]] · 길이 00:01:54 · [YouTube](https://www.youtube.com/watch?v=hAZK-xBO6UU)

## 어떤 영상인가

스노크 짧은 코미디 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
