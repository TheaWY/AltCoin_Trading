---
title: "Better Disney Theme Park Movies"
channel: "Jenny Nicholson"
type: "video"
video_id: "-OXylWiZ-9c"
url: "https://www.youtube.com/watch?v=-OXylWiZ-9c"
duration: "00:09:21"
upload_order: 38
about: "Better ideas for movies based on Disney rides"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Better Disney Theme Park Movies

Channel: [[Jenny Nicholson]] · Length 00:09:21 · [YouTube](https://www.youtube.com/watch?v=-OXylWiZ-9c)

## What it is

Better ideas for movies based on Disney rides

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
