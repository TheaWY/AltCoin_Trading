---
title: "Better Disney Theme Park Movies"
channel: "Jenny Nicholson"
type: "video"
video_id: "-OXylWiZ-9c"
url: "https://www.youtube.com/watch?v=-OXylWiZ-9c"
duration: "00:09:21"
upload_order: 38
about_ko: "디즈니 놀이기구 기반 영화의 더 나은 아이디어"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Better Disney Theme Park Movies

채널: [[Jenny Nicholson]] · 길이 00:09:21 · [YouTube](https://www.youtube.com/watch?v=-OXylWiZ-9c)

## 어떤 영상인가

디즈니 놀이기구 기반 영화의 더 나은 아이디어

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
