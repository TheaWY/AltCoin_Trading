---
title: "The Church Play Cinematic Universe"
channel: "Jenny Nicholson"
type: "video"
video_id: "ZK4gM7RC1M0"
url: "https://www.youtube.com/watch?v=ZK4gM7RC1M0"
duration: "01:20:12"
upload_order: 110
about: "Following a \"universe\" of church play videos and picking them apart"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Church Play Cinematic Universe

Channel: [[Jenny Nicholson]] · Length 01:20:12 · [YouTube](https://www.youtube.com/watch?v=ZK4gM7RC1M0)

## What it is

Following a "universe" of church play videos and picking them apart

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
