---
title: "The Church Play Cinematic Universe"
channel: "Jenny Nicholson"
type: "video"
video_id: "ZK4gM7RC1M0"
url: "https://www.youtube.com/watch?v=ZK4gM7RC1M0"
duration: "01:20:12"
upload_order: 110
about_ko: "교회 연극 영상들로 이어지는 '세계관'을 따라가며 웃고 분석하는 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Church Play Cinematic Universe

채널: [[Jenny Nicholson]] · 길이 01:20:12 · [YouTube](https://www.youtube.com/watch?v=ZK4gM7RC1M0)

## 어떤 영상인가

교회 연극 영상들로 이어지는 '세계관'을 따라가며 웃고 분석하는 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
