---
title: "The Last Bronycon: a fandom autopsy"
channel: "Jenny Nicholson"
type: "video"
video_id: "4fVOF2PiHnc"
url: "https://www.youtube.com/watch?v=4fVOF2PiHnc"
duration: "01:11:27"
upload_order: 104
about_ko: "마지막 BronyCon에 직접 가서 브로니 팬덤의 흥망을 돌아보는 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Last Bronycon: a fandom autopsy

채널: [[Jenny Nicholson]] · 길이 01:11:27 · [YouTube](https://www.youtube.com/watch?v=4fVOF2PiHnc)

## 어떤 영상인가

마지막 BronyCon에 직접 가서 브로니 팬덤의 흥망을 돌아보는 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
