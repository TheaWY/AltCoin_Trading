---
title: "The Last Bronycon: a fandom autopsy"
channel: "Jenny Nicholson"
type: "video"
video_id: "4fVOF2PiHnc"
url: "https://www.youtube.com/watch?v=4fVOF2PiHnc"
duration: "01:11:27"
upload_order: 104
about: "She attends the final BronyCon and looks back on the fandom's rise and fall"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Last Bronycon: a fandom autopsy

Channel: [[Jenny Nicholson]] · Length 01:11:27 · [YouTube](https://www.youtube.com/watch?v=4fVOF2PiHnc)

## What it is

She attends the final BronyCon and looks back on the fandom's rise and fall

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
