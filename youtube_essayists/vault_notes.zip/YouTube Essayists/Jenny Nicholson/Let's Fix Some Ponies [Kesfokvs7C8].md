---
title: "Let's Fix Some Ponies"
channel: "Jenny Nicholson"
type: "video"
video_id: "Kesfokvs7C8"
url: "https://www.youtube.com/watch?v=Kesfokvs7C8"
duration: "00:06:50"
upload_order: 12
about_ko: "마이 리틀 포니 캐릭터 고치기"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Let's Fix Some Ponies

채널: [[Jenny Nicholson]] · 길이 00:06:50 · [YouTube](https://www.youtube.com/watch?v=Kesfokvs7C8)

## 어떤 영상인가

마이 리틀 포니 캐릭터 고치기

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
