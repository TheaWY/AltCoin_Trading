---
title: "Let's Fix Some Ponies"
channel: "Jenny Nicholson"
type: "video"
video_id: "Kesfokvs7C8"
url: "https://www.youtube.com/watch?v=Kesfokvs7C8"
duration: "00:06:50"
upload_order: 12
about: "Fixing My Little Pony characters"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Let's Fix Some Ponies

Channel: [[Jenny Nicholson]] · Length 00:06:50 · [YouTube](https://www.youtube.com/watch?v=Kesfokvs7C8)

## What it is

Fixing My Little Pony characters

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
