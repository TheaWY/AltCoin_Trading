---
title: "Rogue 101"
channel: "Jenny Nicholson"
type: "video"
video_id: "YYcdrZfKU3E"
url: "https://www.youtube.com/watch?v=YYcdrZfKU3E"
duration: "00:09:26"
upload_order: 21
about_ko: "로그 원 개봉 전 기초 정리"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Rogue 101

채널: [[Jenny Nicholson]] · 길이 00:09:26 · [YouTube](https://www.youtube.com/watch?v=YYcdrZfKU3E)

## 어떤 영상인가

로그 원 개봉 전 기초 정리

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
