---
title: "Rogue 101"
channel: "Jenny Nicholson"
type: "video"
video_id: "YYcdrZfKU3E"
url: "https://www.youtube.com/watch?v=YYcdrZfKU3E"
duration: "00:09:26"
upload_order: 21
about: "Primer before Rogue One's release"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Rogue 101

Channel: [[Jenny Nicholson]] · Length 00:09:26 · [YouTube](https://www.youtube.com/watch?v=YYcdrZfKU3E)

## What it is

Primer before Rogue One's release

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
