---
title: "Porg.mp4"
channel: "Jenny Nicholson"
type: "video"
video_id: "XTnEhlvb6jI"
url: "https://www.youtube.com/watch?v=XTnEhlvb6jI"
duration: "00:03:55"
upload_order: 45
about: "Short porg video"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Porg.mp4

Channel: [[Jenny Nicholson]] · Length 00:03:55 · [YouTube](https://www.youtube.com/watch?v=XTnEhlvb6jI)

## What it is

Short porg video

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
