---
title: "Porg.mp4"
channel: "Jenny Nicholson"
type: "video"
video_id: "XTnEhlvb6jI"
url: "https://www.youtube.com/watch?v=XTnEhlvb6jI"
duration: "00:03:55"
upload_order: 45
about_ko: "포그 짧은 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Porg.mp4

채널: [[Jenny Nicholson]] · 길이 00:03:55 · [YouTube](https://www.youtube.com/watch?v=XTnEhlvb6jI)

## 어떤 영상인가

포그 짧은 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
