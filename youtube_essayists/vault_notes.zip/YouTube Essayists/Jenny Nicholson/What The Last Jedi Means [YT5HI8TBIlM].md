---
title: "What The Last Jedi Means"
channel: "Jenny Nicholson"
type: "video"
video_id: "YT5HI8TBIlM"
url: "https://www.youtube.com/watch?v=YT5HI8TBIlM"
duration: "00:02:11"
upload_order: 29
about_ko: "'라스트 제다이' 제목의 의미 추측"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# What The Last Jedi Means

채널: [[Jenny Nicholson]] · 길이 00:02:11 · [YouTube](https://www.youtube.com/watch?v=YT5HI8TBIlM)

## 어떤 영상인가

'라스트 제다이' 제목의 의미 추측

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
