---
title: "What The Last Jedi Means"
channel: "Jenny Nicholson"
type: "video"
video_id: "YT5HI8TBIlM"
url: "https://www.youtube.com/watch?v=YT5HI8TBIlM"
duration: "00:02:11"
upload_order: 29
about: "Guessing what the title \"The Last Jedi\" means"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# What The Last Jedi Means

Channel: [[Jenny Nicholson]] · Length 00:02:11 · [YouTube](https://www.youtube.com/watch?v=YT5HI8TBIlM)

## What it is

Guessing what the title "The Last Jedi" means

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
