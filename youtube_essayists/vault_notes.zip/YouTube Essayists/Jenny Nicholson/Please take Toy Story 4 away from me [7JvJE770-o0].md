---
title: "Please take Toy Story 4 away from me"
channel: "Jenny Nicholson"
type: "video"
video_id: "7JvJE770-o0"
url: "https://www.youtube.com/watch?v=7JvJE770-o0"
duration: "00:19:14"
upload_order: 92
about_ko: "토이 스토리 4 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Please take Toy Story 4 away from me

채널: [[Jenny Nicholson]] · 길이 00:19:14 · [YouTube](https://www.youtube.com/watch?v=7JvJE770-o0)

## 어떤 영상인가

토이 스토리 4 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
