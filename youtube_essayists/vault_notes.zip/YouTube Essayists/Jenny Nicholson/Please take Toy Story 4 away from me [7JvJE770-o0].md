---
title: "Please take Toy Story 4 away from me"
channel: "Jenny Nicholson"
type: "video"
video_id: "7JvJE770-o0"
url: "https://www.youtube.com/watch?v=7JvJE770-o0"
duration: "00:19:14"
upload_order: 92
about: "Critique of Toy Story 4"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Please take Toy Story 4 away from me

Channel: [[Jenny Nicholson]] · Length 00:19:14 · [YouTube](https://www.youtube.com/watch?v=7JvJE770-o0)

## What it is

Critique of Toy Story 4

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
