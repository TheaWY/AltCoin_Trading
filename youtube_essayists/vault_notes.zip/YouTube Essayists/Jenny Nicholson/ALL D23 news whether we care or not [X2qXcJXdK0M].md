---
title: "ALL D23 news whether we care or not"
channel: "Jenny Nicholson"
type: "video"
video_id: "X2qXcJXdK0M"
url: "https://www.youtube.com/watch?v=X2qXcJXdK0M"
duration: "00:33:00"
upload_order: 94
about: "Rundown of every announcement from D23"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# ALL D23 news whether we care or not

Channel: [[Jenny Nicholson]] · Length 00:33:00 · [YouTube](https://www.youtube.com/watch?v=X2qXcJXdK0M)

## What it is

Rundown of every announcement from D23

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
