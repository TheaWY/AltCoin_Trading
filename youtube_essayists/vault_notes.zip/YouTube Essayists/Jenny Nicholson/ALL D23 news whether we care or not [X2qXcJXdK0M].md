---
title: "ALL D23 news whether we care or not"
channel: "Jenny Nicholson"
type: "video"
video_id: "X2qXcJXdK0M"
url: "https://www.youtube.com/watch?v=X2qXcJXdK0M"
duration: "00:33:00"
upload_order: 94
about_ko: "D23 행사에서 발표된 디즈니 소식을 전부 훑어보는 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# ALL D23 news whether we care or not

채널: [[Jenny Nicholson]] · 길이 00:33:00 · [YouTube](https://www.youtube.com/watch?v=X2qXcJXdK0M)

## 어떤 영상인가

D23 행사에서 발표된 디즈니 소식을 전부 훑어보는 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
