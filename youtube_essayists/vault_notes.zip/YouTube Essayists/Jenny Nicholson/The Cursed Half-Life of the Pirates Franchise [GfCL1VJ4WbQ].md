---
title: "The Cursed Half-Life of the Pirates Franchise"
channel: "Jenny Nicholson"
type: "video"
video_id: "GfCL1VJ4WbQ"
url: "https://www.youtube.com/watch?v=GfCL1VJ4WbQ"
duration: "00:20:33"
upload_order: 39
about_ko: "캐리비안의 해적 프랜차이즈의 몰락 분석"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Cursed Half-Life of the Pirates Franchise

채널: [[Jenny Nicholson]] · 길이 00:20:33 · [YouTube](https://www.youtube.com/watch?v=GfCL1VJ4WbQ)

## 어떤 영상인가

캐리비안의 해적 프랜차이즈의 몰락 분석

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
