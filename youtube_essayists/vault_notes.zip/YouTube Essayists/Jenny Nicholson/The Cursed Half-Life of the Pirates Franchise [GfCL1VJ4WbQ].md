---
title: "The Cursed Half-Life of the Pirates Franchise"
channel: "Jenny Nicholson"
type: "video"
video_id: "GfCL1VJ4WbQ"
url: "https://www.youtube.com/watch?v=GfCL1VJ4WbQ"
duration: "00:20:33"
upload_order: 39
about: "The decline of the Pirates of the Caribbean franchise"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Cursed Half-Life of the Pirates Franchise

Channel: [[Jenny Nicholson]] · Length 00:20:33 · [YouTube](https://www.youtube.com/watch?v=GfCL1VJ4WbQ)

## What it is

The decline of the Pirates of the Caribbean franchise

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
