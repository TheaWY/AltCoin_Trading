---
title: "I hate The Greatest Showman more every moment"
channel: "Jenny Nicholson"
type: "video"
video_id: "4vHt-yRR_bM"
url: "https://www.youtube.com/watch?v=4vHt-yRR_bM"
duration: "00:32:31"
upload_order: 59
about: "Critique of The Greatest Showman"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# I hate The Greatest Showman more every moment

Channel: [[Jenny Nicholson]] · Length 00:32:31 · [YouTube](https://www.youtube.com/watch?v=4vHt-yRR_bM)

## What it is

Critique of The Greatest Showman

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
