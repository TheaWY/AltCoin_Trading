---
title: "I hate The Greatest Showman more every moment"
channel: "Jenny Nicholson"
type: "video"
video_id: "4vHt-yRR_bM"
url: "https://www.youtube.com/watch?v=4vHt-yRR_bM"
duration: "00:32:31"
upload_order: 59
about_ko: "위대한 쇼맨 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# I hate The Greatest Showman more every moment

채널: [[Jenny Nicholson]] · 길이 00:32:31 · [YouTube](https://www.youtube.com/watch?v=4vHt-yRR_bM)

## 어떤 영상인가

위대한 쇼맨 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
