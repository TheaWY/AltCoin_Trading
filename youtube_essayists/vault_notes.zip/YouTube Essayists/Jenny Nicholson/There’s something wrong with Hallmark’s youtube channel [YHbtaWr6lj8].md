---
title: "There’s something wrong with Hallmark’s youtube channel"
channel: "Jenny Nicholson"
type: "video"
video_id: "YHbtaWr6lj8"
url: "https://www.youtube.com/watch?v=YHbtaWr6lj8"
duration: "00:18:32"
upload_order: 106
about: "Digging into the strange videos on Hallmark's official YouTube channel"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# There’s something wrong with Hallmark’s youtube channel

Channel: [[Jenny Nicholson]] · Length 00:18:32 · [YouTube](https://www.youtube.com/watch?v=YHbtaWr6lj8)

## What it is

Digging into the strange videos on Hallmark's official YouTube channel

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
