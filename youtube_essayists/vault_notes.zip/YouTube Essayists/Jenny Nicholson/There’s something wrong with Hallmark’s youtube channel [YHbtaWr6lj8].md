---
title: "There’s something wrong with Hallmark’s youtube channel"
channel: "Jenny Nicholson"
type: "video"
video_id: "YHbtaWr6lj8"
url: "https://www.youtube.com/watch?v=YHbtaWr6lj8"
duration: "00:18:32"
upload_order: 106
about_ko: "Hallmark 공식 유튜브 채널의 이상한 영상들을 파헤치는 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# There’s something wrong with Hallmark’s youtube channel

채널: [[Jenny Nicholson]] · 길이 00:18:32 · [YouTube](https://www.youtube.com/watch?v=YHbtaWr6lj8)

## 어떤 영상인가

Hallmark 공식 유튜브 채널의 이상한 영상들을 파헤치는 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
