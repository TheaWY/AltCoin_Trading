---
title: "I did it. I found the Worst Book."
channel: "Jenny Nicholson"
type: "video"
video_id: "yZMt87ZdUbw"
url: "https://www.youtube.com/watch?v=yZMt87ZdUbw"
duration: "00:23:19"
upload_order: 46
about_ko: "'최악의 책'을 찾아냈다며 읽고 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# I did it. I found the Worst Book.

채널: [[Jenny Nicholson]] · 길이 00:23:19 · [YouTube](https://www.youtube.com/watch?v=yZMt87ZdUbw)

## 어떤 영상인가

'최악의 책'을 찾아냈다며 읽고 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
