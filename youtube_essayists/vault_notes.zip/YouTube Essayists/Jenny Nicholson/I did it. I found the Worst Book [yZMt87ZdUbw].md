---
title: "I did it. I found the Worst Book."
channel: "Jenny Nicholson"
type: "video"
video_id: "yZMt87ZdUbw"
url: "https://www.youtube.com/watch?v=yZMt87ZdUbw"
duration: "00:23:19"
upload_order: 46
about: "Reading and reviewing what she calls the worst book"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# I did it. I found the Worst Book.

Channel: [[Jenny Nicholson]] · Length 00:23:19 · [YouTube](https://www.youtube.com/watch?v=yZMt87ZdUbw)

## What it is

Reading and reviewing what she calls the worst book

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
