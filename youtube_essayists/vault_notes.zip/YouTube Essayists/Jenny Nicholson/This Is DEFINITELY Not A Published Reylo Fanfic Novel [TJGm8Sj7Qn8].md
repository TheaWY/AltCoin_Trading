---
title: "This Is DEFINITELY Not A Published Reylo Fanfic Novel"
channel: "Jenny Nicholson"
type: "video"
video_id: "TJGm8Sj7Qn8"
url: "https://www.youtube.com/watch?v=TJGm8Sj7Qn8"
duration: "01:43:21"
upload_order: 86
about: "Reading a published romance novel that began as Reylo fanfic"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# This Is DEFINITELY Not A Published Reylo Fanfic Novel

Channel: [[Jenny Nicholson]] · Length 01:43:21 · [YouTube](https://www.youtube.com/watch?v=TJGm8Sj7Qn8)

## What it is

Reading a published romance novel that began as Reylo fanfic

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
