---
title: "This Is DEFINITELY Not A Published Reylo Fanfic Novel"
channel: "Jenny Nicholson"
type: "video"
video_id: "TJGm8Sj7Qn8"
url: "https://www.youtube.com/watch?v=TJGm8Sj7Qn8"
duration: "01:43:21"
upload_order: 86
about_ko: "레이로(Rey/Kylo) 팬픽에서 출발해 출판된 로맨스 소설을 읽고 분석"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# This Is DEFINITELY Not A Published Reylo Fanfic Novel

채널: [[Jenny Nicholson]] · 길이 01:43:21 · [YouTube](https://www.youtube.com/watch?v=TJGm8Sj7Qn8)

## 어떤 영상인가

레이로(Rey/Kylo) 팬픽에서 출발해 출판된 로맨스 소설을 읽고 분석

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
