---
title: "Star Wars: Episode IX Bingo"
channel: "Jenny Nicholson"
type: "video"
video_id: "u7h7y8U4G0g"
url: "https://www.youtube.com/watch?v=u7h7y8U4G0g"
duration: "00:22:25"
upload_order: 93
about_ko: "스타워즈 에피소드 IX 예측 빙고"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Star Wars: Episode IX Bingo

채널: [[Jenny Nicholson]] · 길이 00:22:25 · [YouTube](https://www.youtube.com/watch?v=u7h7y8U4G0g)

## 어떤 영상인가

스타워즈 에피소드 IX 예측 빙고

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
