---
title: "Star Wars: Episode IX Bingo"
channel: "Jenny Nicholson"
type: "video"
video_id: "u7h7y8U4G0g"
url: "https://www.youtube.com/watch?v=u7h7y8U4G0g"
duration: "00:22:25"
upload_order: 93
about: "Prediction bingo for Episode IX"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Star Wars: Episode IX Bingo

Channel: [[Jenny Nicholson]] · Length 00:22:25 · [YouTube](https://www.youtube.com/watch?v=u7h7y8U4G0g)

## What it is

Prediction bingo for Episode IX

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
