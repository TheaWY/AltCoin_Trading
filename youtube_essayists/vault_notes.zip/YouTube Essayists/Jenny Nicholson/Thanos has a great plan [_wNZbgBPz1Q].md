---
title: "Thanos has a great plan"
channel: "Jenny Nicholson"
type: "video"
video_id: "_wNZbgBPz1Q"
url: "https://www.youtube.com/watch?v=_wNZbgBPz1Q"
duration: "00:07:33"
upload_order: 68
about: "Short ironic defense of Thanos's plan"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Thanos has a great plan

Channel: [[Jenny Nicholson]] · Length 00:07:33 · [YouTube](https://www.youtube.com/watch?v=_wNZbgBPz1Q)

## What it is

Short ironic defense of Thanos's plan

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
