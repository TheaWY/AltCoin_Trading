---
title: "Thanos has a great plan"
channel: "Jenny Nicholson"
type: "video"
video_id: "_wNZbgBPz1Q"
url: "https://www.youtube.com/watch?v=_wNZbgBPz1Q"
duration: "00:07:33"
upload_order: 68
about_ko: "타노스의 계획을 반어적으로 옹호하는 짧은 코미디"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Thanos has a great plan

채널: [[Jenny Nicholson]] · 길이 00:07:33 · [YouTube](https://www.youtube.com/watch?v=_wNZbgBPz1Q)

## 어떤 영상인가

타노스의 계획을 반어적으로 옹호하는 짧은 코미디

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
