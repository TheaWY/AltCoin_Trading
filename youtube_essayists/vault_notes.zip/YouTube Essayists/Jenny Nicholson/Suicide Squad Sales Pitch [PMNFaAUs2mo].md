---
title: "Suicide Squad Sales Pitch"
channel: "Jenny Nicholson"
type: "video"
video_id: "PMNFaAUs2mo"
url: "https://www.youtube.com/watch?v=PMNFaAUs2mo"
duration: "00:03:18"
upload_order: 14
about: "Comedy sales pitch for Suicide Squad"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Suicide Squad Sales Pitch

Channel: [[Jenny Nicholson]] · Length 00:03:18 · [YouTube](https://www.youtube.com/watch?v=PMNFaAUs2mo)

## What it is

Comedy sales pitch for Suicide Squad

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
