---
title: "Suicide Squad Sales Pitch"
channel: "Jenny Nicholson"
type: "video"
video_id: "PMNFaAUs2mo"
url: "https://www.youtube.com/watch?v=PMNFaAUs2mo"
duration: "00:03:18"
upload_order: 14
about_ko: "수어사이드 스쿼드를 영업하는 코미디"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Suicide Squad Sales Pitch

채널: [[Jenny Nicholson]] · 길이 00:03:18 · [YouTube](https://www.youtube.com/watch?v=PMNFaAUs2mo)

## 어떤 영상인가

수어사이드 스쿼드를 영업하는 코미디

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
