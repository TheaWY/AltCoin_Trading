---
title: "Let's Write Some Star Wars Books"
channel: "Jenny Nicholson"
type: "video"
video_id: "5IGkxlSDCJM"
url: "https://www.youtube.com/watch?v=5IGkxlSDCJM"
duration: "00:08:52"
upload_order: 37
about_ko: "스타워즈 소설 설정을 직접 지어보는 코미디"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Let's Write Some Star Wars Books

채널: [[Jenny Nicholson]] · 길이 00:08:52 · [YouTube](https://www.youtube.com/watch?v=5IGkxlSDCJM)

## 어떤 영상인가

스타워즈 소설 설정을 직접 지어보는 코미디

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
