---
title: "Let's Write Some Star Wars Books"
channel: "Jenny Nicholson"
type: "video"
video_id: "5IGkxlSDCJM"
url: "https://www.youtube.com/watch?v=5IGkxlSDCJM"
duration: "00:08:52"
upload_order: 37
about: "Comedy: making up Star Wars novel plots"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Let's Write Some Star Wars Books

Channel: [[Jenny Nicholson]] · Length 00:08:52 · [YouTube](https://www.youtube.com/watch?v=5IGkxlSDCJM)

## What it is

Comedy: making up Star Wars novel plots

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
