---
title: "Things you need to know about Pennywise"
channel: "Jenny Nicholson"
type: "video"
video_id: "bp6uJJJMaLs"
url: "https://www.youtube.com/watch?v=bp6uJJJMaLs"
duration: "00:05:29"
upload_order: 44
about_ko: "영화 IT(2017) 페니와이즈에 대한 짧은 정리"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Things you need to know about Pennywise

채널: [[Jenny Nicholson]] · 길이 00:05:29 · [YouTube](https://www.youtube.com/watch?v=bp6uJJJMaLs)

## 어떤 영상인가

영화 IT(2017) 페니와이즈에 대한 짧은 정리

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
