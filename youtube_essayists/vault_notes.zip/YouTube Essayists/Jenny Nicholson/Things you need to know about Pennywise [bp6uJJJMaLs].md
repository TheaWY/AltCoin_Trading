---
title: "Things you need to know about Pennywise"
channel: "Jenny Nicholson"
type: "video"
video_id: "bp6uJJJMaLs"
url: "https://www.youtube.com/watch?v=bp6uJJJMaLs"
duration: "00:05:29"
upload_order: 44
about: "Short primer on Pennywise from IT (2017)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Things you need to know about Pennywise

Channel: [[Jenny Nicholson]] · Length 00:05:29 · [YouTube](https://www.youtube.com/watch?v=bp6uJJJMaLs)

## What it is

Short primer on Pennywise from IT (2017)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
