---
title: "The Biggest Plot Hole in The Last Jedi"
channel: "Jenny Nicholson"
type: "video"
video_id: "mPg__kEZ6YM"
url: "https://www.youtube.com/watch?v=mPg__kEZ6YM"
duration: "00:05:02"
upload_order: 65
about: "Short video on \"the biggest plot hole\" in The Last Jedi"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Biggest Plot Hole in The Last Jedi

Channel: [[Jenny Nicholson]] · Length 00:05:02 · [YouTube](https://www.youtube.com/watch?v=mPg__kEZ6YM)

## What it is

Short video on "the biggest plot hole" in The Last Jedi

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
