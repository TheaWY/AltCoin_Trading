---
title: "The Biggest Plot Hole in The Last Jedi"
channel: "Jenny Nicholson"
type: "video"
video_id: "mPg__kEZ6YM"
url: "https://www.youtube.com/watch?v=mPg__kEZ6YM"
duration: "00:05:02"
upload_order: 65
about_ko: "라스트 제다이의 '가장 큰 플롯 구멍'을 다루는 짧은 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Biggest Plot Hole in The Last Jedi

채널: [[Jenny Nicholson]] · 길이 00:05:02 · [YouTube](https://www.youtube.com/watch?v=mPg__kEZ6YM)

## 어떤 영상인가

라스트 제다이의 '가장 큰 플롯 구멍'을 다루는 짧은 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
