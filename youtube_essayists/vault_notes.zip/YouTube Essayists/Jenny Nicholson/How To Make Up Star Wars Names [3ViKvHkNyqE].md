---
title: "How To Make Up Star Wars Names"
channel: "Jenny Nicholson"
type: "video"
video_id: "3ViKvHkNyqE"
url: "https://www.youtube.com/watch?v=3ViKvHkNyqE"
duration: "00:01:51"
upload_order: 7
about: "How to invent Star Wars-style names"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# How To Make Up Star Wars Names

Channel: [[Jenny Nicholson]] · Length 00:01:51 · [YouTube](https://www.youtube.com/watch?v=3ViKvHkNyqE)

## What it is

How to invent Star Wars-style names

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
