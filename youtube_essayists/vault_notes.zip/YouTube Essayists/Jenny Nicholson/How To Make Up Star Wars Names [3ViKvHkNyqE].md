---
title: "How To Make Up Star Wars Names"
channel: "Jenny Nicholson"
type: "video"
video_id: "3ViKvHkNyqE"
url: "https://www.youtube.com/watch?v=3ViKvHkNyqE"
duration: "00:01:51"
upload_order: 7
about_ko: "스타워즈식 이름 짓는 법"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# How To Make Up Star Wars Names

채널: [[Jenny Nicholson]] · 길이 00:01:51 · [YouTube](https://www.youtube.com/watch?v=3ViKvHkNyqE)

## 어떤 영상인가

스타워즈식 이름 짓는 법

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
