---
title: "Jyn Erso Audition"
channel: "Jenny Nicholson"
type: "video"
video_id: "sych2UPAvg0"
url: "https://www.youtube.com/watch?v=sych2UPAvg0"
duration: "00:01:51"
upload_order: 26
about: "Parody Jyn Erso audition"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Jyn Erso Audition

Channel: [[Jenny Nicholson]] · Length 00:01:51 · [YouTube](https://www.youtube.com/watch?v=sych2UPAvg0)

## What it is

Parody Jyn Erso audition

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
