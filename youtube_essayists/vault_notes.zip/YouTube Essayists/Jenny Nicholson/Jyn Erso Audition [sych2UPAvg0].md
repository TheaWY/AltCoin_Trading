---
title: "Jyn Erso Audition"
channel: "Jenny Nicholson"
type: "video"
video_id: "sych2UPAvg0"
url: "https://www.youtube.com/watch?v=sych2UPAvg0"
duration: "00:01:51"
upload_order: 26
about_ko: "진 어소 오디션 패러디"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Jyn Erso Audition

채널: [[Jenny Nicholson]] · 길이 00:01:51 · [YouTube](https://www.youtube.com/watch?v=sych2UPAvg0)

## 어떤 영상인가

진 어소 오디션 패러디

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
