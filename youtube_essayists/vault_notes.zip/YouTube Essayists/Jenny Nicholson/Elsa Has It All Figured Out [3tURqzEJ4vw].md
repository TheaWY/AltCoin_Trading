---
title: "Elsa Has It All Figured Out"
channel: "Jenny Nicholson"
type: "video"
video_id: "3tURqzEJ4vw"
url: "https://www.youtube.com/watch?v=3tURqzEJ4vw"
duration: "00:04:46"
upload_order: 20
about_ko: "엘사 캐릭터에 대한 짧은 코미디"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Elsa Has It All Figured Out

채널: [[Jenny Nicholson]] · 길이 00:04:46 · [YouTube](https://www.youtube.com/watch?v=3tURqzEJ4vw)

## 어떤 영상인가

엘사 캐릭터에 대한 짧은 코미디

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
