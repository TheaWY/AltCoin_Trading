---
title: "Elsa Has It All Figured Out"
channel: "Jenny Nicholson"
type: "video"
video_id: "3tURqzEJ4vw"
url: "https://www.youtube.com/watch?v=3tURqzEJ4vw"
duration: "00:04:46"
upload_order: 20
about: "Short comedy about Elsa"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Elsa Has It All Figured Out

Channel: [[Jenny Nicholson]] · Length 00:04:46 · [YouTube](https://www.youtube.com/watch?v=3tURqzEJ4vw)

## What it is

Short comedy about Elsa

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
