---
title: "Kylo Rendemption Party"
channel: "Jenny Nicholson"
type: "video"
video_id: "ONTdp_pnWuI"
url: "https://www.youtube.com/watch?v=ONTdp_pnWuI"
duration: "00:12:48"
upload_order: 89
about_ko: "카일로 렌의 구원 서사를 두고 벌이는 코미디 '파티'"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Kylo Rendemption Party

채널: [[Jenny Nicholson]] · 길이 00:12:48 · [YouTube](https://www.youtube.com/watch?v=ONTdp_pnWuI)

## 어떤 영상인가

카일로 렌의 구원 서사를 두고 벌이는 코미디 '파티'

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
