---
title: "Kylo Rendemption Party"
channel: "Jenny Nicholson"
type: "video"
video_id: "ONTdp_pnWuI"
url: "https://www.youtube.com/watch?v=ONTdp_pnWuI"
duration: "00:12:48"
upload_order: 89
about: "Comedy \"party\" about Kylo Ren's redemption arc"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Kylo Rendemption Party

Channel: [[Jenny Nicholson]] · Length 00:12:48 · [YouTube](https://www.youtube.com/watch?v=ONTdp_pnWuI)

## What it is

Comedy "party" about Kylo Ren's redemption arc

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
