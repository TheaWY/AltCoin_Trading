---
title: "Cleaning Horse ASMR"
channel: "Jenny Nicholson"
type: "video"
video_id: "4u87Ia5zxUo"
url: "https://www.youtube.com/watch?v=4u87Ia5zxUo"
duration: "00:05:11"
upload_order: 13
about_ko: "말 손질 ASMR (직접 키우는 말)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Cleaning Horse ASMR

채널: [[Jenny Nicholson]] · 길이 00:05:11 · [YouTube](https://www.youtube.com/watch?v=4u87Ia5zxUo)

## 어떤 영상인가

말 손질 ASMR (직접 키우는 말)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
