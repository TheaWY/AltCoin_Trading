---
title: "Cleaning Horse ASMR"
channel: "Jenny Nicholson"
type: "video"
video_id: "4u87Ia5zxUo"
url: "https://www.youtube.com/watch?v=4u87Ia5zxUo"
duration: "00:05:11"
upload_order: 13
about: "Horse grooming ASMR with her own horse"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Cleaning Horse ASMR

Channel: [[Jenny Nicholson]] · Length 00:05:11 · [YouTube](https://www.youtube.com/watch?v=4u87Ia5zxUo)

## What it is

Horse grooming ASMR with her own horse

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
