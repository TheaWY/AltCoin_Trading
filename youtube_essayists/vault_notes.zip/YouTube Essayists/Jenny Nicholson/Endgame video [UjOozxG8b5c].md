---
title: "Endgame video"
channel: "Jenny Nicholson"
type: "video"
video_id: "UjOozxG8b5c"
url: "https://www.youtube.com/watch?v=UjOozxG8b5c"
duration: "00:22:48"
upload_order: 91
about: "Thoughts on Avengers: Endgame"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Endgame video

Channel: [[Jenny Nicholson]] · Length 00:22:48 · [YouTube](https://www.youtube.com/watch?v=UjOozxG8b5c)

## What it is

Thoughts on Avengers: Endgame

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
