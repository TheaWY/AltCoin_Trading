---
title: "Endgame video"
channel: "Jenny Nicholson"
type: "video"
video_id: "UjOozxG8b5c"
url: "https://www.youtube.com/watch?v=UjOozxG8b5c"
duration: "00:22:48"
upload_order: 91
about_ko: "어벤져스: 엔드게임 감상과 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Endgame video

채널: [[Jenny Nicholson]] · 길이 00:22:48 · [YouTube](https://www.youtube.com/watch?v=UjOozxG8b5c)

## 어떤 영상인가

어벤져스: 엔드게임 감상과 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
