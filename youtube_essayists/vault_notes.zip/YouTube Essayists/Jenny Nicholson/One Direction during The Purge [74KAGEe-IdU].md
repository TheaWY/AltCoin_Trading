---
title: "One Direction during The Purge"
channel: "Jenny Nicholson"
type: "video"
video_id: "74KAGEe-IdU"
url: "https://www.youtube.com/watch?v=74KAGEe-IdU"
duration: "00:35:02"
upload_order: 74
about_ko: "원 디렉션 멤버들이 퍼지(Purge) 상황에 놓인 팬픽 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# One Direction during The Purge

채널: [[Jenny Nicholson]] · 길이 00:35:02 · [YouTube](https://www.youtube.com/watch?v=74KAGEe-IdU)

## 어떤 영상인가

원 디렉션 멤버들이 퍼지(Purge) 상황에 놓인 팬픽 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
