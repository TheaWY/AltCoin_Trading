---
title: "That Last Jedi Teaser"
channel: "Jenny Nicholson"
type: "video"
video_id: "Lkt3SNYMo8I"
url: "https://www.youtube.com/watch?v=Lkt3SNYMo8I"
duration: "00:07:01"
upload_order: 35
about_ko: "라스트 제다이 티저 반응"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# That Last Jedi Teaser

채널: [[Jenny Nicholson]] · 길이 00:07:01 · [YouTube](https://www.youtube.com/watch?v=Lkt3SNYMo8I)

## 어떤 영상인가

라스트 제다이 티저 반응

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
