---
title: "That Last Jedi Teaser"
channel: "Jenny Nicholson"
type: "video"
video_id: "Lkt3SNYMo8I"
url: "https://www.youtube.com/watch?v=Lkt3SNYMo8I"
duration: "00:07:01"
upload_order: 35
about: "Reaction to The Last Jedi teaser"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# That Last Jedi Teaser

Channel: [[Jenny Nicholson]] · Length 00:07:01 · [YouTube](https://www.youtube.com/watch?v=Lkt3SNYMo8I)

## What it is

Reaction to The Last Jedi teaser

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
