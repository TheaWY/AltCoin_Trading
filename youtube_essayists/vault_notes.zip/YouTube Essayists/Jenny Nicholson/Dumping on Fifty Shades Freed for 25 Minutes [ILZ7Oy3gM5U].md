---
title: "Dumping on Fifty Shades Freed for 25 Minutes"
channel: "Jenny Nicholson"
type: "video"
video_id: "ILZ7Oy3gM5U"
url: "https://www.youtube.com/watch?v=ILZ7Oy3gM5U"
duration: "00:25:32"
upload_order: 61
about_ko: "피프티 셰이드 프리드 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Dumping on Fifty Shades Freed for 25 Minutes

채널: [[Jenny Nicholson]] · 길이 00:25:32 · [YouTube](https://www.youtube.com/watch?v=ILZ7Oy3gM5U)

## 어떤 영상인가

피프티 셰이드 프리드 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
