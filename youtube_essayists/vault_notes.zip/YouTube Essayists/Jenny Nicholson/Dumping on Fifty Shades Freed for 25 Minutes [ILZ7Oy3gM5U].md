---
title: "Dumping on Fifty Shades Freed for 25 Minutes"
channel: "Jenny Nicholson"
type: "video"
video_id: "ILZ7Oy3gM5U"
url: "https://www.youtube.com/watch?v=ILZ7Oy3gM5U"
duration: "00:25:32"
upload_order: 61
about: "Critique of Fifty Shades Freed"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Dumping on Fifty Shades Freed for 25 Minutes

Channel: [[Jenny Nicholson]] · Length 00:25:32 · [YouTube](https://www.youtube.com/watch?v=ILZ7Oy3gM5U)

## What it is

Critique of Fifty Shades Freed

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
