---
title: "Fur-Bearing Trout ASMR"
channel: "Jenny Nicholson"
type: "video"
video_id: "BZz-zGwTY4A"
url: "https://www.youtube.com/watch?v=BZz-zGwTY4A"
duration: "00:11:03"
upload_order: 108
about_ko: "'털 난 송어' 박제를 소재로 한 패러디 ASMR"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Fur-Bearing Trout ASMR

채널: [[Jenny Nicholson]] · 길이 00:11:03 · [YouTube](https://www.youtube.com/watch?v=BZz-zGwTY4A)

## 어떤 영상인가

'털 난 송어' 박제를 소재로 한 패러디 ASMR

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
