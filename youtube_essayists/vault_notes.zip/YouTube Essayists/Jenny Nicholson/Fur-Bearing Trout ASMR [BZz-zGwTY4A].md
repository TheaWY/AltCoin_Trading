---
title: "Fur-Bearing Trout ASMR"
channel: "Jenny Nicholson"
type: "video"
video_id: "BZz-zGwTY4A"
url: "https://www.youtube.com/watch?v=BZz-zGwTY4A"
duration: "00:11:03"
upload_order: 108
about: "Parody ASMR built around a taxidermied \"fur-bearing trout\""
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Fur-Bearing Trout ASMR

Channel: [[Jenny Nicholson]] · Length 00:11:03 · [YouTube](https://www.youtube.com/watch?v=BZz-zGwTY4A)

## What it is

Parody ASMR built around a taxidermied "fur-bearing trout"

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
