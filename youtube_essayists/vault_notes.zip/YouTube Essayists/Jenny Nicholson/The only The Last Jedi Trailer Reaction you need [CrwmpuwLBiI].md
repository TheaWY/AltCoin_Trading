---
title: "The only The Last Jedi Trailer Reaction you need"
channel: "Jenny Nicholson"
type: "video"
video_id: "CrwmpuwLBiI"
url: "https://www.youtube.com/watch?v=CrwmpuwLBiI"
duration: "00:07:45"
upload_order: 48
about_ko: "라스트 제다이 트레일러 반응"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The only The Last Jedi Trailer Reaction you need

채널: [[Jenny Nicholson]] · 길이 00:07:45 · [YouTube](https://www.youtube.com/watch?v=CrwmpuwLBiI)

## 어떤 영상인가

라스트 제다이 트레일러 반응

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
