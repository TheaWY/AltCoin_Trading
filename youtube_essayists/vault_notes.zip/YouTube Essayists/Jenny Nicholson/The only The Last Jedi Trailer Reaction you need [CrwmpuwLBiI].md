---
title: "The only The Last Jedi Trailer Reaction you need"
channel: "Jenny Nicholson"
type: "video"
video_id: "CrwmpuwLBiI"
url: "https://www.youtube.com/watch?v=CrwmpuwLBiI"
duration: "00:07:45"
upload_order: 48
about: "Reaction to The Last Jedi trailer"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The only The Last Jedi Trailer Reaction you need

Channel: [[Jenny Nicholson]] · Length 00:07:45 · [YouTube](https://www.youtube.com/watch?v=CrwmpuwLBiI)

## What it is

Reaction to The Last Jedi trailer

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
