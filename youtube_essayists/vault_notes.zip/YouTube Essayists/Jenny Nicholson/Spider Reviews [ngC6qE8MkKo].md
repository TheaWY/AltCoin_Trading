---
title: "Spider Reviews"
channel: "Jenny Nicholson"
type: "video"
video_id: "ngC6qE8MkKo"
url: "https://www.youtube.com/watch?v=ngC6qE8MkKo"
duration: "00:14:20"
upload_order: 97
about_ko: "여러 거미를 '리뷰'하는 코미디 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Spider Reviews

채널: [[Jenny Nicholson]] · 길이 00:14:20 · [YouTube](https://www.youtube.com/watch?v=ngC6qE8MkKo)

## 어떤 영상인가

여러 거미를 '리뷰'하는 코미디 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
