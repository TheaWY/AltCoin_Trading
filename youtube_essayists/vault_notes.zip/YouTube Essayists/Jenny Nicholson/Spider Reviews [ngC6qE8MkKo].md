---
title: "Spider Reviews"
channel: "Jenny Nicholson"
type: "video"
video_id: "ngC6qE8MkKo"
url: "https://www.youtube.com/watch?v=ngC6qE8MkKo"
duration: "00:14:20"
upload_order: 97
about: "Comedy \"reviews\" of various spiders"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Spider Reviews

Channel: [[Jenny Nicholson]] · Length 00:14:20 · [YouTube](https://www.youtube.com/watch?v=ngC6qE8MkKo)

## What it is

Comedy "reviews" of various spiders

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
