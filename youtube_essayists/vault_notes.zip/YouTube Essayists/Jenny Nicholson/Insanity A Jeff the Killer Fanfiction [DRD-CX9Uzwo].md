---
title: "Insanity: A Jeff the Killer Fanfiction"
channel: "Jenny Nicholson"
type: "video"
video_id: "DRD-CX9Uzwo"
url: "https://www.youtube.com/watch?v=DRD-CX9Uzwo"
duration: "00:53:28"
upload_order: 67
about_ko: "제프 더 킬러(Jeff the Killer) 팬픽션을 읽고 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Insanity: A Jeff the Killer Fanfiction

채널: [[Jenny Nicholson]] · 길이 00:53:28 · [YouTube](https://www.youtube.com/watch?v=DRD-CX9Uzwo)

## 어떤 영상인가

제프 더 킬러(Jeff the Killer) 팬픽션을 읽고 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
