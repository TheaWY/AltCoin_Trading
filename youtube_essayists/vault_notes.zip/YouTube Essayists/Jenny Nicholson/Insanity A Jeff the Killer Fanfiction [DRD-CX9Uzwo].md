---
title: "Insanity: A Jeff the Killer Fanfiction"
channel: "Jenny Nicholson"
type: "video"
video_id: "DRD-CX9Uzwo"
url: "https://www.youtube.com/watch?v=DRD-CX9Uzwo"
duration: "00:53:28"
upload_order: 67
about: "Reading and critiquing a Jeff the Killer fanfic"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Insanity: A Jeff the Killer Fanfiction

Channel: [[Jenny Nicholson]] · Length 00:53:28 · [YouTube](https://www.youtube.com/watch?v=DRD-CX9Uzwo)

## What it is

Reading and critiquing a Jeff the Killer fanfic

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
