---
title: "The Dark Side Doesn't Make Sense"
channel: "Jenny Nicholson"
type: "video"
video_id: "qzk78aItaUQ"
url: "https://www.youtube.com/watch?v=qzk78aItaUQ"
duration: "00:11:39"
upload_order: 25
about_ko: "스타워즈 다크 사이드 설정의 모순"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Dark Side Doesn't Make Sense

채널: [[Jenny Nicholson]] · 길이 00:11:39 · [YouTube](https://www.youtube.com/watch?v=qzk78aItaUQ)

## 어떤 영상인가

스타워즈 다크 사이드 설정의 모순

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
