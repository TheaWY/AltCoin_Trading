---
title: "The Dark Side Doesn't Make Sense"
channel: "Jenny Nicholson"
type: "video"
video_id: "qzk78aItaUQ"
url: "https://www.youtube.com/watch?v=qzk78aItaUQ"
duration: "00:11:39"
upload_order: 25
about: "Contradictions in how Star Wars defines the dark side"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Dark Side Doesn't Make Sense

Channel: [[Jenny Nicholson]] · Length 00:11:39 · [YouTube](https://www.youtube.com/watch?v=qzk78aItaUQ)

## What it is

Contradictions in how Star Wars defines the dark side

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
