---
title: "The Problem With Padme"
channel: "Jenny Nicholson"
type: "video"
video_id: "r9-Anpo8AvY"
url: "https://www.youtube.com/watch?v=r9-Anpo8AvY"
duration: "00:05:11"
upload_order: 10
about_ko: "파드메 캐릭터의 문제"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Problem With Padme

채널: [[Jenny Nicholson]] · 길이 00:05:11 · [YouTube](https://www.youtube.com/watch?v=r9-Anpo8AvY)

## 어떤 영상인가

파드메 캐릭터의 문제

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
