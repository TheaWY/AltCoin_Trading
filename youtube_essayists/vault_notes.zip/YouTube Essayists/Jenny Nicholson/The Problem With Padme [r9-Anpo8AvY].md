---
title: "The Problem With Padme"
channel: "Jenny Nicholson"
type: "video"
video_id: "r9-Anpo8AvY"
url: "https://www.youtube.com/watch?v=r9-Anpo8AvY"
duration: "00:05:11"
upload_order: 10
about: "The problem with Padmé"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Problem With Padme

Channel: [[Jenny Nicholson]] · Length 00:05:11 · [YouTube](https://www.youtube.com/watch?v=r9-Anpo8AvY)

## What it is

The problem with Padmé

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
