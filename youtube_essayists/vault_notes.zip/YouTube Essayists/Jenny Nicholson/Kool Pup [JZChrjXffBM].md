---
title: "Kool Pup"
channel: "Jenny Nicholson"
type: "video"
video_id: "JZChrjXffBM"
url: "https://www.youtube.com/watch?v=JZChrjXffBM"
duration: "00:01:03"
upload_order: 2
about_ko: "초기 짧은 개 영상(제목 기준)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Kool Pup

채널: [[Jenny Nicholson]] · 길이 00:01:03 · [YouTube](https://www.youtube.com/watch?v=JZChrjXffBM)

## 어떤 영상인가

초기 짧은 개 영상(제목 기준)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
