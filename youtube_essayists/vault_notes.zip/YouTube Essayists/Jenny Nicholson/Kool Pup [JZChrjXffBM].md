---
title: "Kool Pup"
channel: "Jenny Nicholson"
type: "video"
video_id: "JZChrjXffBM"
url: "https://www.youtube.com/watch?v=JZChrjXffBM"
duration: "00:01:03"
upload_order: 2
about: "Early short dog video (guessed from title)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Kool Pup

Channel: [[Jenny Nicholson]] · Length 00:01:03 · [YouTube](https://www.youtube.com/watch?v=JZChrjXffBM)

## What it is

Early short dog video (guessed from title)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
