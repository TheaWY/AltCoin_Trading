---
title: "A Star Wars Story"
channel: "Jenny Nicholson"
type: "video"
video_id: "b7QzSnDNiNM"
url: "https://www.youtube.com/watch?v=b7QzSnDNiNM"
duration: "00:14:14"
upload_order: 31
about_ko: "스타워즈 스핀오프 '스토리' 영화 관련 짧은 영상(제목 기준)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# A Star Wars Story

채널: [[Jenny Nicholson]] · 길이 00:14:14 · [YouTube](https://www.youtube.com/watch?v=b7QzSnDNiNM)

## 어떤 영상인가

스타워즈 스핀오프 '스토리' 영화 관련 짧은 영상(제목 기준)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
