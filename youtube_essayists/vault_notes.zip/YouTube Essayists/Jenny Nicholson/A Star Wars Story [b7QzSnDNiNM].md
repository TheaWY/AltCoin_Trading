---
title: "A Star Wars Story"
channel: "Jenny Nicholson"
type: "video"
video_id: "b7QzSnDNiNM"
url: "https://www.youtube.com/watch?v=b7QzSnDNiNM"
duration: "00:14:14"
upload_order: 31
about: "Short video on the Star Wars \"Story\" spinoff films (guessed from title)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# A Star Wars Story

Channel: [[Jenny Nicholson]] · Length 00:14:14 · [YouTube](https://www.youtube.com/watch?v=b7QzSnDNiNM)

## What it is

Short video on the Star Wars "Story" spinoff films (guessed from title)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
