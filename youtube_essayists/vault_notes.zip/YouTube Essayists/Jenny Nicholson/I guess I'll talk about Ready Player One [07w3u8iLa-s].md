---
title: "I guess I'll talk about Ready Player One"
channel: "Jenny Nicholson"
type: "video"
video_id: "07w3u8iLa-s"
url: "https://www.youtube.com/watch?v=07w3u8iLa-s"
duration: "00:19:33"
upload_order: 66
about_ko: "레디 플레이어 원 영화 감상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# I guess I'll talk about Ready Player One

채널: [[Jenny Nicholson]] · 길이 00:19:33 · [YouTube](https://www.youtube.com/watch?v=07w3u8iLa-s)

## 어떤 영상인가

레디 플레이어 원 영화 감상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
