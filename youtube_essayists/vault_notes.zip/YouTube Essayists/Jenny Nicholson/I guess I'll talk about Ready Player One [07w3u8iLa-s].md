---
title: "I guess I'll talk about Ready Player One"
channel: "Jenny Nicholson"
type: "video"
video_id: "07w3u8iLa-s"
url: "https://www.youtube.com/watch?v=07w3u8iLa-s"
duration: "00:19:33"
upload_order: 66
about: "Thoughts on the Ready Player One film"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# I guess I'll talk about Ready Player One

Channel: [[Jenny Nicholson]] · Length 00:19:33 · [YouTube](https://www.youtube.com/watch?v=07w3u8iLa-s)

## What it is

Thoughts on the Ready Player One film

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
