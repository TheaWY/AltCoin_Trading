---
title: "BB-Gate"
channel: "Jenny Nicholson"
type: "video"
video_id: "3UNWEEPqLos"
url: "https://www.youtube.com/watch?v=3UNWEEPqLos"
duration: "00:05:12"
upload_order: 15
about: "Short comedy about a BB-8 controversy"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# BB-Gate

Channel: [[Jenny Nicholson]] · Length 00:05:12 · [YouTube](https://www.youtube.com/watch?v=3UNWEEPqLos)

## What it is

Short comedy about a BB-8 controversy

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
