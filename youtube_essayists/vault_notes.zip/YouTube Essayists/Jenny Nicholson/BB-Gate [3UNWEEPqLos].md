---
title: "BB-Gate"
channel: "Jenny Nicholson"
type: "video"
video_id: "3UNWEEPqLos"
url: "https://www.youtube.com/watch?v=3UNWEEPqLos"
duration: "00:05:12"
upload_order: 15
about_ko: "BB-8 관련 논란을 다룬 짧은 코미디"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# BB-Gate

채널: [[Jenny Nicholson]] · 길이 00:05:12 · [YouTube](https://www.youtube.com/watch?v=3UNWEEPqLos)

## 어떤 영상인가

BB-8 관련 논란을 다룬 짧은 코미디

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
