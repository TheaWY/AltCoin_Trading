---
title: "The Last Jedi Sneak Peek Toy Review! *SPOILERS*"
channel: "Jenny Nicholson"
type: "video"
video_id: "p9vg92-jfFc"
url: "https://www.youtube.com/watch?v=p9vg92-jfFc"
duration: "00:06:24"
upload_order: 43
about_ko: "라스트 제다이 장난감 '리뷰' 형식의 코미디"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Last Jedi Sneak Peek Toy Review! *SPOILERS*

채널: [[Jenny Nicholson]] · 길이 00:06:24 · [YouTube](https://www.youtube.com/watch?v=p9vg92-jfFc)

## 어떤 영상인가

라스트 제다이 장난감 '리뷰' 형식의 코미디

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
