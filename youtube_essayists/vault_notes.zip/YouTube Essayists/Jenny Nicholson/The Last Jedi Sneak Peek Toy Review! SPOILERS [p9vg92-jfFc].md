---
title: "The Last Jedi Sneak Peek Toy Review! *SPOILERS*"
channel: "Jenny Nicholson"
type: "video"
video_id: "p9vg92-jfFc"
url: "https://www.youtube.com/watch?v=p9vg92-jfFc"
duration: "00:06:24"
upload_order: 43
about: "Comedy \"toy review\" of The Last Jedi merchandise"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Last Jedi Sneak Peek Toy Review! *SPOILERS*

Channel: [[Jenny Nicholson]] · Length 00:06:24 · [YouTube](https://www.youtube.com/watch?v=p9vg92-jfFc)

## What it is

Comedy "toy review" of The Last Jedi merchandise

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
