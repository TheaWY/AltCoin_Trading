---
title: "The Problem With Split And Finding Dory"
channel: "Jenny Nicholson"
type: "video"
video_id: "8W2xnyyc8qk"
url: "https://www.youtube.com/watch?v=8W2xnyyc8qk"
duration: "00:13:03"
upload_order: 30
about: "How Split and Finding Dory portray disability"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Problem With Split And Finding Dory

Channel: [[Jenny Nicholson]] · Length 00:13:03 · [YouTube](https://www.youtube.com/watch?v=8W2xnyyc8qk)

## What it is

How Split and Finding Dory portray disability

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
