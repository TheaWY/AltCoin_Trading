---
title: "The Problem With Split And Finding Dory"
channel: "Jenny Nicholson"
type: "video"
video_id: "8W2xnyyc8qk"
url: "https://www.youtube.com/watch?v=8W2xnyyc8qk"
duration: "00:13:03"
upload_order: 30
about_ko: "영화 Split과 도리를 찾아서의 장애 묘사 문제"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Problem With Split And Finding Dory

채널: [[Jenny Nicholson]] · 길이 00:13:03 · [YouTube](https://www.youtube.com/watch?v=8W2xnyyc8qk)

## 어떤 영상인가

영화 Split과 도리를 찾아서의 장애 묘사 문제

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
