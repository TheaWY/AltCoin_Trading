---
title: "Is Forces of Destiny good?"
channel: "Jenny Nicholson"
type: "video"
video_id: "H3PKipRZKv0"
url: "https://www.youtube.com/watch?v=H3PKipRZKv0"
duration: "00:31:18"
upload_order: 70
about_ko: "애니메이션 스타워즈: Forces of Destiny 리뷰"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Is Forces of Destiny good?

채널: [[Jenny Nicholson]] · 길이 00:31:18 · [YouTube](https://www.youtube.com/watch?v=H3PKipRZKv0)

## 어떤 영상인가

애니메이션 스타워즈: Forces of Destiny 리뷰

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
