---
title: "Is Forces of Destiny good?"
channel: "Jenny Nicholson"
type: "video"
video_id: "H3PKipRZKv0"
url: "https://www.youtube.com/watch?v=H3PKipRZKv0"
duration: "00:31:18"
upload_order: 70
about: "Review of the animated Star Wars: Forces of Destiny"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Is Forces of Destiny good?

Channel: [[Jenny Nicholson]] · Length 00:31:18 · [YouTube](https://www.youtube.com/watch?v=H3PKipRZKv0)

## What it is

Review of the animated Star Wars: Forces of Destiny

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
