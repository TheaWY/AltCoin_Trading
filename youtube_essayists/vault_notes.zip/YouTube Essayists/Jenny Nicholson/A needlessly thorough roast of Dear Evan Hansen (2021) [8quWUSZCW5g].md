---
title: "A needlessly thorough roast of Dear Evan Hansen (2021)"
channel: "Jenny Nicholson"
type: "video"
video_id: "8quWUSZCW5g"
url: "https://www.youtube.com/watch?v=8quWUSZCW5g"
duration: "01:17:04"
upload_order: 109
about: "Scene-by-scene roast of the 2021 Dear Evan Hansen film"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# A needlessly thorough roast of Dear Evan Hansen (2021)

Channel: [[Jenny Nicholson]] · Length 01:17:04 · [YouTube](https://www.youtube.com/watch?v=8quWUSZCW5g)

## What it is

Scene-by-scene roast of the 2021 Dear Evan Hansen film

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
