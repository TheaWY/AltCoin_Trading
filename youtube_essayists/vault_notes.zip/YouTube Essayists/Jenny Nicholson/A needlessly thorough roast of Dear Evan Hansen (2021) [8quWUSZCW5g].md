---
title: "A needlessly thorough roast of Dear Evan Hansen (2021)"
channel: "Jenny Nicholson"
type: "video"
video_id: "8quWUSZCW5g"
url: "https://www.youtube.com/watch?v=8quWUSZCW5g"
duration: "01:17:04"
upload_order: 109
about_ko: "2021년 영화판 Dear Evan Hansen을 장면 단위로 비평하는 장편 로스트"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# A needlessly thorough roast of Dear Evan Hansen (2021)

채널: [[Jenny Nicholson]] · 길이 01:17:04 · [YouTube](https://www.youtube.com/watch?v=8quWUSZCW5g)

## 어떤 영상인가

2021년 영화판 Dear Evan Hansen을 장면 단위로 비평하는 장편 로스트

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
