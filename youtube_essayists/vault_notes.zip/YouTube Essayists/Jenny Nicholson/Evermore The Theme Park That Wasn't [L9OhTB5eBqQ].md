---
title: "Evermore: The Theme Park That Wasn't"
channel: "Jenny Nicholson"
type: "video"
video_id: "L9OhTB5eBqQ"
url: "https://www.youtube.com/watch?v=L9OhTB5eBqQ"
duration: "03:48:15"
upload_order: 111
about_ko: "유타의 테마파크 Evermore Park의 개장부터 붕괴까지 추적한 다큐형 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Evermore: The Theme Park That Wasn't

채널: [[Jenny Nicholson]] · 길이 03:48:15 · [YouTube](https://www.youtube.com/watch?v=L9OhTB5eBqQ)

## 어떤 영상인가

유타의 테마파크 Evermore Park의 개장부터 붕괴까지 추적한 다큐형 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
