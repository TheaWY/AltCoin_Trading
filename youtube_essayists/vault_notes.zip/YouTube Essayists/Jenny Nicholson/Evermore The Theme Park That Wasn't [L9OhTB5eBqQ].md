---
title: "Evermore: The Theme Park That Wasn't"
channel: "Jenny Nicholson"
type: "video"
video_id: "L9OhTB5eBqQ"
url: "https://www.youtube.com/watch?v=L9OhTB5eBqQ"
duration: "03:48:15"
upload_order: 111
about: "Documentary-style history of Utah's Evermore Park, from opening to collapse"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Evermore: The Theme Park That Wasn't

Channel: [[Jenny Nicholson]] · Length 03:48:15 · [YouTube](https://www.youtube.com/watch?v=L9OhTB5eBqQ)

## What it is

Documentary-style history of Utah's Evermore Park, from opening to collapse

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
