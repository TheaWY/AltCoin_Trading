---
title: "Snoke Isn't Mace Windu Ya Crazies"
channel: "Jenny Nicholson"
type: "video"
video_id: "5hH22wNH5KM"
url: "https://www.youtube.com/watch?v=5hH22wNH5KM"
duration: "00:07:55"
upload_order: 19
about_ko: "스노크가 메이스 윈두라는 팬 이론 반박"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Snoke Isn't Mace Windu Ya Crazies

채널: [[Jenny Nicholson]] · 길이 00:07:55 · [YouTube](https://www.youtube.com/watch?v=5hH22wNH5KM)

## 어떤 영상인가

스노크가 메이스 윈두라는 팬 이론 반박

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
