---
title: "Snoke Isn't Mace Windu Ya Crazies"
channel: "Jenny Nicholson"
type: "video"
video_id: "5hH22wNH5KM"
url: "https://www.youtube.com/watch?v=5hH22wNH5KM"
duration: "00:07:55"
upload_order: 19
about: "Debunking the theory that Snoke is Mace Windu"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Snoke Isn't Mace Windu Ya Crazies

Channel: [[Jenny Nicholson]] · Length 00:07:55 · [YouTube](https://www.youtube.com/watch?v=5hH22wNH5KM)

## What it is

Debunking the theory that Snoke is Mace Windu

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
