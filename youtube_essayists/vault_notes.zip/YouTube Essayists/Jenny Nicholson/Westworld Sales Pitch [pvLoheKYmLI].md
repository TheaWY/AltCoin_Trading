---
title: "Westworld Sales Pitch"
channel: "Jenny Nicholson"
type: "video"
video_id: "pvLoheKYmLI"
url: "https://www.youtube.com/watch?v=pvLoheKYmLI"
duration: "00:04:28"
upload_order: 22
about: "Comedy sales pitch for Westworld"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Westworld Sales Pitch

Channel: [[Jenny Nicholson]] · Length 00:04:28 · [YouTube](https://www.youtube.com/watch?v=pvLoheKYmLI)

## What it is

Comedy sales pitch for Westworld

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
