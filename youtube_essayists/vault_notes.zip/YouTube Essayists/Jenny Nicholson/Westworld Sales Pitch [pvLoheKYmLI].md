---
title: "Westworld Sales Pitch"
channel: "Jenny Nicholson"
type: "video"
video_id: "pvLoheKYmLI"
url: "https://www.youtube.com/watch?v=pvLoheKYmLI"
duration: "00:04:28"
upload_order: 22
about_ko: "웨스트월드를 영업하는 코미디"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Westworld Sales Pitch

채널: [[Jenny Nicholson]] · 길이 00:04:28 · [YouTube](https://www.youtube.com/watch?v=pvLoheKYmLI)

## 어떤 영상인가

웨스트월드를 영업하는 코미디

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
