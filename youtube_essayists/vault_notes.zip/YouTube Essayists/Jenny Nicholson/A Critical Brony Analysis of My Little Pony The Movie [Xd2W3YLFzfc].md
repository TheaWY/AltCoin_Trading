---
title: "A Critical Brony Analysis of My Little Pony: The Movie"
channel: "Jenny Nicholson"
type: "video"
video_id: "Xd2W3YLFzfc"
url: "https://www.youtube.com/watch?v=Xd2W3YLFzfc"
duration: "00:08:04"
upload_order: 47
about_ko: "마이 리틀 포니 극장판을 브로니 관점에서 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# A Critical Brony Analysis of My Little Pony: The Movie

채널: [[Jenny Nicholson]] · 길이 00:08:04 · [YouTube](https://www.youtube.com/watch?v=Xd2W3YLFzfc)

## 어떤 영상인가

마이 리틀 포니 극장판을 브로니 관점에서 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
