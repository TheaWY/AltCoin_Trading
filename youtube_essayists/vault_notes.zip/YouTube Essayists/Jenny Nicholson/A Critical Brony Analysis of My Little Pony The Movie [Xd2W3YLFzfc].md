---
title: "A Critical Brony Analysis of My Little Pony: The Movie"
channel: "Jenny Nicholson"
type: "video"
video_id: "Xd2W3YLFzfc"
url: "https://www.youtube.com/watch?v=Xd2W3YLFzfc"
duration: "00:08:04"
upload_order: 47
about: "My Little Pony: The Movie reviewed from a brony angle"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# A Critical Brony Analysis of My Little Pony: The Movie

Channel: [[Jenny Nicholson]] · Length 00:08:04 · [YouTube](https://www.youtube.com/watch?v=Xd2W3YLFzfc)

## What it is

My Little Pony: The Movie reviewed from a brony angle

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
