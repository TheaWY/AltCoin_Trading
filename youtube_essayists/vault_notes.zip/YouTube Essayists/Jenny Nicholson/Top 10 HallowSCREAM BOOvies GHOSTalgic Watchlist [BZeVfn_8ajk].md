---
title: "Top 10 HallowSCREAM BOOvies GHOSTalgic Watchlist"
channel: "Jenny Nicholson"
type: "video"
video_id: "BZeVfn_8ajk"
url: "https://www.youtube.com/watch?v=BZeVfn_8ajk"
duration: "00:23:17"
upload_order: 80
about_ko: "할로윈 추천 영화 목록 형식을 패러디한 코미디"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Top 10 HallowSCREAM BOOvies GHOSTalgic Watchlist

채널: [[Jenny Nicholson]] · 길이 00:23:17 · [YouTube](https://www.youtube.com/watch?v=BZeVfn_8ajk)

## 어떤 영상인가

할로윈 추천 영화 목록 형식을 패러디한 코미디

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
