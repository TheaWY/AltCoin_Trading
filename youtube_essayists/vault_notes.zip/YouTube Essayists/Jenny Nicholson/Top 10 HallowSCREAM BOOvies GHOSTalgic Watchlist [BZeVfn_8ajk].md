---
title: "Top 10 HallowSCREAM BOOvies GHOSTalgic Watchlist"
channel: "Jenny Nicholson"
type: "video"
video_id: "BZeVfn_8ajk"
url: "https://www.youtube.com/watch?v=BZeVfn_8ajk"
duration: "00:23:17"
upload_order: 80
about: "Comedy parody of Halloween watchlist videos"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Top 10 HallowSCREAM BOOvies GHOSTalgic Watchlist

Channel: [[Jenny Nicholson]] · Length 00:23:17 · [YouTube](https://www.youtube.com/watch?v=BZeVfn_8ajk)

## What it is

Comedy parody of Halloween watchlist videos

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
