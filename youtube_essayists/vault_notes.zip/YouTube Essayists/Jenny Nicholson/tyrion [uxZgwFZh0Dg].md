---
title: "tyrion"
channel: "Jenny Nicholson"
type: "video"
video_id: "uxZgwFZh0Dg"
url: "https://www.youtube.com/watch?v=uxZgwFZh0Dg"
duration: "00:06:24"
upload_order: 90
about: "Short video about Tyrion from Game of Thrones"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# tyrion

Channel: [[Jenny Nicholson]] · Length 00:06:24 · [YouTube](https://www.youtube.com/watch?v=uxZgwFZh0Dg)

## What it is

Short video about Tyrion from Game of Thrones

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
