---
title: "tyrion"
channel: "Jenny Nicholson"
type: "video"
video_id: "uxZgwFZh0Dg"
url: "https://www.youtube.com/watch?v=uxZgwFZh0Dg"
duration: "00:06:24"
upload_order: 90
about_ko: "왕좌의 게임 티리온 캐릭터에 대한 짧은 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# tyrion

채널: [[Jenny Nicholson]] · 길이 00:06:24 · [YouTube](https://www.youtube.com/watch?v=uxZgwFZh0Dg)

## 어떤 영상인가

왕좌의 게임 티리온 캐릭터에 대한 짧은 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
