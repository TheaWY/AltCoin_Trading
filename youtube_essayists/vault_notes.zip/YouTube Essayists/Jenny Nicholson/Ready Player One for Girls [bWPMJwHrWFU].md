---
title: "Ready Player One for Girls"
channel: "Jenny Nicholson"
type: "video"
video_id: "bWPMJwHrWFU"
url: "https://www.youtube.com/watch?v=bWPMJwHrWFU"
duration: "00:05:37"
upload_order: 63
about: "Comedy sketch imagining Ready Player One \"for girls\""
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Ready Player One for Girls

Channel: [[Jenny Nicholson]] · Length 00:05:37 · [YouTube](https://www.youtube.com/watch?v=bWPMJwHrWFU)

## What it is

Comedy sketch imagining Ready Player One "for girls"

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
