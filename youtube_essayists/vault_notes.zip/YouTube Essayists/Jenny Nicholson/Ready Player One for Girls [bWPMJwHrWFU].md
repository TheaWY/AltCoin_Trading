---
title: "Ready Player One for Girls"
channel: "Jenny Nicholson"
type: "video"
video_id: "bWPMJwHrWFU"
url: "https://www.youtube.com/watch?v=bWPMJwHrWFU"
duration: "00:05:37"
upload_order: 63
about_ko: "'여자용' 레디 플레이어 원을 상상하는 코미디"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Ready Player One for Girls

채널: [[Jenny Nicholson]] · 길이 00:05:37 · [YouTube](https://www.youtube.com/watch?v=bWPMJwHrWFU)

## 어떤 영상인가

'여자용' 레디 플레이어 원을 상상하는 코미디

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
