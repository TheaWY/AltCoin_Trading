---
title: "Fantastic Beasts Script Doctor"
channel: "Jenny Nicholson"
type: "video"
video_id: "EMRnG_mtosY"
url: "https://www.youtube.com/watch?v=EMRnG_mtosY"
duration: "00:18:16"
upload_order: 24
about: "Script Doctor: rewriting Fantastic Beasts"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Fantastic Beasts Script Doctor

Channel: [[Jenny Nicholson]] · Length 00:18:16 · [YouTube](https://www.youtube.com/watch?v=EMRnG_mtosY)

## What it is

Script Doctor: rewriting Fantastic Beasts

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
