---
title: "Fantastic Beasts Script Doctor"
channel: "Jenny Nicholson"
type: "video"
video_id: "EMRnG_mtosY"
url: "https://www.youtube.com/watch?v=EMRnG_mtosY"
duration: "00:18:16"
upload_order: 24
about_ko: "신비한 동물사전 각본 고쳐 쓰기"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Fantastic Beasts Script Doctor

채널: [[Jenny Nicholson]] · 길이 00:18:16 · [YouTube](https://www.youtube.com/watch?v=EMRnG_mtosY)

## 어떤 영상인가

신비한 동물사전 각본 고쳐 쓰기

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
