---
title: "Infinity War Hot Take"
channel: "Jenny Nicholson"
type: "video"
video_id: "6BF7IWpaZoU"
url: "https://www.youtube.com/watch?v=6BF7IWpaZoU"
duration: "00:17:03"
upload_order: 69
about_ko: "어벤져스: 인피니티 워 감상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Infinity War Hot Take

채널: [[Jenny Nicholson]] · 길이 00:17:03 · [YouTube](https://www.youtube.com/watch?v=6BF7IWpaZoU)

## 어떤 영상인가

어벤져스: 인피니티 워 감상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
