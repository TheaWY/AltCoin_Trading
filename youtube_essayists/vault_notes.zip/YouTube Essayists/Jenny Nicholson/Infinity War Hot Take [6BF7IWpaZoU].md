---
title: "Infinity War Hot Take"
channel: "Jenny Nicholson"
type: "video"
video_id: "6BF7IWpaZoU"
url: "https://www.youtube.com/watch?v=6BF7IWpaZoU"
duration: "00:17:03"
upload_order: 69
about: "Thoughts on Avengers: Infinity War"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Infinity War Hot Take

Channel: [[Jenny Nicholson]] · Length 00:17:03 · [YouTube](https://www.youtube.com/watch?v=6BF7IWpaZoU)

## What it is

Thoughts on Avengers: Infinity War

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
