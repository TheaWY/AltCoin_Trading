# Jenny Nicholson

113 videos

| # | Video | Length | What it is |
|---|---|---|---|
| 113 | [[My Favorite Twilight Knockoff [-Gq1P2aaDqM]\|My Favorite Twilight Knockoff]] | 01:40:33 | Long review of her favorite Twilight-era YA knockoff |
| 112 | [[The Spectacular Failure of the Star Wars Hotel [T0CpOYZZZW4]\|The Spectacular Failure of the Star Wars Hotel]] | 04:05:39 | Her stay at Disney's Galactic Starcruiser and why it failed. The channel's best-known video |
| 111 | [[Evermore The Theme Park That Wasn't [L9OhTB5eBqQ]\|Evermore: The Theme Park That Wasn't]] | 03:48:15 | Documentary-style history of Utah's Evermore Park, from opening to collapse |
| 110 | [[The Church Play Cinematic Universe [ZK4gM7RC1M0]\|The Church Play Cinematic Universe]] | 01:20:12 | Following a "universe" of church play videos and picking them apart |
| 109 | [[A needlessly thorough roast of Dear Evan Hansen (2021) [8quWUSZCW5g]\|A needlessly thorough roast of Dear Evan Hansen (2021)]] | 01:17:04 | Scene-by-scene roast of the 2021 Dear Evan Hansen film |
| 108 | [[Fur-Bearing Trout ASMR [BZz-zGwTY4A]\|Fur-Bearing Trout ASMR]] | 00:11:03 | Parody ASMR built around a taxidermied "fur-bearing trout" |
| 107 | [[THE Vampire Diaries Video [p4AdFD3E2ok]\|THE Vampire Diaries Video]] | 02:33:19 | Long recap and critique of The Vampire Diaries, all seasons |
| 106 | [[There’s something wrong with Hallmark’s youtube channel [YHbtaWr6lj8]\|There’s something wrong with Hallmark’s youtube channel]] | 00:18:32 | Digging into the strange videos on Hallmark's official YouTube channel |
| 105 | [[SPIDERQUEST Quest for the Man-Sized Spider [-CRXUeTmNtE]\|SPIDERQUEST: Quest for the Man-Sized Spider]] | 00:22:59 | Comedy quest to find a man-sized spider |
| 104 | [[The Last Bronycon a fandom autopsy [4fVOF2PiHnc]\|The Last Bronycon: a fandom autopsy]] | 01:11:27 | She attends the final BronyCon and looks back on the fandom's rise and fall |
| 103 | [[I’m on lockdown so I watched all 14 Land Before Times [B-8zmGr0geQ]\|I’m on lockdown so I watched all 14 Land Before Times]] | 00:58:46 | Watching and reviewing all 14 Land Before Time films during lockdown |
| 102 | [[Well. Let’s read Colin Trevorrow’s Episode IX script [7AGvXqviRys]\|Well. Let’s read Colin Trevorrow’s Episode IX script]] | 01:50:02 | Reading and analyzing Colin Trevorrow's leaked Episode IX script (Duel of the Fates) |
| 101 | [[Oh no! The Rise of Skywalker was real bad ( [GErIPKjwuDg]\|Oh no! The Rise of Skywalker was real bad :(]] | 01:04:47 | Critique of Star Wars: The Rise of Skywalker |
| 100 | [[I read the terrible Episode IX pitch where Rey is a robot [aanyjLmB1Bs]\|I read the terrible Episode IX pitch where Rey is a robot]] | 00:53:47 | Reading a bad fan pitch for Episode IX in which Rey is a robot |
| 99 | [[Going ohhhhh at everything in the new Star Wars ride [6OqoeF9WlX8]\|Going "ohhhhh" at everything in the new Star Wars ride]] | 00:01:54 | Short clip of reacting to everything on the new Star Wars ride |
| 98 | [[Frozen 2 Script Doctor [jwN3Myxrpvw]\|Frozen 2 Script Doctor]] | 00:28:52 | Script Doctor: rewriting Frozen 2 |
| 97 | [[Spider Reviews [ngC6qE8MkKo]\|Spider Reviews]] | 00:14:20 | Comedy "reviews" of various spiders |
| 96 | [[Well, I didn’t like Joker [0tsdOo_wO44]\|Well, I didn’t like Joker]] | 00:33:54 | Why she didn't like Joker (2019) |
| 95 | [[Star Wars Land An Excruciatingly In-Depth Prequel [dYy6V_ZVSU8]\|Star Wars Land: An Excruciatingly In-Depth Prequel]] | 00:42:54 | Deep dive into the plans and lore of Star Wars: Galaxy's Edge before it opened |
| 94 | [[ALL D23 news whether we care or not [X2qXcJXdK0M]\|ALL D23 news whether we care or not]] | 00:33:00 | Rundown of every announcement from D23 |
| 93 | [[Star Wars Episode IX Bingo [u7h7y8U4G0g]\|Star Wars: Episode IX Bingo]] | 00:22:25 | Prediction bingo for Episode IX |
| 92 | [[Please take Toy Story 4 away from me [7JvJE770-o0]\|Please take Toy Story 4 away from me]] | 00:19:14 | Critique of Toy Story 4 |
| 91 | [[Endgame video [UjOozxG8b5c]\|Endgame video]] | 00:22:48 | Thoughts on Avengers: Endgame |
| 90 | [[tyrion [uxZgwFZh0Dg]\|tyrion]] | 00:06:24 | Short video about Tyrion from Game of Thrones |
| 89 | [[Kylo Rendemption Party [ONTdp_pnWuI]\|Kylo Rendemption Party]] | 00:12:48 | Comedy "party" about Kylo Ren's redemption arc |
| 88 | [[DUMBO SLAPS [XwcDlDexAzQ]\|DUMBO SLAPS]] | 00:21:41 | Review of Tim Burton's live-action Dumbo (2019) |
| 87 | [[Original Star Wars Costume Ideas [FXNwk4fHDOo]\|Original Star Wars Costume Ideas]] | 00:07:01 | Her own original Star Wars costume ideas |
| 86 | [[This Is DEFINITELY Not A Published Reylo Fanfic Novel [TJGm8Sj7Qn8]\|This Is DEFINITELY Not A Published Reylo Fanfic Novel]] | 01:43:21 | Reading a published romance novel that began as Reylo fanfic |
| 85 | [[WHERE’S BUZZY The Great Animatronic Caper [Nu5bR_89W7U]\|WHERE’S BUZZY? The Great Animatronic Caper]] | 00:36:52 | Tracking down "Buzzy," an animatronic that vanished from a Disney park |
| 84 | [[Well, I guess SOMEBODY had to read “Trigger Warning” [qMgMr0JcYJ4]\|Well, I guess SOMEBODY had to read “Trigger Warning”]] | 01:28:39 | Long critique of the book "Trigger Warning" |
| 83 | [[The Grim Dystopia of A Christmas Prince [BsHT1fYouYU]\|The Grim Dystopia of A Christmas Prince]] | 00:32:53 | The odd world of Netflix's A Christmas Prince |
| 82 | [[An Excruciatingly Deep Dive into the Avatar Theme Park [xrIxGWterYA]\|An Excruciatingly Deep Dive into the Avatar Theme Park]] | 00:59:01 | Deep dive into Disney's Avatar land (Pandora) |
| 81 | [[15 Very Dumb Things in Fantastic Beasts 2 [QYUJ_ODfc8w]\|15 Very Dumb Things in Fantastic Beasts 2]] | 00:31:03 | 15 dumb things in Fantastic Beasts: The Crimes of Grindelwald |
| 80 | [[Top 10 HallowSCREAM BOOvies GHOSTalgic Watchlist [BZeVfn_8ajk]\|Top 10 HallowSCREAM BOOvies GHOSTalgic Watchlist]] | 00:23:17 | Comedy parody of Halloween watchlist videos |
| 79 | [[The Worst Ghost Hunting Show of All Time [-wG9m-eYNiM]\|The Worst Ghost Hunting Show of All Time]] | 00:31:43 | Review of the worst ghost hunting reality show |
| 78 | [[25 Knights of Ren Theories [pt3ZtY9pIKo]\|25 Knights of Ren Theories]] | 00:07:52 | 25 theories about the Knights of Ren |
| 77 | [[Nobody on the planet remembers Beastly [0cwGwkupmWk]\|Nobody on the planet remembers Beastly]] | 00:46:57 | Review of the forgotten film Beastly (2011) |
| 76 | [[Dark Internet Rituals [nmy4FMwug0Q]\|Dark Internet Rituals]] | 00:34:58 | Trying out or examining "rituals" from internet creepy lore |
| 75 | [[Incredibles 2 (and Brad Bird) and Theme [TDK5U95w9v4]\|Incredibles 2 (and Brad Bird) and Theme]] | 00:11:31 | Incredibles 2 and the themes in Brad Bird's films |
| 74 | [[One Direction during The Purge [74KAGEe-IdU]\|One Direction during The Purge]] | 00:35:02 | Reading a fanfic that puts One Direction in The Purge |
| 73 | [[Should we let Jurassic World 2 get melted by this volcano [PRwI1unON7A]\|Should we let Jurassic World 2 get melted by this volcano?]] | 00:30:53 | Review of Jurassic World: Fallen Kingdom |
| 72 | [[Rating. Every. Porg [1yw6z9G7p1g]\|Rating. Every. Porg.]] | 00:08:09 | Rating porgs one by one |
| 71 | [[Solo Bad [XP8FZ4cBzaI]\|Solo Bad]] | 00:49:55 | Critique of Solo: A Star Wars Story |
| 70 | [[Is Forces of Destiny good [H3PKipRZKv0]\|Is Forces of Destiny good?]] | 00:31:18 | Review of the animated Star Wars: Forces of Destiny |
| 69 | [[Infinity War Hot Take [6BF7IWpaZoU]\|Infinity War Hot Take]] | 00:17:03 | Thoughts on Avengers: Infinity War |
| 68 | [[Thanos has a great plan [_wNZbgBPz1Q]\|Thanos has a great plan]] | 00:07:33 | Short ironic defense of Thanos's plan |
| 67 | [[Insanity A Jeff the Killer Fanfiction [DRD-CX9Uzwo]\|Insanity: A Jeff the Killer Fanfiction]] | 00:53:28 | Reading and critiquing a Jeff the Killer fanfic |
| 66 | [[I guess I'll talk about Ready Player One [07w3u8iLa-s]\|I guess I'll talk about Ready Player One]] | 00:19:33 | Thoughts on the Ready Player One film |
| 65 | [[The Biggest Plot Hole in The Last Jedi [mPg__kEZ6YM]\|The Biggest Plot Hole in The Last Jedi]] | 00:05:02 | Short video on "the biggest plot hole" in The Last Jedi |
| 64 | [[Top 10 Lame Things To Do At Disney World [-KeFvjm_hcA]\|Top 10 Lame Things To Do At Disney World]] | 00:12:00 | Parody top 10 of lame things to do at Disney World |
| 63 | [[Ready Player One for Girls [bWPMJwHrWFU]\|Ready Player One for Girls]] | 00:05:37 | Comedy sketch imagining Ready Player One "for girls" |
| 62 | [[Escape from Tomorrow is a dumb exercise in misery [38BiNsFFzcs]\|Escape from Tomorrow is a dumb exercise in misery]] | 00:47:34 | Critique of Escape from Tomorrow, shot guerrilla-style at Disney World |
| 61 | [[Dumping on Fifty Shades Freed for 25 Minutes [ILZ7Oy3gM5U]\|Dumping on Fifty Shades Freed for 25 Minutes]] | 00:25:32 | Critique of Fifty Shades Freed |
| 60 | [[The Worst Reality Show of All Time [JKFgn6tNU6w]\|The Worst Reality Show of All Time]] | 00:25:43 | Review of the worst reality show |
| 59 | [[I hate The Greatest Showman more every moment [4vHt-yRR_bM]\|I hate The Greatest Showman more every moment]] | 00:32:31 | Critique of The Greatest Showman |
| 58 | [[Top 10 Worst Reasons You Hated The Last Jedi [JpoUN_A12Eg]\|Top 10 Worst Reasons You Hated The Last Jedi]] | 00:22:57 | Top 10 worst reasons people hated The Last Jedi |
| 57 | [[The Applejack Problem [S4vKQbpOn5k]\|The Applejack Problem]] | 00:19:06 | The writing problem with Applejack in My Little Pony |
| 56 | [[The Last Jedi SPOILER PARTY Don't Watch [X9QiHlEC22U]\|The Last Jedi SPOILER PARTY Don't Watch]] | 00:18:11 | The Last Jedi spoiler discussion |
| 55 | [[I saw that new star wars [6P6Ia5Qj9W0]\|I saw that new star wars]] | 00:02:40 | Short reaction right after seeing The Last Jedi |
| 54 | [[Trapped In A Island With Josh Hutcherson [OVa-sqcDYZ4]\|Trapped In A Island With Josh Hutcherson]] | 00:26:54 | Reading a fanfic about being stranded on an island with Josh Hutcherson |
| 53 | [[Justice League Bad [vFK7oWLWapc]\|Justice League Bad]] | 00:12:37 | Critique of Justice League (2017) |
| 52 | [[I played Battlefront II and [YTDa55gBk_E]\|I played Battlefront II and]] | 00:08:44 | Thoughts after playing Star Wars Battlefront II (2017) |
| 51 | [[The Last Jedi Bingo [I-5CODzeGEE]\|The Last Jedi Bingo]] | 00:12:20 | Prediction bingo for The Last Jedi |
| 50 | [[The Halloween Costumes Nobody Wanted [K9JttJ_B0PQ]\|The Halloween Costumes Nobody Wanted]] | 00:18:38 | Halloween costumes nobody wanted |
| 49 | [[Let's do real magic [Zv0v0VCVgJ4]\|Let's do real magic]] | 00:23:59 | Comedy video attempting "real magic" |
| 48 | [[The only The Last Jedi Trailer Reaction you need [CrwmpuwLBiI]\|The only The Last Jedi Trailer Reaction you need]] | 00:07:45 | Reaction to The Last Jedi trailer |
| 47 | [[A Critical Brony Analysis of My Little Pony The Movie [Xd2W3YLFzfc]\|A Critical Brony Analysis of My Little Pony: The Movie]] | 00:08:04 | My Little Pony: The Movie reviewed from a brony angle |
| 46 | [[I did it. I found the Worst Book [yZMt87ZdUbw]\|I did it. I found the Worst Book.]] | 00:23:19 | Reading and reviewing what she calls the worst book |
| 45 | [[Porg.mp4 [XTnEhlvb6jI]\|Porg.mp4]] | 00:03:55 | Short porg video |
| 44 | [[Things you need to know about Pennywise [bp6uJJJMaLs]\|Things you need to know about Pennywise]] | 00:05:29 | Short primer on Pennywise from IT (2017) |
| 43 | [[The Last Jedi Sneak Peek Toy Review! SPOILERS [p9vg92-jfFc]\|The Last Jedi Sneak Peek Toy Review! *SPOILERS*]] | 00:06:24 | Comedy "toy review" of The Last Jedi merchandise |
| 42 | [[But what if Peter hadn't been Spiderman [mcLtyRLpr8k]\|But what if Peter hadn't been Spiderman]] | 00:03:13 | Short what-if about Peter Parker not being Spider-Man |
| 41 | [[Why Does Creepypasta Suck [KAN_IPwK1K8]\|Why Does Creepypasta Suck]] | 00:15:20 | Why creepypasta is bad |
| 40 | [[Spiderman Homecoming is basically Hey Arnold [DC_AqezinXM]\|Spiderman Homecoming is basically Hey Arnold]] | 00:08:39 | Arguing Spider-Man: Homecoming is basically Hey Arnold |
| 39 | [[The Cursed Half-Life of the Pirates Franchise [GfCL1VJ4WbQ]\|The Cursed Half-Life of the Pirates Franchise]] | 00:20:33 | The decline of the Pirates of the Caribbean franchise |
| 38 | [[Better Disney Theme Park Movies [-OXylWiZ-9c]\|Better Disney Theme Park Movies]] | 00:09:21 | Better ideas for movies based on Disney rides |
| 37 | [[Let's Write Some Star Wars Books [5IGkxlSDCJM]\|Let's Write Some Star Wars Books]] | 00:08:52 | Comedy: making up Star Wars novel plots |
| 36 | [[Beauty and the Beast 2017 Compliment Sandwich [18AquBLpXh8]\|Beauty and the Beast 2017 Compliment Sandwich]] | 00:16:04 | Compliment-sandwich critique of live-action Beauty and the Beast (2017) |
| 35 | [[That Last Jedi Teaser [Lkt3SNYMo8I]\|That Last Jedi Teaser]] | 00:07:01 | Reaction to The Last Jedi teaser |
| 34 | [[Top 10 Reasons I Won't Do ASMR ASMR [3QcjAmnDTos]\|Top 10 Reasons I Won't Do ASMR ASMR]] | 00:07:39 | ASMR parody about why she won't do ASMR |
| 33 | [[Unfortunate Implications - Beauty and the Beast [gGRmTmA6znk]\|Unfortunate Implications - Beauty and the Beast]] | 00:08:34 | Unfortunate implications in Beauty and the Beast |
| 32 | [[Fifty Shades Darker Script Doctor [gzVNYdmS8s8]\|Fifty Shades Darker Script Doctor]] | 00:20:14 | Script Doctor: rewriting Fifty Shades Darker |
| 31 | [[A Star Wars Story [b7QzSnDNiNM]\|A Star Wars Story]] | 00:14:14 | Short video on the Star Wars "Story" spinoff films (guessed from title) |
| 30 | [[The Problem With Split And Finding Dory [8W2xnyyc8qk]\|The Problem With Split And Finding Dory]] | 00:13:03 | How Split and Finding Dory portray disability |
| 29 | [[What The Last Jedi Means [YT5HI8TBIlM]\|What The Last Jedi Means]] | 00:02:11 | Guessing what the title "The Last Jedi" means |
| 28 | [[Tomorrowland Ruined My Life And Dreams [C1-74z9dFYs]\|Tomorrowland Ruined My Life And Dreams]] | 00:21:11 | Critique of Disney's Tomorrowland |
| 27 | [[Top 10 Worst Reasons You Liked Rogue One [P3gf6qyAHOw]\|Top 10 Worst Reasons You Liked Rogue One]] | 00:24:14 | Top 10 worst reasons people liked Rogue One |
| 26 | [[Jyn Erso Audition [sych2UPAvg0]\|Jyn Erso Audition]] | 00:01:51 | Parody Jyn Erso audition |
| 25 | [[The Dark Side Doesn't Make Sense [qzk78aItaUQ]\|The Dark Side Doesn't Make Sense]] | 00:11:39 | Contradictions in how Star Wars defines the dark side |
| 24 | [[Fantastic Beasts Script Doctor [EMRnG_mtosY]\|Fantastic Beasts Script Doctor]] | 00:18:16 | Script Doctor: rewriting Fantastic Beasts |
| 23 | [[Doctor Strange Looks Familiar [IBRUtdzTf8U]\|Doctor Strange Looks Familiar]] | 00:06:48 | Why Doctor Strange feels familiar (the Marvel formula) |
| 22 | [[Westworld Sales Pitch [pvLoheKYmLI]\|Westworld Sales Pitch]] | 00:04:28 | Comedy sales pitch for Westworld |
| 21 | [[Rogue 101 [YYcdrZfKU3E]\|Rogue 101]] | 00:09:26 | Primer before Rogue One's release |
| 20 | [[Elsa Has It All Figured Out [3tURqzEJ4vw]\|Elsa Has It All Figured Out]] | 00:04:46 | Short comedy about Elsa |
| 19 | [[Snoke Isn't Mace Windu Ya Crazies [5hH22wNH5KM]\|Snoke Isn't Mace Windu Ya Crazies]] | 00:07:55 | Debunking the theory that Snoke is Mace Windu |
| 18 | [[Batman V Superman Script Doctor [AwRwiuSG_6w]\|Batman V Superman Script Doctor]] | 00:08:09 | Script Doctor: rewriting Batman v Superman |
| 17 | [[5 Dumbest Episode VIII Theories [Pu-dTtt0BGk]\|5 Dumbest Episode VIII Theories]] | 00:08:12 | The 5 dumbest Episode VIII fan theories |
| 16 | [[If Rey is a Skywalker [mjHEHuNyvME]\|If Rey is a Skywalker]] | 00:04:45 | Short take on what it would mean if Rey were a Skywalker |
| 15 | [[BB-Gate [3UNWEEPqLos]\|BB-Gate]] | 00:05:12 | Short comedy about a BB-8 controversy |
| 14 | [[Suicide Squad Sales Pitch [PMNFaAUs2mo]\|Suicide Squad Sales Pitch]] | 00:03:18 | Comedy sales pitch for Suicide Squad |
| 13 | [[Cleaning Horse ASMR [4u87Ia5zxUo]\|Cleaning Horse ASMR]] | 00:05:11 | Horse grooming ASMR with her own horse |
| 12 | [[Let's Fix Some Ponies [Kesfokvs7C8]\|Let's Fix Some Ponies]] | 00:06:50 | Fixing My Little Pony characters |
| 11 | [[My Episode VIII Wishlist [zFFjaKAdHMk]\|My Episode VIII Wishlist]] | 00:05:47 | Her wishlist for Episode VIII |
| 10 | [[The Problem With Padme [r9-Anpo8AvY]\|The Problem With Padme]] | 00:05:11 | The problem with Padmé |
| 9 | [[Snokesnokesnokesnoke [hAZK-xBO6UU]\|Snokesnokesnokesnoke]] | 00:01:54 | Short Snoke comedy clip |
| 8 | [[Nobody Loves BB-8 Like I Love BB-8 [jfEcVC90Arg]\|Nobody Loves BB-8 Like I Love BB-8]] | 00:01:37 | Short video about loving BB-8 |
| 7 | [[How To Make Up Star Wars Names [3ViKvHkNyqE]\|How To Make Up Star Wars Names]] | 00:01:51 | How to invent Star Wars-style names |
| 6 | [[Anakin vs Obi-Wan (cover) [G0JxmyTwY7s]\|Anakin vs Obi-Wan (cover)]] | 00:01:58 | Music cover of Anakin vs Obi-Wan from Episode III |
| 5 | [[Harry Potter  See You Again [5J5I-_wAe5Y]\|Harry Potter // See You Again]] | 00:02:17 | Harry Potter fan video set to See You Again |
| 4 | [[The Adventures of Darging Do [3bWR-WkwOBo]\|The Adventures of Darging Do]] | 00:00:17 | Very short early video about Daring Do |
| 3 | [[Episode III - The Final Battle (cover) [Is3Sl3RR8kM]\|Episode III - "The Final Battle" (cover)]] | 00:01:22 | Music cover of "The Final Battle" from Episode III |
| 2 | [[Kool Pup [JZChrjXffBM]\|Kool Pup]] | 00:01:03 | Early short dog video (guessed from title) |
| 1 | [[Voldemort Isn't Funny [wGj-AWQVBPk]\|Voldemort Isn't Funny]] | 00:01:00 | Early short comedy arguing Voldemort isn't funny |
