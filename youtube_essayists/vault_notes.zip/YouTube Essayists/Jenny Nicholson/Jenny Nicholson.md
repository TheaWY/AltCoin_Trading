# Jenny Nicholson

영상 113개

| # | 영상 | 길이 | 어떤 영상인가 |
|---|---|---|---|
| 113 | [[My Favorite Twilight Knockoff [-Gq1P2aaDqM]\|My Favorite Twilight Knockoff]] | 01:40:33 | 트와일라잇 아류 YA 소설/영화들 중 가장 좋아하는 작품을 파고드는 장편 리뷰 |
| 112 | [[The Spectacular Failure of the Star Wars Hotel [T0CpOYZZZW4]\|The Spectacular Failure of the Star Wars Hotel]] | 04:05:39 | 디즈니 스타워즈 호텔(Galactic Starcruiser)에 직접 묵어본 체험기이자 그 실패 원인 분석. 채널 대표작 |
| 111 | [[Evermore The Theme Park That Wasn't [L9OhTB5eBqQ]\|Evermore: The Theme Park That Wasn't]] | 03:48:15 | 유타의 테마파크 Evermore Park의 개장부터 붕괴까지 추적한 다큐형 영상 |
| 110 | [[The Church Play Cinematic Universe [ZK4gM7RC1M0]\|The Church Play Cinematic Universe]] | 01:20:12 | 교회 연극 영상들로 이어지는 '세계관'을 따라가며 웃고 분석하는 영상 |
| 109 | [[A needlessly thorough roast of Dear Evan Hansen (2021) [8quWUSZCW5g]\|A needlessly thorough roast of Dear Evan Hansen (2021)]] | 01:17:04 | 2021년 영화판 Dear Evan Hansen을 장면 단위로 비평하는 장편 로스트 |
| 108 | [[Fur-Bearing Trout ASMR [BZz-zGwTY4A]\|Fur-Bearing Trout ASMR]] | 00:11:03 | '털 난 송어' 박제를 소재로 한 패러디 ASMR |
| 107 | [[THE Vampire Diaries Video [p4AdFD3E2ok]\|THE Vampire Diaries Video]] | 02:33:19 | 드라마 The Vampire Diaries 전 시즌을 정리하고 비평하는 장편 |
| 106 | [[There’s something wrong with Hallmark’s youtube channel [YHbtaWr6lj8]\|There’s something wrong with Hallmark’s youtube channel]] | 00:18:32 | Hallmark 공식 유튜브 채널의 이상한 영상들을 파헤치는 영상 |
| 105 | [[SPIDERQUEST Quest for the Man-Sized Spider [-CRXUeTmNtE]\|SPIDERQUEST: Quest for the Man-Sized Spider]] | 00:22:59 | 사람 크기만 한 거미를 찾아 나서는 코미디 탐사 영상 |
| 104 | [[The Last Bronycon a fandom autopsy [4fVOF2PiHnc]\|The Last Bronycon: a fandom autopsy]] | 01:11:27 | 마지막 BronyCon에 직접 가서 브로니 팬덤의 흥망을 돌아보는 영상 |
| 103 | [[I’m on lockdown so I watched all 14 Land Before Times [B-8zmGr0geQ]\|I’m on lockdown so I watched all 14 Land Before Times]] | 00:58:46 | 코로나 봉쇄 중 Land Before Time 시리즈 14편을 전부 보고 리뷰 |
| 102 | [[Well. Let’s read Colin Trevorrow’s Episode IX script [7AGvXqviRys]\|Well. Let’s read Colin Trevorrow’s Episode IX script]] | 01:50:02 | 유출된 콜린 트레버로우의 스타워즈 에피소드 IX 각본(Duel of the Fates)을 읽고 분석 |
| 101 | [[Oh no! The Rise of Skywalker was real bad ( [GErIPKjwuDg]\|Oh no! The Rise of Skywalker was real bad :(]] | 01:04:47 | 스타워즈: 라이즈 오브 스카이워커 비평 |
| 100 | [[I read the terrible Episode IX pitch where Rey is a robot [aanyjLmB1Bs]\|I read the terrible Episode IX pitch where Rey is a robot]] | 00:53:47 | 레이가 로봇이라는 설정의 엉터리 에피소드 IX 팬 피치를 읽는 영상 |
| 99 | [[Going ohhhhh at everything in the new Star Wars ride [6OqoeF9WlX8]\|Going "ohhhhh" at everything in the new Star Wars ride]] | 00:01:54 | 새 스타워즈 놀이기구에서 모든 것에 감탄하는 짧은 영상 |
| 98 | [[Frozen 2 Script Doctor [jwN3Myxrpvw]\|Frozen 2 Script Doctor]] | 00:28:52 | 겨울왕국 2 각본을 고쳐 쓰는 Script Doctor 시리즈 |
| 97 | [[Spider Reviews [ngC6qE8MkKo]\|Spider Reviews]] | 00:14:20 | 여러 거미를 '리뷰'하는 코미디 영상 |
| 96 | [[Well, I didn’t like Joker [0tsdOo_wO44]\|Well, I didn’t like Joker]] | 00:33:54 | 영화 조커(2019)를 왜 싫어했는지 설명하는 리뷰 |
| 95 | [[Star Wars Land An Excruciatingly In-Depth Prequel [dYy6V_ZVSU8]\|Star Wars Land: An Excruciatingly In-Depth Prequel]] | 00:42:54 | 디즈니 스타워즈 랜드(Galaxy's Edge) 개장 전 설정과 계획을 깊게 파고드는 영상 |
| 94 | [[ALL D23 news whether we care or not [X2qXcJXdK0M]\|ALL D23 news whether we care or not]] | 00:33:00 | D23 행사에서 발표된 디즈니 소식을 전부 훑어보는 영상 |
| 93 | [[Star Wars Episode IX Bingo [u7h7y8U4G0g]\|Star Wars: Episode IX Bingo]] | 00:22:25 | 스타워즈 에피소드 IX 예측 빙고 |
| 92 | [[Please take Toy Story 4 away from me [7JvJE770-o0]\|Please take Toy Story 4 away from me]] | 00:19:14 | 토이 스토리 4 비평 |
| 91 | [[Endgame video [UjOozxG8b5c]\|Endgame video]] | 00:22:48 | 어벤져스: 엔드게임 감상과 비평 |
| 90 | [[tyrion [uxZgwFZh0Dg]\|tyrion]] | 00:06:24 | 왕좌의 게임 티리온 캐릭터에 대한 짧은 영상 |
| 89 | [[Kylo Rendemption Party [ONTdp_pnWuI]\|Kylo Rendemption Party]] | 00:12:48 | 카일로 렌의 구원 서사를 두고 벌이는 코미디 '파티' |
| 88 | [[DUMBO SLAPS [XwcDlDexAzQ]\|DUMBO SLAPS]] | 00:21:41 | 팀 버튼 실사판 덤보(2019) 리뷰 |
| 87 | [[Original Star Wars Costume Ideas [FXNwk4fHDOo]\|Original Star Wars Costume Ideas]] | 00:07:01 | 직접 만든 오리지널 스타워즈 코스튬 아이디어 소개 |
| 86 | [[This Is DEFINITELY Not A Published Reylo Fanfic Novel [TJGm8Sj7Qn8]\|This Is DEFINITELY Not A Published Reylo Fanfic Novel]] | 01:43:21 | 레이로(Rey/Kylo) 팬픽에서 출발해 출판된 로맨스 소설을 읽고 분석 |
| 85 | [[WHERE’S BUZZY The Great Animatronic Caper [Nu5bR_89W7U]\|WHERE’S BUZZY? The Great Animatronic Caper]] | 00:36:52 | 디즈니 파크에서 사라진 애니매트로닉스 'Buzzy'의 행방을 추적 |
| 84 | [[Well, I guess SOMEBODY had to read “Trigger Warning” [qMgMr0JcYJ4]\|Well, I guess SOMEBODY had to read “Trigger Warning”]] | 01:28:39 | 문제적 책 'Trigger Warning'을 읽고 비평하는 장편 |
| 83 | [[The Grim Dystopia of A Christmas Prince [BsHT1fYouYU]\|The Grim Dystopia of A Christmas Prince]] | 00:32:53 | 넷플릭스 영화 A Christmas Prince의 이상한 세계관 비평 |
| 82 | [[An Excruciatingly Deep Dive into the Avatar Theme Park [xrIxGWterYA]\|An Excruciatingly Deep Dive into the Avatar Theme Park]] | 00:59:01 | 디즈니 아바타 테마파크(Pandora)를 깊게 분석 |
| 81 | [[15 Very Dumb Things in Fantastic Beasts 2 [QYUJ_ODfc8w]\|15 Very Dumb Things in Fantastic Beasts 2]] | 00:31:03 | 신비한 동물들과 그린델왈드의 범죄 속 어이없는 지점 15가지 |
| 80 | [[Top 10 HallowSCREAM BOOvies GHOSTalgic Watchlist [BZeVfn_8ajk]\|Top 10 HallowSCREAM BOOvies GHOSTalgic Watchlist]] | 00:23:17 | 할로윈 추천 영화 목록 형식을 패러디한 코미디 |
| 79 | [[The Worst Ghost Hunting Show of All Time [-wG9m-eYNiM]\|The Worst Ghost Hunting Show of All Time]] | 00:31:43 | 역대 최악의 유령 사냥 리얼리티 쇼 리뷰 |
| 78 | [[25 Knights of Ren Theories [pt3ZtY9pIKo]\|25 Knights of Ren Theories]] | 00:07:52 | 스타워즈 '렌 기사단' 정체에 대한 25가지 이론 |
| 77 | [[Nobody on the planet remembers Beastly [0cwGwkupmWk]\|Nobody on the planet remembers Beastly]] | 00:46:57 | 아무도 기억하지 못하는 영화 Beastly(2011) 리뷰 |
| 76 | [[Dark Internet Rituals [nmy4FMwug0Q]\|Dark Internet Rituals]] | 00:34:58 | 인터넷 괴담 속 '의식'들을 직접 해보거나 살펴보는 영상 |
| 75 | [[Incredibles 2 (and Brad Bird) and Theme [TDK5U95w9v4]\|Incredibles 2 (and Brad Bird) and Theme]] | 00:11:31 | 인크레더블 2와 브래드 버드 영화의 주제 의식 |
| 74 | [[One Direction during The Purge [74KAGEe-IdU]\|One Direction during The Purge]] | 00:35:02 | 원 디렉션 멤버들이 퍼지(Purge) 상황에 놓인 팬픽 리뷰 |
| 73 | [[Should we let Jurassic World 2 get melted by this volcano [PRwI1unON7A]\|Should we let Jurassic World 2 get melted by this volcano?]] | 00:30:53 | 쥬라기 월드: 폴른 킹덤 리뷰 |
| 72 | [[Rating. Every. Porg [1yw6z9G7p1g]\|Rating. Every. Porg.]] | 00:08:09 | 스타워즈 포그 굿즈/장면을 하나씩 평가 |
| 71 | [[Solo Bad [XP8FZ4cBzaI]\|Solo Bad]] | 00:49:55 | 한 솔로: 스타워즈 스토리 비평 |
| 70 | [[Is Forces of Destiny good [H3PKipRZKv0]\|Is Forces of Destiny good?]] | 00:31:18 | 애니메이션 스타워즈: Forces of Destiny 리뷰 |
| 69 | [[Infinity War Hot Take [6BF7IWpaZoU]\|Infinity War Hot Take]] | 00:17:03 | 어벤져스: 인피니티 워 감상 |
| 68 | [[Thanos has a great plan [_wNZbgBPz1Q]\|Thanos has a great plan]] | 00:07:33 | 타노스의 계획을 반어적으로 옹호하는 짧은 코미디 |
| 67 | [[Insanity A Jeff the Killer Fanfiction [DRD-CX9Uzwo]\|Insanity: A Jeff the Killer Fanfiction]] | 00:53:28 | 제프 더 킬러(Jeff the Killer) 팬픽션을 읽고 비평 |
| 66 | [[I guess I'll talk about Ready Player One [07w3u8iLa-s]\|I guess I'll talk about Ready Player One]] | 00:19:33 | 레디 플레이어 원 영화 감상 |
| 65 | [[The Biggest Plot Hole in The Last Jedi [mPg__kEZ6YM]\|The Biggest Plot Hole in The Last Jedi]] | 00:05:02 | 라스트 제다이의 '가장 큰 플롯 구멍'을 다루는 짧은 영상 |
| 64 | [[Top 10 Lame Things To Do At Disney World [-KeFvjm_hcA]\|Top 10 Lame Things To Do At Disney World]] | 00:12:00 | 디즈니 월드에서 하면 시시한 일 톱 10 패러디 |
| 63 | [[Ready Player One for Girls [bWPMJwHrWFU]\|Ready Player One for Girls]] | 00:05:37 | '여자용' 레디 플레이어 원을 상상하는 코미디 |
| 62 | [[Escape from Tomorrow is a dumb exercise in misery [38BiNsFFzcs]\|Escape from Tomorrow is a dumb exercise in misery]] | 00:47:34 | 디즈니 월드에서 몰래 찍은 영화 Escape from Tomorrow 비평 |
| 61 | [[Dumping on Fifty Shades Freed for 25 Minutes [ILZ7Oy3gM5U]\|Dumping on Fifty Shades Freed for 25 Minutes]] | 00:25:32 | 피프티 셰이드 프리드 비평 |
| 60 | [[The Worst Reality Show of All Time [JKFgn6tNU6w]\|The Worst Reality Show of All Time]] | 00:25:43 | 역대 최악의 리얼리티 쇼 리뷰 |
| 59 | [[I hate The Greatest Showman more every moment [4vHt-yRR_bM]\|I hate The Greatest Showman more every moment]] | 00:32:31 | 위대한 쇼맨 비평 |
| 58 | [[Top 10 Worst Reasons You Hated The Last Jedi [JpoUN_A12Eg]\|Top 10 Worst Reasons You Hated The Last Jedi]] | 00:22:57 | 라스트 제다이를 싫어하는 최악의 이유 톱 10 |
| 57 | [[The Applejack Problem [S4vKQbpOn5k]\|The Applejack Problem]] | 00:19:06 | 마이 리틀 포니 캐릭터 애플잭의 서사적 문제 |
| 56 | [[The Last Jedi SPOILER PARTY Don't Watch [X9QiHlEC22U]\|The Last Jedi SPOILER PARTY Don't Watch]] | 00:18:11 | 라스트 제다이 스포일러 감상 방송 |
| 55 | [[I saw that new star wars [6P6Ia5Qj9W0]\|I saw that new star wars]] | 00:02:40 | 라스트 제다이를 보고 난 직후 짧은 반응 |
| 54 | [[Trapped In A Island With Josh Hutcherson [OVa-sqcDYZ4]\|Trapped In A Island With Josh Hutcherson]] | 00:26:54 | 조시 허처슨과 무인도에 갇히는 팬픽 리뷰 |
| 53 | [[Justice League Bad [vFK7oWLWapc]\|Justice League Bad]] | 00:12:37 | 저스티스 리그(2017) 비평 |
| 52 | [[I played Battlefront II and [YTDa55gBk_E]\|I played Battlefront II and]] | 00:08:44 | 스타워즈 배틀프론트 II(2017) 플레이 소감 |
| 51 | [[The Last Jedi Bingo [I-5CODzeGEE]\|The Last Jedi Bingo]] | 00:12:20 | 라스트 제다이 예측 빙고 |
| 50 | [[The Halloween Costumes Nobody Wanted [K9JttJ_B0PQ]\|The Halloween Costumes Nobody Wanted]] | 00:18:38 | 아무도 원하지 않았을 할로윈 코스튬 소개 |
| 49 | [[Let's do real magic [Zv0v0VCVgJ4]\|Let's do real magic]] | 00:23:59 | '진짜 마법'을 시도해보는 코미디 영상 |
| 48 | [[The only The Last Jedi Trailer Reaction you need [CrwmpuwLBiI]\|The only The Last Jedi Trailer Reaction you need]] | 00:07:45 | 라스트 제다이 트레일러 반응 |
| 47 | [[A Critical Brony Analysis of My Little Pony The Movie [Xd2W3YLFzfc]\|A Critical Brony Analysis of My Little Pony: The Movie]] | 00:08:04 | 마이 리틀 포니 극장판을 브로니 관점에서 비평 |
| 46 | [[I did it. I found the Worst Book [yZMt87ZdUbw]\|I did it. I found the Worst Book.]] | 00:23:19 | '최악의 책'을 찾아냈다며 읽고 리뷰 |
| 45 | [[Porg.mp4 [XTnEhlvb6jI]\|Porg.mp4]] | 00:03:55 | 포그 짧은 영상 |
| 44 | [[Things you need to know about Pennywise [bp6uJJJMaLs]\|Things you need to know about Pennywise]] | 00:05:29 | 영화 IT(2017) 페니와이즈에 대한 짧은 정리 |
| 43 | [[The Last Jedi Sneak Peek Toy Review! SPOILERS [p9vg92-jfFc]\|The Last Jedi Sneak Peek Toy Review! *SPOILERS*]] | 00:06:24 | 라스트 제다이 장난감 '리뷰' 형식의 코미디 |
| 42 | [[But what if Peter hadn't been Spiderman [mcLtyRLpr8k]\|But what if Peter hadn't been Spiderman]] | 00:03:13 | 피터 파커가 스파이더맨이 아니었다면 하는 짧은 상상 |
| 41 | [[Why Does Creepypasta Suck [KAN_IPwK1K8]\|Why Does Creepypasta Suck]] | 00:15:20 | 크리피파스타는 왜 별로인가 |
| 40 | [[Spiderman Homecoming is basically Hey Arnold [DC_AqezinXM]\|Spiderman Homecoming is basically Hey Arnold]] | 00:08:39 | 스파이더맨: 홈커밍이 사실상 Hey Arnold라는 비교 |
| 39 | [[The Cursed Half-Life of the Pirates Franchise [GfCL1VJ4WbQ]\|The Cursed Half-Life of the Pirates Franchise]] | 00:20:33 | 캐리비안의 해적 프랜차이즈의 몰락 분석 |
| 38 | [[Better Disney Theme Park Movies [-OXylWiZ-9c]\|Better Disney Theme Park Movies]] | 00:09:21 | 디즈니 놀이기구 기반 영화의 더 나은 아이디어 |
| 37 | [[Let's Write Some Star Wars Books [5IGkxlSDCJM]\|Let's Write Some Star Wars Books]] | 00:08:52 | 스타워즈 소설 설정을 직접 지어보는 코미디 |
| 36 | [[Beauty and the Beast 2017 Compliment Sandwich [18AquBLpXh8]\|Beauty and the Beast 2017 Compliment Sandwich]] | 00:16:04 | 실사판 미녀와 야수(2017)를 칭찬 샌드위치로 비평 |
| 35 | [[That Last Jedi Teaser [Lkt3SNYMo8I]\|That Last Jedi Teaser]] | 00:07:01 | 라스트 제다이 티저 반응 |
| 34 | [[Top 10 Reasons I Won't Do ASMR ASMR [3QcjAmnDTos]\|Top 10 Reasons I Won't Do ASMR ASMR]] | 00:07:39 | ASMR을 하지 않는 이유를 ASMR로 말하는 패러디 |
| 33 | [[Unfortunate Implications - Beauty and the Beast [gGRmTmA6znk]\|Unfortunate Implications - Beauty and the Beast]] | 00:08:34 | 미녀와 야수의 문제적 함의 |
| 32 | [[Fifty Shades Darker Script Doctor [gzVNYdmS8s8]\|Fifty Shades Darker Script Doctor]] | 00:20:14 | 피프티 셰이드 다크 각본 고쳐 쓰기 |
| 31 | [[A Star Wars Story [b7QzSnDNiNM]\|A Star Wars Story]] | 00:14:14 | 스타워즈 스핀오프 '스토리' 영화 관련 짧은 영상(제목 기준) |
| 30 | [[The Problem With Split And Finding Dory [8W2xnyyc8qk]\|The Problem With Split And Finding Dory]] | 00:13:03 | 영화 Split과 도리를 찾아서의 장애 묘사 문제 |
| 29 | [[What The Last Jedi Means [YT5HI8TBIlM]\|What The Last Jedi Means]] | 00:02:11 | '라스트 제다이' 제목의 의미 추측 |
| 28 | [[Tomorrowland Ruined My Life And Dreams [C1-74z9dFYs]\|Tomorrowland Ruined My Life And Dreams]] | 00:21:11 | 디즈니 영화 투모로우랜드 비평 |
| 27 | [[Top 10 Worst Reasons You Liked Rogue One [P3gf6qyAHOw]\|Top 10 Worst Reasons You Liked Rogue One]] | 00:24:14 | 로그 원을 좋아한 최악의 이유 톱 10 |
| 26 | [[Jyn Erso Audition [sych2UPAvg0]\|Jyn Erso Audition]] | 00:01:51 | 진 어소 오디션 패러디 |
| 25 | [[The Dark Side Doesn't Make Sense [qzk78aItaUQ]\|The Dark Side Doesn't Make Sense]] | 00:11:39 | 스타워즈 다크 사이드 설정의 모순 |
| 24 | [[Fantastic Beasts Script Doctor [EMRnG_mtosY]\|Fantastic Beasts Script Doctor]] | 00:18:16 | 신비한 동물사전 각본 고쳐 쓰기 |
| 23 | [[Doctor Strange Looks Familiar [IBRUtdzTf8U]\|Doctor Strange Looks Familiar]] | 00:06:48 | 닥터 스트레인지가 익숙해 보이는 이유(마블 공식) |
| 22 | [[Westworld Sales Pitch [pvLoheKYmLI]\|Westworld Sales Pitch]] | 00:04:28 | 웨스트월드를 영업하는 코미디 |
| 21 | [[Rogue 101 [YYcdrZfKU3E]\|Rogue 101]] | 00:09:26 | 로그 원 개봉 전 기초 정리 |
| 20 | [[Elsa Has It All Figured Out [3tURqzEJ4vw]\|Elsa Has It All Figured Out]] | 00:04:46 | 엘사 캐릭터에 대한 짧은 코미디 |
| 19 | [[Snoke Isn't Mace Windu Ya Crazies [5hH22wNH5KM]\|Snoke Isn't Mace Windu Ya Crazies]] | 00:07:55 | 스노크가 메이스 윈두라는 팬 이론 반박 |
| 18 | [[Batman V Superman Script Doctor [AwRwiuSG_6w]\|Batman V Superman Script Doctor]] | 00:08:09 | 배트맨 대 슈퍼맨 각본 고쳐 쓰기 |
| 17 | [[5 Dumbest Episode VIII Theories [Pu-dTtt0BGk]\|5 Dumbest Episode VIII Theories]] | 00:08:12 | 에피소드 VIII에 대한 가장 바보 같은 팬 이론 5가지 |
| 16 | [[If Rey is a Skywalker [mjHEHuNyvME]\|If Rey is a Skywalker]] | 00:04:45 | 레이가 스카이워커 가문이라면 하는 짧은 고찰 |
| 15 | [[BB-Gate [3UNWEEPqLos]\|BB-Gate]] | 00:05:12 | BB-8 관련 논란을 다룬 짧은 코미디 |
| 14 | [[Suicide Squad Sales Pitch [PMNFaAUs2mo]\|Suicide Squad Sales Pitch]] | 00:03:18 | 수어사이드 스쿼드를 영업하는 코미디 |
| 13 | [[Cleaning Horse ASMR [4u87Ia5zxUo]\|Cleaning Horse ASMR]] | 00:05:11 | 말 손질 ASMR (직접 키우는 말) |
| 12 | [[Let's Fix Some Ponies [Kesfokvs7C8]\|Let's Fix Some Ponies]] | 00:06:50 | 마이 리틀 포니 캐릭터 고치기 |
| 11 | [[My Episode VIII Wishlist [zFFjaKAdHMk]\|My Episode VIII Wishlist]] | 00:05:47 | 에피소드 VIII 위시리스트 |
| 10 | [[The Problem With Padme [r9-Anpo8AvY]\|The Problem With Padme]] | 00:05:11 | 파드메 캐릭터의 문제 |
| 9 | [[Snokesnokesnokesnoke [hAZK-xBO6UU]\|Snokesnokesnokesnoke]] | 00:01:54 | 스노크 짧은 코미디 영상 |
| 8 | [[Nobody Loves BB-8 Like I Love BB-8 [jfEcVC90Arg]\|Nobody Loves BB-8 Like I Love BB-8]] | 00:01:37 | BB-8 사랑을 표현하는 짧은 영상 |
| 7 | [[How To Make Up Star Wars Names [3ViKvHkNyqE]\|How To Make Up Star Wars Names]] | 00:01:51 | 스타워즈식 이름 짓는 법 |
| 6 | [[Anakin vs Obi-Wan (cover) [G0JxmyTwY7s]\|Anakin vs Obi-Wan (cover)]] | 00:01:58 | 스타워즈 에피소드 III 아나킨 대 오비완 음악 커버 |
| 5 | [[Harry Potter  See You Again [5J5I-_wAe5Y]\|Harry Potter // See You Again]] | 00:02:17 | 해리 포터 팬 영상 (See You Again) |
| 4 | [[The Adventures of Darging Do [3bWR-WkwOBo]\|The Adventures of Darging Do]] | 00:00:17 | 'Daring Do' 관련 아주 짧은 초기 영상 |
| 3 | [[Episode III - The Final Battle (cover) [Is3Sl3RR8kM]\|Episode III - "The Final Battle" (cover)]] | 00:01:22 | 스타워즈 에피소드 III 'The Final Battle' 음악 커버 |
| 2 | [[Kool Pup [JZChrjXffBM]\|Kool Pup]] | 00:01:03 | 초기 짧은 개 영상(제목 기준) |
| 1 | [[Voldemort Isn't Funny [wGj-AWQVBPk]\|Voldemort Isn't Funny]] | 00:01:00 | 볼드모트는 웃기지 않다는 초기 짧은 코미디 |
