---
title: "Tomorrowland Ruined My Life And Dreams"
channel: "Jenny Nicholson"
type: "video"
video_id: "C1-74z9dFYs"
url: "https://www.youtube.com/watch?v=C1-74z9dFYs"
duration: "00:21:11"
upload_order: 28
about: "Critique of Disney's Tomorrowland"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Tomorrowland Ruined My Life And Dreams

Channel: [[Jenny Nicholson]] · Length 00:21:11 · [YouTube](https://www.youtube.com/watch?v=C1-74z9dFYs)

## What it is

Critique of Disney's Tomorrowland

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
