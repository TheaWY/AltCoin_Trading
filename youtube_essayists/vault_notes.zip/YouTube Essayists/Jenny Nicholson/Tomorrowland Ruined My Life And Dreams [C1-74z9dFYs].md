---
title: "Tomorrowland Ruined My Life And Dreams"
channel: "Jenny Nicholson"
type: "video"
video_id: "C1-74z9dFYs"
url: "https://www.youtube.com/watch?v=C1-74z9dFYs"
duration: "00:21:11"
upload_order: 28
about_ko: "디즈니 영화 투모로우랜드 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Tomorrowland Ruined My Life And Dreams

채널: [[Jenny Nicholson]] · 길이 00:21:11 · [YouTube](https://www.youtube.com/watch?v=C1-74z9dFYs)

## 어떤 영상인가

디즈니 영화 투모로우랜드 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
