---
title: "Top 10 Worst Reasons You Hated The Last Jedi"
channel: "Jenny Nicholson"
type: "video"
video_id: "JpoUN_A12Eg"
url: "https://www.youtube.com/watch?v=JpoUN_A12Eg"
duration: "00:22:57"
upload_order: 58
about: "Top 10 worst reasons people hated The Last Jedi"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Top 10 Worst Reasons You Hated The Last Jedi

Channel: [[Jenny Nicholson]] · Length 00:22:57 · [YouTube](https://www.youtube.com/watch?v=JpoUN_A12Eg)

## What it is

Top 10 worst reasons people hated The Last Jedi

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
