---
title: "Top 10 Worst Reasons You Hated The Last Jedi"
channel: "Jenny Nicholson"
type: "video"
video_id: "JpoUN_A12Eg"
url: "https://www.youtube.com/watch?v=JpoUN_A12Eg"
duration: "00:22:57"
upload_order: 58
about_ko: "라스트 제다이를 싫어하는 최악의 이유 톱 10"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Top 10 Worst Reasons You Hated The Last Jedi

채널: [[Jenny Nicholson]] · 길이 00:22:57 · [YouTube](https://www.youtube.com/watch?v=JpoUN_A12Eg)

## 어떤 영상인가

라스트 제다이를 싫어하는 최악의 이유 톱 10

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
