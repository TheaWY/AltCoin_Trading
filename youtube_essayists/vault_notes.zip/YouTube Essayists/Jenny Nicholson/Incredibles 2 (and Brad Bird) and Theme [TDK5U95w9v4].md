---
title: "Incredibles 2 (and Brad Bird) and Theme"
channel: "Jenny Nicholson"
type: "video"
video_id: "TDK5U95w9v4"
url: "https://www.youtube.com/watch?v=TDK5U95w9v4"
duration: "00:11:31"
upload_order: 75
about: "Incredibles 2 and the themes in Brad Bird's films"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Incredibles 2 (and Brad Bird) and Theme

Channel: [[Jenny Nicholson]] · Length 00:11:31 · [YouTube](https://www.youtube.com/watch?v=TDK5U95w9v4)

## What it is

Incredibles 2 and the themes in Brad Bird's films

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
