---
title: "Incredibles 2 (and Brad Bird) and Theme"
channel: "Jenny Nicholson"
type: "video"
video_id: "TDK5U95w9v4"
url: "https://www.youtube.com/watch?v=TDK5U95w9v4"
duration: "00:11:31"
upload_order: 75
about_ko: "인크레더블 2와 브래드 버드 영화의 주제 의식"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Incredibles 2 (and Brad Bird) and Theme

채널: [[Jenny Nicholson]] · 길이 00:11:31 · [YouTube](https://www.youtube.com/watch?v=TDK5U95w9v4)

## 어떤 영상인가

인크레더블 2와 브래드 버드 영화의 주제 의식

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
