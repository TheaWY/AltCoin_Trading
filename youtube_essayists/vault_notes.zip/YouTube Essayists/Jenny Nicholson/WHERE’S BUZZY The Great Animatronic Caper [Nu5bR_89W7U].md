---
title: "WHERE’S BUZZY? The Great Animatronic Caper"
channel: "Jenny Nicholson"
type: "video"
video_id: "Nu5bR_89W7U"
url: "https://www.youtube.com/watch?v=Nu5bR_89W7U"
duration: "00:36:52"
upload_order: 85
about_ko: "디즈니 파크에서 사라진 애니매트로닉스 'Buzzy'의 행방을 추적"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# WHERE’S BUZZY? The Great Animatronic Caper

채널: [[Jenny Nicholson]] · 길이 00:36:52 · [YouTube](https://www.youtube.com/watch?v=Nu5bR_89W7U)

## 어떤 영상인가

디즈니 파크에서 사라진 애니매트로닉스 'Buzzy'의 행방을 추적

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
