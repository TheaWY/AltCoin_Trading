---
title: "WHERE’S BUZZY? The Great Animatronic Caper"
channel: "Jenny Nicholson"
type: "video"
video_id: "Nu5bR_89W7U"
url: "https://www.youtube.com/watch?v=Nu5bR_89W7U"
duration: "00:36:52"
upload_order: 85
about: "Tracking down \"Buzzy,\" an animatronic that vanished from a Disney park"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# WHERE’S BUZZY? The Great Animatronic Caper

Channel: [[Jenny Nicholson]] · Length 00:36:52 · [YouTube](https://www.youtube.com/watch?v=Nu5bR_89W7U)

## What it is

Tracking down "Buzzy," an animatronic that vanished from a Disney park

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
