---
title: "Top 10 Reasons I Won't Do ASMR ASMR"
channel: "Jenny Nicholson"
type: "video"
video_id: "3QcjAmnDTos"
url: "https://www.youtube.com/watch?v=3QcjAmnDTos"
duration: "00:07:39"
upload_order: 34
about: "ASMR parody about why she won't do ASMR"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Top 10 Reasons I Won't Do ASMR ASMR

Channel: [[Jenny Nicholson]] · Length 00:07:39 · [YouTube](https://www.youtube.com/watch?v=3QcjAmnDTos)

## What it is

ASMR parody about why she won't do ASMR

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
