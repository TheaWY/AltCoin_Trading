---
title: "Top 10 Reasons I Won't Do ASMR ASMR"
channel: "Jenny Nicholson"
type: "video"
video_id: "3QcjAmnDTos"
url: "https://www.youtube.com/watch?v=3QcjAmnDTos"
duration: "00:07:39"
upload_order: 34
about_ko: "ASMR을 하지 않는 이유를 ASMR로 말하는 패러디"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Top 10 Reasons I Won't Do ASMR ASMR

채널: [[Jenny Nicholson]] · 길이 00:07:39 · [YouTube](https://www.youtube.com/watch?v=3QcjAmnDTos)

## 어떤 영상인가

ASMR을 하지 않는 이유를 ASMR로 말하는 패러디

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
