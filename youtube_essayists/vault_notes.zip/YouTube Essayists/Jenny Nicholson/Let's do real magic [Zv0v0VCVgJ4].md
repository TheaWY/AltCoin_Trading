---
title: "Let's do real magic"
channel: "Jenny Nicholson"
type: "video"
video_id: "Zv0v0VCVgJ4"
url: "https://www.youtube.com/watch?v=Zv0v0VCVgJ4"
duration: "00:23:59"
upload_order: 49
about_ko: "'진짜 마법'을 시도해보는 코미디 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Let's do real magic

채널: [[Jenny Nicholson]] · 길이 00:23:59 · [YouTube](https://www.youtube.com/watch?v=Zv0v0VCVgJ4)

## 어떤 영상인가

'진짜 마법'을 시도해보는 코미디 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
