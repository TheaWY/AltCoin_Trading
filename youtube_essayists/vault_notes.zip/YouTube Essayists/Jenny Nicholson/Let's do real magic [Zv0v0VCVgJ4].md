---
title: "Let's do real magic"
channel: "Jenny Nicholson"
type: "video"
video_id: "Zv0v0VCVgJ4"
url: "https://www.youtube.com/watch?v=Zv0v0VCVgJ4"
duration: "00:23:59"
upload_order: 49
about: "Comedy video attempting \"real magic\""
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Let's do real magic

Channel: [[Jenny Nicholson]] · Length 00:23:59 · [YouTube](https://www.youtube.com/watch?v=Zv0v0VCVgJ4)

## What it is

Comedy video attempting "real magic"

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
