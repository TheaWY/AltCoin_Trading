---
title: "Well. Let’s read Colin Trevorrow’s Episode IX script"
channel: "Jenny Nicholson"
type: "video"
video_id: "7AGvXqviRys"
url: "https://www.youtube.com/watch?v=7AGvXqviRys"
duration: "01:50:02"
upload_order: 102
about_ko: "유출된 콜린 트레버로우의 스타워즈 에피소드 IX 각본(Duel of the Fates)을 읽고 분석"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Well. Let’s read Colin Trevorrow’s Episode IX script

채널: [[Jenny Nicholson]] · 길이 01:50:02 · [YouTube](https://www.youtube.com/watch?v=7AGvXqviRys)

## 어떤 영상인가

유출된 콜린 트레버로우의 스타워즈 에피소드 IX 각본(Duel of the Fates)을 읽고 분석

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
