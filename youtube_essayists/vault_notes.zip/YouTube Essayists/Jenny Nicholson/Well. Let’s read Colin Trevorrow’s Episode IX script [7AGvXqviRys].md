---
title: "Well. Let’s read Colin Trevorrow’s Episode IX script"
channel: "Jenny Nicholson"
type: "video"
video_id: "7AGvXqviRys"
url: "https://www.youtube.com/watch?v=7AGvXqviRys"
duration: "01:50:02"
upload_order: 102
about: "Reading and analyzing Colin Trevorrow's leaked Episode IX script (Duel of the Fates)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Well. Let’s read Colin Trevorrow’s Episode IX script

Channel: [[Jenny Nicholson]] · Length 01:50:02 · [YouTube](https://www.youtube.com/watch?v=7AGvXqviRys)

## What it is

Reading and analyzing Colin Trevorrow's leaked Episode IX script (Duel of the Fates)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
