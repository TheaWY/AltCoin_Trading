---
title: "Harry Potter || See You Again"
channel: "Jenny Nicholson"
type: "video"
video_id: "5J5I-_wAe5Y"
url: "https://www.youtube.com/watch?v=5J5I-_wAe5Y"
duration: "00:02:17"
upload_order: 5
about_ko: "해리 포터 팬 영상 (See You Again)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Harry Potter || See You Again

채널: [[Jenny Nicholson]] · 길이 00:02:17 · [YouTube](https://www.youtube.com/watch?v=5J5I-_wAe5Y)

## 어떤 영상인가

해리 포터 팬 영상 (See You Again)

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
