---
title: "An Excruciatingly Deep Dive into the Avatar Theme Park"
channel: "Jenny Nicholson"
type: "video"
video_id: "xrIxGWterYA"
url: "https://www.youtube.com/watch?v=xrIxGWterYA"
duration: "00:59:01"
upload_order: 82
about_ko: "디즈니 아바타 테마파크(Pandora)를 깊게 분석"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# An Excruciatingly Deep Dive into the Avatar Theme Park

채널: [[Jenny Nicholson]] · 길이 00:59:01 · [YouTube](https://www.youtube.com/watch?v=xrIxGWterYA)

## 어떤 영상인가

디즈니 아바타 테마파크(Pandora)를 깊게 분석

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
