---
title: "An Excruciatingly Deep Dive into the Avatar Theme Park"
channel: "Jenny Nicholson"
type: "video"
video_id: "xrIxGWterYA"
url: "https://www.youtube.com/watch?v=xrIxGWterYA"
duration: "00:59:01"
upload_order: 82
about: "Deep dive into Disney's Avatar land (Pandora)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# An Excruciatingly Deep Dive into the Avatar Theme Park

Channel: [[Jenny Nicholson]] · Length 00:59:01 · [YouTube](https://www.youtube.com/watch?v=xrIxGWterYA)

## What it is

Deep dive into Disney's Avatar land (Pandora)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
