---
title: "Why Does Creepypasta Suck"
channel: "Jenny Nicholson"
type: "video"
video_id: "KAN_IPwK1K8"
url: "https://www.youtube.com/watch?v=KAN_IPwK1K8"
duration: "00:15:20"
upload_order: 41
about: "Why creepypasta is bad"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Why Does Creepypasta Suck

Channel: [[Jenny Nicholson]] · Length 00:15:20 · [YouTube](https://www.youtube.com/watch?v=KAN_IPwK1K8)

## What it is

Why creepypasta is bad

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
