---
title: "Why Does Creepypasta Suck"
channel: "Jenny Nicholson"
type: "video"
video_id: "KAN_IPwK1K8"
url: "https://www.youtube.com/watch?v=KAN_IPwK1K8"
duration: "00:15:20"
upload_order: 41
about_ko: "크리피파스타는 왜 별로인가"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Why Does Creepypasta Suck

채널: [[Jenny Nicholson]] · 길이 00:15:20 · [YouTube](https://www.youtube.com/watch?v=KAN_IPwK1K8)

## 어떤 영상인가

크리피파스타는 왜 별로인가

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
