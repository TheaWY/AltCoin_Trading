---
title: "The Last Jedi SPOILER PARTY Don't Watch"
channel: "Jenny Nicholson"
type: "video"
video_id: "X9QiHlEC22U"
url: "https://www.youtube.com/watch?v=X9QiHlEC22U"
duration: "00:18:11"
upload_order: 56
about_ko: "라스트 제다이 스포일러 감상 방송"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Last Jedi SPOILER PARTY Don't Watch

채널: [[Jenny Nicholson]] · 길이 00:18:11 · [YouTube](https://www.youtube.com/watch?v=X9QiHlEC22U)

## 어떤 영상인가

라스트 제다이 스포일러 감상 방송

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
