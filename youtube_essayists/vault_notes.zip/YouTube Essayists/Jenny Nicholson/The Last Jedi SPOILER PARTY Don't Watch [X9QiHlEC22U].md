---
title: "The Last Jedi SPOILER PARTY Don't Watch"
channel: "Jenny Nicholson"
type: "video"
video_id: "X9QiHlEC22U"
url: "https://www.youtube.com/watch?v=X9QiHlEC22U"
duration: "00:18:11"
upload_order: 56
about: "The Last Jedi spoiler discussion"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Last Jedi SPOILER PARTY Don't Watch

Channel: [[Jenny Nicholson]] · Length 00:18:11 · [YouTube](https://www.youtube.com/watch?v=X9QiHlEC22U)

## What it is

The Last Jedi spoiler discussion

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
