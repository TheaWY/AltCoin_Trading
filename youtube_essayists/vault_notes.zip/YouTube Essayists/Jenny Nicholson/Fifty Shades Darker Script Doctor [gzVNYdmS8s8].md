---
title: "Fifty Shades Darker Script Doctor"
channel: "Jenny Nicholson"
type: "video"
video_id: "gzVNYdmS8s8"
url: "https://www.youtube.com/watch?v=gzVNYdmS8s8"
duration: "00:20:14"
upload_order: 32
about: "Script Doctor: rewriting Fifty Shades Darker"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Fifty Shades Darker Script Doctor

Channel: [[Jenny Nicholson]] · Length 00:20:14 · [YouTube](https://www.youtube.com/watch?v=gzVNYdmS8s8)

## What it is

Script Doctor: rewriting Fifty Shades Darker

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
