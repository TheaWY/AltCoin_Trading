---
title: "Fifty Shades Darker Script Doctor"
channel: "Jenny Nicholson"
type: "video"
video_id: "gzVNYdmS8s8"
url: "https://www.youtube.com/watch?v=gzVNYdmS8s8"
duration: "00:20:14"
upload_order: 32
about_ko: "피프티 셰이드 다크 각본 고쳐 쓰기"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Fifty Shades Darker Script Doctor

채널: [[Jenny Nicholson]] · 길이 00:20:14 · [YouTube](https://www.youtube.com/watch?v=gzVNYdmS8s8)

## 어떤 영상인가

피프티 셰이드 다크 각본 고쳐 쓰기

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
