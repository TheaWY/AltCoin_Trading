---
title: "The Halloween Costumes Nobody Wanted"
channel: "Jenny Nicholson"
type: "video"
video_id: "K9JttJ_B0PQ"
url: "https://www.youtube.com/watch?v=K9JttJ_B0PQ"
duration: "00:18:38"
upload_order: 50
about_ko: "아무도 원하지 않았을 할로윈 코스튬 소개"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Halloween Costumes Nobody Wanted

채널: [[Jenny Nicholson]] · 길이 00:18:38 · [YouTube](https://www.youtube.com/watch?v=K9JttJ_B0PQ)

## 어떤 영상인가

아무도 원하지 않았을 할로윈 코스튬 소개

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
