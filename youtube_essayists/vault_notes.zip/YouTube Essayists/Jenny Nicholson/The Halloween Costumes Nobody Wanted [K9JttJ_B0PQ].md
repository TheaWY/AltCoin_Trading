---
title: "The Halloween Costumes Nobody Wanted"
channel: "Jenny Nicholson"
type: "video"
video_id: "K9JttJ_B0PQ"
url: "https://www.youtube.com/watch?v=K9JttJ_B0PQ"
duration: "00:18:38"
upload_order: 50
about: "Halloween costumes nobody wanted"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Halloween Costumes Nobody Wanted

Channel: [[Jenny Nicholson]] · Length 00:18:38 · [YouTube](https://www.youtube.com/watch?v=K9JttJ_B0PQ)

## What it is

Halloween costumes nobody wanted

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
