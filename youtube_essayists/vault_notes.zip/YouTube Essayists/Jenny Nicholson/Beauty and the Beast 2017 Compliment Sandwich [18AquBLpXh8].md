---
title: "Beauty and the Beast 2017 Compliment Sandwich"
channel: "Jenny Nicholson"
type: "video"
video_id: "18AquBLpXh8"
url: "https://www.youtube.com/watch?v=18AquBLpXh8"
duration: "00:16:04"
upload_order: 36
about: "Compliment-sandwich critique of live-action Beauty and the Beast (2017)"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Beauty and the Beast 2017 Compliment Sandwich

Channel: [[Jenny Nicholson]] · Length 00:16:04 · [YouTube](https://www.youtube.com/watch?v=18AquBLpXh8)

## What it is

Compliment-sandwich critique of live-action Beauty and the Beast (2017)

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
