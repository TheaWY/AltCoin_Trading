---
title: "Beauty and the Beast 2017 Compliment Sandwich"
channel: "Jenny Nicholson"
type: "video"
video_id: "18AquBLpXh8"
url: "https://www.youtube.com/watch?v=18AquBLpXh8"
duration: "00:16:04"
upload_order: 36
about_ko: "실사판 미녀와 야수(2017)를 칭찬 샌드위치로 비평"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Beauty and the Beast 2017 Compliment Sandwich

채널: [[Jenny Nicholson]] · 길이 00:16:04 · [YouTube](https://www.youtube.com/watch?v=18AquBLpXh8)

## 어떤 영상인가

실사판 미녀와 야수(2017)를 칭찬 샌드위치로 비평

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
