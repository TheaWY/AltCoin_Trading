---
title: "I read the terrible Episode IX pitch where Rey is a robot"
channel: "Jenny Nicholson"
type: "video"
video_id: "aanyjLmB1Bs"
url: "https://www.youtube.com/watch?v=aanyjLmB1Bs"
duration: "00:53:47"
upload_order: 100
about: "Reading a bad fan pitch for Episode IX in which Rey is a robot"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# I read the terrible Episode IX pitch where Rey is a robot

Channel: [[Jenny Nicholson]] · Length 00:53:47 · [YouTube](https://www.youtube.com/watch?v=aanyjLmB1Bs)

## What it is

Reading a bad fan pitch for Episode IX in which Rey is a robot

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
