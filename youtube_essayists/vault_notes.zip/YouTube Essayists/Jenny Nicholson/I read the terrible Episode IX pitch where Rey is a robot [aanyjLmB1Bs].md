---
title: "I read the terrible Episode IX pitch where Rey is a robot"
channel: "Jenny Nicholson"
type: "video"
video_id: "aanyjLmB1Bs"
url: "https://www.youtube.com/watch?v=aanyjLmB1Bs"
duration: "00:53:47"
upload_order: 100
about_ko: "레이가 로봇이라는 설정의 엉터리 에피소드 IX 팬 피치를 읽는 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# I read the terrible Episode IX pitch where Rey is a robot

채널: [[Jenny Nicholson]] · 길이 00:53:47 · [YouTube](https://www.youtube.com/watch?v=aanyjLmB1Bs)

## 어떤 영상인가

레이가 로봇이라는 설정의 엉터리 에피소드 IX 팬 피치를 읽는 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
