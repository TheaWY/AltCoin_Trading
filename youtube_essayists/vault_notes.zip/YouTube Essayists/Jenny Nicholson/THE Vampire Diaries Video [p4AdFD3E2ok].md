---
title: "THE Vampire Diaries Video"
channel: "Jenny Nicholson"
type: "video"
video_id: "p4AdFD3E2ok"
url: "https://www.youtube.com/watch?v=p4AdFD3E2ok"
duration: "02:33:19"
upload_order: 107
about: "Long recap and critique of The Vampire Diaries, all seasons"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# THE Vampire Diaries Video

Channel: [[Jenny Nicholson]] · Length 02:33:19 · [YouTube](https://www.youtube.com/watch?v=p4AdFD3E2ok)

## What it is

Long recap and critique of The Vampire Diaries, all seasons

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
