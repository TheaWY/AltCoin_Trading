---
title: "THE Vampire Diaries Video"
channel: "Jenny Nicholson"
type: "video"
video_id: "p4AdFD3E2ok"
url: "https://www.youtube.com/watch?v=p4AdFD3E2ok"
duration: "02:33:19"
upload_order: 107
about_ko: "드라마 The Vampire Diaries 전 시즌을 정리하고 비평하는 장편"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# THE Vampire Diaries Video

채널: [[Jenny Nicholson]] · 길이 02:33:19 · [YouTube](https://www.youtube.com/watch?v=p4AdFD3E2ok)

## 어떤 영상인가

드라마 The Vampire Diaries 전 시즌을 정리하고 비평하는 장편

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
