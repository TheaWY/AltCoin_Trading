---
title: "Dark Internet Rituals"
channel: "Jenny Nicholson"
type: "video"
video_id: "nmy4FMwug0Q"
url: "https://www.youtube.com/watch?v=nmy4FMwug0Q"
duration: "00:34:58"
upload_order: 76
about: "Trying out or examining \"rituals\" from internet creepy lore"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Dark Internet Rituals

Channel: [[Jenny Nicholson]] · Length 00:34:58 · [YouTube](https://www.youtube.com/watch?v=nmy4FMwug0Q)

## What it is

Trying out or examining "rituals" from internet creepy lore

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
