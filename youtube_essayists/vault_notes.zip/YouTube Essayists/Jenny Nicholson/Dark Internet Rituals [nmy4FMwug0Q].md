---
title: "Dark Internet Rituals"
channel: "Jenny Nicholson"
type: "video"
video_id: "nmy4FMwug0Q"
url: "https://www.youtube.com/watch?v=nmy4FMwug0Q"
duration: "00:34:58"
upload_order: 76
about_ko: "인터넷 괴담 속 '의식'들을 직접 해보거나 살펴보는 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Dark Internet Rituals

채널: [[Jenny Nicholson]] · 길이 00:34:58 · [YouTube](https://www.youtube.com/watch?v=nmy4FMwug0Q)

## 어떤 영상인가

인터넷 괴담 속 '의식'들을 직접 해보거나 살펴보는 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
