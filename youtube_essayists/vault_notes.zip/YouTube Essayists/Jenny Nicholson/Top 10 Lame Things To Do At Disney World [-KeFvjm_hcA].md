---
title: "Top 10 Lame Things To Do At Disney World"
channel: "Jenny Nicholson"
type: "video"
video_id: "-KeFvjm_hcA"
url: "https://www.youtube.com/watch?v=-KeFvjm_hcA"
duration: "00:12:00"
upload_order: 64
about_ko: "디즈니 월드에서 하면 시시한 일 톱 10 패러디"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Top 10 Lame Things To Do At Disney World

채널: [[Jenny Nicholson]] · 길이 00:12:00 · [YouTube](https://www.youtube.com/watch?v=-KeFvjm_hcA)

## 어떤 영상인가

디즈니 월드에서 하면 시시한 일 톱 10 패러디

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
