---
title: "Top 10 Lame Things To Do At Disney World"
channel: "Jenny Nicholson"
type: "video"
video_id: "-KeFvjm_hcA"
url: "https://www.youtube.com/watch?v=-KeFvjm_hcA"
duration: "00:12:00"
upload_order: 64
about: "Parody top 10 of lame things to do at Disney World"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Top 10 Lame Things To Do At Disney World

Channel: [[Jenny Nicholson]] · Length 00:12:00 · [YouTube](https://www.youtube.com/watch?v=-KeFvjm_hcA)

## What it is

Parody top 10 of lame things to do at Disney World

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
