---
title: "The Adventures of Darging Do"
channel: "Jenny Nicholson"
type: "video"
video_id: "3bWR-WkwOBo"
url: "https://www.youtube.com/watch?v=3bWR-WkwOBo"
duration: "00:00:17"
upload_order: 4
about_ko: "'Daring Do' 관련 아주 짧은 초기 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Adventures of Darging Do

채널: [[Jenny Nicholson]] · 길이 00:00:17 · [YouTube](https://www.youtube.com/watch?v=3bWR-WkwOBo)

## 어떤 영상인가

'Daring Do' 관련 아주 짧은 초기 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
