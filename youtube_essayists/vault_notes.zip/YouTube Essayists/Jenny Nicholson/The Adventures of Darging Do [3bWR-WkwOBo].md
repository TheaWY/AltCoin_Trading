---
title: "The Adventures of Darging Do"
channel: "Jenny Nicholson"
type: "video"
video_id: "3bWR-WkwOBo"
url: "https://www.youtube.com/watch?v=3bWR-WkwOBo"
duration: "00:00:17"
upload_order: 4
about: "Very short early video about Daring Do"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Adventures of Darging Do

Channel: [[Jenny Nicholson]] · Length 00:00:17 · [YouTube](https://www.youtube.com/watch?v=3bWR-WkwOBo)

## What it is

Very short early video about Daring Do

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
