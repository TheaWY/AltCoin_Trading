---
title: "I saw that new star wars"
channel: "Jenny Nicholson"
type: "video"
video_id: "6P6Ia5Qj9W0"
url: "https://www.youtube.com/watch?v=6P6Ia5Qj9W0"
duration: "00:02:40"
upload_order: 55
about_ko: "라스트 제다이를 보고 난 직후 짧은 반응"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# I saw that new star wars

채널: [[Jenny Nicholson]] · 길이 00:02:40 · [YouTube](https://www.youtube.com/watch?v=6P6Ia5Qj9W0)

## 어떤 영상인가

라스트 제다이를 보고 난 직후 짧은 반응

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
