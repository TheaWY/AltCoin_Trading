---
title: "I saw that new star wars"
channel: "Jenny Nicholson"
type: "video"
video_id: "6P6Ia5Qj9W0"
url: "https://www.youtube.com/watch?v=6P6Ia5Qj9W0"
duration: "00:02:40"
upload_order: 55
about: "Short reaction right after seeing The Last Jedi"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# I saw that new star wars

Channel: [[Jenny Nicholson]] · Length 00:02:40 · [YouTube](https://www.youtube.com/watch?v=6P6Ia5Qj9W0)

## What it is

Short reaction right after seeing The Last Jedi

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
