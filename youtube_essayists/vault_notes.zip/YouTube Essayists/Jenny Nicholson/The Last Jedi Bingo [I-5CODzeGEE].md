---
title: "The Last Jedi Bingo"
channel: "Jenny Nicholson"
type: "video"
video_id: "I-5CODzeGEE"
url: "https://www.youtube.com/watch?v=I-5CODzeGEE"
duration: "00:12:20"
upload_order: 51
about_ko: "라스트 제다이 예측 빙고"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Last Jedi Bingo

채널: [[Jenny Nicholson]] · 길이 00:12:20 · [YouTube](https://www.youtube.com/watch?v=I-5CODzeGEE)

## 어떤 영상인가

라스트 제다이 예측 빙고

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
