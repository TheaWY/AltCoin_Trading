---
title: "The Last Jedi Bingo"
channel: "Jenny Nicholson"
type: "video"
video_id: "I-5CODzeGEE"
url: "https://www.youtube.com/watch?v=I-5CODzeGEE"
duration: "00:12:20"
upload_order: 51
about: "Prediction bingo for The Last Jedi"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# The Last Jedi Bingo

Channel: [[Jenny Nicholson]] · Length 00:12:20 · [YouTube](https://www.youtube.com/watch?v=I-5CODzeGEE)

## What it is

Prediction bingo for The Last Jedi

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
