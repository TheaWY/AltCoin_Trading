---
title: "Star Wars Land: An Excruciatingly In-Depth Prequel"
channel: "Jenny Nicholson"
type: "video"
video_id: "dYy6V_ZVSU8"
url: "https://www.youtube.com/watch?v=dYy6V_ZVSU8"
duration: "00:42:54"
upload_order: 95
about: "Deep dive into the plans and lore of Star Wars: Galaxy's Edge before it opened"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Star Wars Land: An Excruciatingly In-Depth Prequel

Channel: [[Jenny Nicholson]] · Length 00:42:54 · [YouTube](https://www.youtube.com/watch?v=dYy6V_ZVSU8)

## What it is

Deep dive into the plans and lore of Star Wars: Galaxy's Edge before it opened

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
