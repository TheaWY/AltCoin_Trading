---
title: "Star Wars Land: An Excruciatingly In-Depth Prequel"
channel: "Jenny Nicholson"
type: "video"
video_id: "dYy6V_ZVSU8"
url: "https://www.youtube.com/watch?v=dYy6V_ZVSU8"
duration: "00:42:54"
upload_order: 95
about_ko: "디즈니 스타워즈 랜드(Galaxy's Edge) 개장 전 설정과 계획을 깊게 파고드는 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Star Wars Land: An Excruciatingly In-Depth Prequel

채널: [[Jenny Nicholson]] · 길이 00:42:54 · [YouTube](https://www.youtube.com/watch?v=dYy6V_ZVSU8)

## 어떤 영상인가

디즈니 스타워즈 랜드(Galaxy's Edge) 개장 전 설정과 계획을 깊게 파고드는 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
