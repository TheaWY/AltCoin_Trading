---
title: "Nobody Loves BB-8 Like I Love BB-8"
channel: "Jenny Nicholson"
type: "video"
video_id: "jfEcVC90Arg"
url: "https://www.youtube.com/watch?v=jfEcVC90Arg"
duration: "00:01:37"
upload_order: 8
about: "Short video about loving BB-8"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Nobody Loves BB-8 Like I Love BB-8

Channel: [[Jenny Nicholson]] · Length 00:01:37 · [YouTube](https://www.youtube.com/watch?v=jfEcVC90Arg)

## What it is

Short video about loving BB-8

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
