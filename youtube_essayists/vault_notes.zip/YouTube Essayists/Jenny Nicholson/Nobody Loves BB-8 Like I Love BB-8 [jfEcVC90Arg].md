---
title: "Nobody Loves BB-8 Like I Love BB-8"
channel: "Jenny Nicholson"
type: "video"
video_id: "jfEcVC90Arg"
url: "https://www.youtube.com/watch?v=jfEcVC90Arg"
duration: "00:01:37"
upload_order: 8
about_ko: "BB-8 사랑을 표현하는 짧은 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Nobody Loves BB-8 Like I Love BB-8

채널: [[Jenny Nicholson]] · 길이 00:01:37 · [YouTube](https://www.youtube.com/watch?v=jfEcVC90Arg)

## 어떤 영상인가

BB-8 사랑을 표현하는 짧은 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
