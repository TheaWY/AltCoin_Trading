---
title: "SPIDERQUEST: Quest for the Man-Sized Spider"
channel: "Jenny Nicholson"
type: "video"
video_id: "-CRXUeTmNtE"
url: "https://www.youtube.com/watch?v=-CRXUeTmNtE"
duration: "00:22:59"
upload_order: 105
about_ko: "사람 크기만 한 거미를 찾아 나서는 코미디 탐사 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# SPIDERQUEST: Quest for the Man-Sized Spider

채널: [[Jenny Nicholson]] · 길이 00:22:59 · [YouTube](https://www.youtube.com/watch?v=-CRXUeTmNtE)

## 어떤 영상인가

사람 크기만 한 거미를 찾아 나서는 코미디 탐사 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
