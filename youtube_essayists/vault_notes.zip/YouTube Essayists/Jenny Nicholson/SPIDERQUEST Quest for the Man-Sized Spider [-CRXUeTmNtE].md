---
title: "SPIDERQUEST: Quest for the Man-Sized Spider"
channel: "Jenny Nicholson"
type: "video"
video_id: "-CRXUeTmNtE"
url: "https://www.youtube.com/watch?v=-CRXUeTmNtE"
duration: "00:22:59"
upload_order: 105
about: "Comedy quest to find a man-sized spider"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# SPIDERQUEST: Quest for the Man-Sized Spider

Channel: [[Jenny Nicholson]] · Length 00:22:59 · [YouTube](https://www.youtube.com/watch?v=-CRXUeTmNtE)

## What it is

Comedy quest to find a man-sized spider

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
