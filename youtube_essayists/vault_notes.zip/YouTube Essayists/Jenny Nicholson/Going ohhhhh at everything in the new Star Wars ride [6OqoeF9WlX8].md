---
title: "Going \"ohhhhh\" at everything in the new Star Wars ride"
channel: "Jenny Nicholson"
type: "video"
video_id: "6OqoeF9WlX8"
url: "https://www.youtube.com/watch?v=6OqoeF9WlX8"
duration: "00:01:54"
upload_order: 99
about: "Short clip of reacting to everything on the new Star Wars ride"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Going "ohhhhh" at everything in the new Star Wars ride

Channel: [[Jenny Nicholson]] · Length 00:01:54 · [YouTube](https://www.youtube.com/watch?v=6OqoeF9WlX8)

## What it is

Short clip of reacting to everything on the new Star Wars ride

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
