---
title: "Going \"ohhhhh\" at everything in the new Star Wars ride"
channel: "Jenny Nicholson"
type: "video"
video_id: "6OqoeF9WlX8"
url: "https://www.youtube.com/watch?v=6OqoeF9WlX8"
duration: "00:01:54"
upload_order: 99
about_ko: "새 스타워즈 놀이기구에서 모든 것에 감탄하는 짧은 영상"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Going "ohhhhh" at everything in the new Star Wars ride

채널: [[Jenny Nicholson]] · 길이 00:01:54 · [YouTube](https://www.youtube.com/watch?v=6OqoeF9WlX8)

## 어떤 영상인가

새 스타워즈 놀이기구에서 모든 것에 감탄하는 짧은 영상

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
