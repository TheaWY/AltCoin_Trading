---
title: "Well, I guess SOMEBODY had to read “Trigger Warning”"
channel: "Jenny Nicholson"
type: "video"
video_id: "qMgMr0JcYJ4"
url: "https://www.youtube.com/watch?v=qMgMr0JcYJ4"
duration: "01:28:39"
upload_order: 84
about_ko: "문제적 책 'Trigger Warning'을 읽고 비평하는 장편"
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Well, I guess SOMEBODY had to read “Trigger Warning”

채널: [[Jenny Nicholson]] · 길이 01:28:39 · [YouTube](https://www.youtube.com/watch?v=qMgMr0JcYJ4)

## 어떤 영상인가

문제적 책 'Trigger Warning'을 읽고 비평하는 장편

## Transcript

<!-- transcript -->

_아직 가져오지 않음. `python yt_vault.py fetch` 실행 필요._
