---
title: "Well, I guess SOMEBODY had to read “Trigger Warning”"
channel: "Jenny Nicholson"
type: "video"
video_id: "qMgMr0JcYJ4"
url: "https://www.youtube.com/watch?v=qMgMr0JcYJ4"
duration: "01:28:39"
upload_order: 84
about: "Long critique of the book \"Trigger Warning\""
transcript_status: "pending"
transcript_video_id: ""
transcript_lang: ""
transcript_kind: ""
transcript_words: 0
upload_date: ""
tags: ["youtube", "video-essay", "jenny-nicholson"]
---

# Well, I guess SOMEBODY had to read “Trigger Warning”

Channel: [[Jenny Nicholson]] · Length 01:28:39 · [YouTube](https://www.youtube.com/watch?v=qMgMr0JcYJ4)

## What it is

Long critique of the book "Trigger Warning"

## Transcript

<!-- transcript -->

_Not fetched yet. Run `python yt_vault.py fetch`._
